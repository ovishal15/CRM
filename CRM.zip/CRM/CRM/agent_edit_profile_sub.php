<?php include("up.php"); require("agent_session.php");?>
<title>Edit Profile</title>
<?php
	require("var/connect.php");
  	 $error = 0;
	if(isset($_POST['sub']))
	{
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$add=$_POST['add'];
		$pcode=$_POST['pcode'];
		$state=$_POST['state'];
		$con_no=$_POST['con_no'];
		$res_no=$_POST['res_no'];
		$city=$_POST['city'];
		$old_pic=$_POST['old_pic'];
		$agent_id=$_SESSION['user_id'];
		 $new_pic = trim($_FILES['new_pic']['name']);
    	 $new_pic_type = $_FILES['new_pic']['type'];
	     $new_pic_size = $_FILES['new_pic']['size']; 

    // Validate and move the uploaded picture file, if necessary
    	 if (!empty($new_pic)) {
         if ((($new_pic_type == 'image/gif') || ($new_pic_type == 'image/jpeg') || ($new_pic_type == 'image/pjpeg') ||
        ($new_pic_type == 'image/png')) && ($new_pic_size > 0) && ($new_pic_size <= 3276800)) {

          // Move the file to the target upload folder
          $target = up_path . basename($new_pic);
          if (move_uploaded_file($_FILES['new_pic']['tmp_name'], $target)) {
              @unlink(MM_UPLOADPATH . $old_picture);
          }
          else {
            // The new picture file move failed, so delete the temporary file and set the error flag
            @unlink($_FILES['new_pic']['tmp_name']);
            $error = 1;
            echo '<p class="error">Sorry, there was a problem uploading your picture.</p>';
          }
        
      }
      else {
        // The new picture file is not valid, so delete the temporary file and set the error flag
        @unlink($_FILES['new_pic']['tmp_name']);
        $error = 1;
        echo '<p class="error">Your picture must be a GIF, JPEG, or PNG image file no greater than ' . (3276800 / 1024) .' KB.</p>';
      }
    }else if(empty($new_pic)){
	$new_pic=$old_pic;
	}
		
		
		
		
		
		
		$e=0;
		$q1="UPDATE `agent_table` SET `first_name`='".$fname."', `last_name`='".$lname."', `picture`='".$new_pic."', `address`='".$add."', `city`='".$city."', `pincode`='".$pcode."',`state`='".$state."',`contact_no`='".$con_no."',`residence_no`='".$res_no."' WHERE `agent_id`='".$agent_id."'";
	
		if(mysql_query($q1,$dbc)){$e=1;}
		
		if($e==1){
			echo "Success fuly updated your profile.";
		}
		else
		{
			echo "not Success fuly updated your profile.";
		}
}

//First this if executed to view data
		if(isset($_POST['submit']) || $error==1)
		{
			$fname=$_POST['fname'];
			$lname=$_POST['lname'];
			$add=$_POST['add'];
			$pcode=$_POST['pcode'];
			$state=$_POST['state'];
			$con_no=$_POST['con_no'];
			$res_no=$_POST['res_no'];
			$city=$_POST['city'];
			$old_pic=$_POST['old_pic'];
			?>
			<fieldset>
			<legend>Conform Data</legend>
			<label>Name:</label><?php echo $fname.' '.$lname;?><br />
			<label>Contect No:</label><?php echo $con_no;?><br />
			<label>Residence No:</label><?php echo $res_no;?><br />
			<label>Address:</label><?php echo $add;?><br />
			<label>Pincode:</label><?php echo $pcode;?><br />
			<label>State:</label><?php echo $state;?><br />
			<label>City:</label><?php echo $city;?><br />		
						
			<form action="agent_edit_profile_sub.php" method="post" enctype="multipart/form-data"><?php
			echo '<input type="hidden" name="fname" value="'.$fname.'" />';
			echo '<input type="hidden" name="lname" value="'.$lname.'" />';
			echo '<input type="hidden" name="add" value="'.$add.'" />';
			echo '<input type="hidden" name="pcode" value="'.$pcode.'" />';
			echo '<input type="hidden" name="state" value="'.$state.'" />';
			echo '<input type="hidden" name="con_no" value="'.$con_no.'" />';
			echo '<input type="hidden" name="res_no" value="'.$res_no.'" />';
			echo '<input type="hidden" name="city" value="'.$city.'" />';
			echo '<input type="hidden" name="old_pic" value="'.$old_pic.'" />';
			?>
			<label>Current Accout Picture:</label><img src="<?php echo  up_path.$old_pic; ?>"  width="200" height="200" /><br>
			<label>Accout Picture:</label><input type="file" name="new_pic" /><br />
			<input type="submit" name="sub" />
			</fieldset>
			</form>
			<img src="" id="pic" alt="" />
			<?php
		}
?>
<?php include("down.php"); ?>