<?php include("up.php"); require("admin_session.php");?>
<title>Approve Claim</title>
 <?php
  require("var/connect.php");
  $error = 0;
  if(isset($_POST['submit']))
  {
  	$claim=$_POST['claim'];
	 foreach($claim as $c){
		$q='UPDATE `claim_table` SET `approve`=1 WHERE `claim_id`='.$c.'';
		mysql_query($q,$dbc)or $error=1;
  	}
	if($error==0){
			echo '<div class="valid">Success fully approve Claim.</div>';
		}
		else
		{
			echo '<div class="error">not Success fully approve claim.</div>';
		}
  }
  else{
  $q='SELECT `claim_id`, `policy_cust_id`, `total_cost`, `cust_id` FROM `claim_table` WHERE `approve`=0';
  $res=mysql_query($q,$dbc) or $error=1;
  if(mysql_num_rows($res)>=1)
  {
  	?>
	<form action="approve_claim.php" method="post">
	<fieldset>
	<legend>Approve Claims</legend>
	 <table><tr><th width="150">Claim_no</th><th width="150">Customer Name</th><th width="150">E-mail</th><th>Total Cost</th><th width="150">Chasis No</th></tr>
	<?php
  	while($row=mysql_fetch_array($res)){
		$cid=$row[0];
		$pcid=$row[1];
		$tcost=$row[2];
		$cust_id=$row[3];
		$q1='SELECT `first_name`, `last_name`, `email_id` FROM `cust_table` WHERE cust_id='.$cust_id.'';
		$res1=mysql_query($q1,$dbc);
		$row1=mysql_fetch_array($res1);
		$fname=$row1[0];
		$lname=$row1[1];
		$email=$row1[2];
		$q3='SELECT `vehicle_id` FROM `policy_cust_table` WHERE `policy_cust_id`='.$pcid.'';
		$res3=mysql_query($q3,$dbc);
		$row3=mysql_fetch_array($res3);
		$vid=$row3[0];
		$q2='SELECT `chasis_no` FROM `vehicle_table` WHERE vehicle_id='.$vid.'';
		$res2=mysql_query($q2,$dbc);
		$row2=mysql_fetch_array($res2);
		$cn=$row2[0];
		echo '<tr><td><input type="checkbox" name="claim[]" value="'.$cid.'" />'.$cid.'</td><td>'.$fname.' '.$lname.'</td><td>'.$email.'</td><td>'.$tcost.'</td><td>'.$cn.'</td></tr>';
	}
	?>
	</table>
	<input type="submit" name="submit" />
	<?php
  }
  else{
  	echo '<div class="warning">no claim.</div>';
  }
  }
?>
<?php include("down.php"); ?>