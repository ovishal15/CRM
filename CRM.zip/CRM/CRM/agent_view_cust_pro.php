<?php include("up.php");  require("agent_session.php"); include("chk_app.php");?>
<?php
	if(isset($_SESSION['key'])){
	$err=0;
	$cust_id=$_GET['vid']/$_SESSION['key'];
	unset($_SESSION['key']);
	$q="SELECT `title`, `first_name`, `last_name`, `dob`, `email_id`, `picture`,`address`, `city`, `pincode`, `state`, `contact_no`, `residence_no` FROM `cust_table` WHERE `cust_id`=$cust_id";
	$data=mysql_query($q,$dbc)or $err=1;
	if(mysql_num_rows($data)==1)
	{
		$row=mysql_fetch_array($data);
			$title=$row[0];$fname=$row[1];$lname=$row[2];$bod=$row[3];$email=$row[4];$pic=$row[5];$add=$row[6];$pcode=$row[8];$con_no=$row[10];$res_no=$row[11];
			$q1='select st.name,ct.name from state_table as st inner join city_table as ct using(state_id) where ct.state_id='.$row[9].' and ct.city_id='.$row[7].'';
			$res1=mysql_query($q1,$dbc) or $err=1;
			$row=mysql_fetch_array($res1);
			$state=$row[0];			
			$city=$row[1];	
	}
	else{$err=1;}
	if($err==0){
	?>
	<fieldset>
			<legend>View Profile</legend>
			<table>
			<tr>
			<td>
			<label>Name:</label><?php echo $fname.' '.$lname;?><br />
			<label>E-mail ID:</label><?php echo $email;?><br />
			<label>Title:</label><?php echo $title;?><br />
			<label>Date of Birth:</label><?php echo $bod;?><br />
			<label>Contect No:</label><?php echo $con_no;?><br />
			<label>Residence No:</label><?php echo $res_no;?><br />
			<label>Address:</label><?php echo $add;?><br />
			<label>Pincode:</label><?php echo $pcode;?><br />
			<label>State:</label><?php echo $state;?><br />
			<label>City:</label><?php echo $city;?><br />
			</td>
			<td align="center">
			<label>Profile Picture:</label></td><td><a href="<?php echo  up_path.$pic; ?>"><img src="<?php echo  up_path.$pic; ?>"  width="200" height="200" /></a>
			</td>
			</tr>
	  </table>
	</fieldset>
	<?php
	}
	else 
	{
		echo '<div class="error">Problem to view proifle.</div>';
	}
	}
	else{echo '<div class="error">NO customer select.</div>';}
?>
<?php include("down.php"); ?>