<?php include("up.php"); ?>
<title>How to claim?</title>
<h1 class="title" style="font-size: 36px;font-weight: bold;">How to claim ?</h1><br>
<div>
    <input type="image" name="imageField" src="Images/about.jpg" />
    <h1 class="title" style="font-size: 16px;font-weight: bold;"> Customer Relationship Managment for VEHICLE insurance</h1>
  <p class="style4"><h1 class="title">What is covered ?</h1><br />
    - Loss or Damage to your vehicle aginst Natural Calamities.<br />
    - Fire,explosion,self-ignition or lighting, earthquake,flood,typhoon,hurricane,storm,<br />
cyclone,landslide,rockslide.

  <h1 class="title">What is not covered ?</h1>
  	- Normal wear and tear and general ageing of the vehicle.<br />
    - Depreciation or anuy consequetial loss.<br />
    - Mechanical/Electrical breakdown.
	
  <p class="style4"><h1 class="title">Sum insured:</h1><br />
    All vehicles are insured at fixed rate known as IDV insured'sDeclared value.<br />
  IDV is calculated on the basis of manufacturer's listed selling price of the vehicle(plus price of accesories) after deducting the depreciation for every year as per INDIAN MOTOR TARIFF.
  
  <h1 class="title">ACCIDENT CLAIM:</h1>
  -Claim Form <br />
    -RC copy of the vehicle<br />
    -Driving License copy<br />
    -Policy copy (First two pages)<br />
    -FIR on a case-to-case basis<br />
    -Original Estimate<br />
    -Original Repair Invoice and Payment Receipt (for cashless garage, only repair invoice)<br />
    * Stamp required in case of company registered vehicle
	
  <h1 class="title">THEFT CLAIM:</h1>
  -Claim Form duly signed*<br />
    -RC copy of the vehicle with all original keys<br />
    -Driving License copy<br />
    -Policy copy<br />
    -Original FIR copy
	
  <h1 class="title">THIRD PARTY CLIAM:</h1><br />
    -Claim Form duly signed*<br />
    -Police FIR copy<br />
    -Driving License copy<br />
    -Policy copy<br />
    -RC copy of the vehicle<br />
  
</div>
<?php include("down.php"); ?>