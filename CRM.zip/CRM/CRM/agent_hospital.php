<?php include("up.php"); require("agent_session.php");?>
<title>Add Hospital</title>
<script type="text/javascript" src="JS/jquery-2.0.3.min.js"></script>
<script type="text/javascript">
function selectcity(state_id){
 if(state_id!="-1"){
   loadData(state_id);
   $("#city_dropdown").html("<option value='-1'>Select City</option>");
 }else{
   $("#city_dropdown").html("<option value='-1'>Select City</option>");
 }
}
function loadData(loadId){
  var dataString ='loadId='+ loadId;
  $("#city_loader").show();
	 $.ajax({
     type: "POST",
     url: "JS/loadcity.php",
     data: dataString,
     cache: false,
     success: function(result){
       $("#city_loader").hide();
       $("#city_dropdown").
       html("<option value='-1'>Select City</option>");
       $("#city_dropdown").append(result);
     }
   });
}
</script>
<script src="JS/hospital_validate.js"></script>
<?php
if(isset($_POST['submit']))
{
require("var/connect.php");
$err=0;
$cid=$_POST['cid'];
$fname=$_POST['fname'];
$dob=$_POST['dob'];
$add=$_POST['add'];
$pcode=$_POST['pcode'];
$state=$_POST['state'];
$city=$_POST['city'];
$con_no=$_POST['con_no'];
$q='INSERT INTO `witness_table`(`witness_id`, `name`, `dob`, `address`,  `pincode`, `state`,`city`, `contact_no`, `claim_id`) VALUES (0,"'.$fname.'",'.$dob.',"'.$add.'",'.$pcode.',"'.$state.'","'.$city.'",'.$con_no.','.$cid.')';
mysql_query($q,$dbc) or $err=1;
	if($err==1){echo 'error';}
}
if(isset($_POST['submit']) && $err==0){
?>
<div id="errors"></div>
<form method="post" action="agent_garage.php" onSubmit="return validate_form(this)">
<fieldset>
	<legend>Hospital Details</legend>
	<label>Hospital Name</label><input type="text" name="hname" required="required"><br>
	<label>Dr. Name</label><input type="text" name="drname" required="required"><br>
	<label>Cost</label><input type="text" name="cost" required="required"><br>
	<label>*Address </label><textarea name="add" required="required"></textarea><br />
<label>*State</label>
<select id="state_dropdown"  name="state" onChange="selectcity(this.options[this.selectedIndex].value)" required="required">
<option value="-1">Select State</option>
   	 <?php
	require("var/connect.php");
	$q="SELECT `state_id`, `name` FROM `state_table`";
	$res=mysql_query($q,$dbc);
	while($row=mysql_fetch_array($res))
	{
	echo '<option value="'.$row[0].'">'.$row[1].'</option>';
	}
	?>
</select><br>

<label>*City</label>
<select id="city_dropdown" name="city" required="required">
<option value="-1">Select City</option>
</select><br />
<label>*Pincode</label><input type="text" name="pcode" required="required" /><br />
<label>*Contact No </label><input type="text" name="con_no" required="required" /><br />
<input type="hidden" name="cid" value="<?php echo $cid;?>">
<input type="submit"  name="submit">
</fieldset>
</form>
<?php }include("down.php"); ?>