<?php include("up.php"); require("admin_session.php");?>
<title>Edit Profile</title>
<?php
	require("var/connect.php");
  	 $error = 0;
	if(isset($_POST['submit']))
	{
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$add=$_POST['add'];
		$pcode=$_POST['pcode'];
		$state=$_POST['state'];
		$con_no=$_POST['con_no'];
		$res_no=$_POST['res_no'];
		$city=$_POST['city'];
		$agent_id=$_SESSION['eagentid'];
		unset($_SESSION['eagentid']);
    	$e=0;
		if($_POST['type']=='customer')
		$q1="UPDATE `cust_table` SET `first_name`='".$fname."', `last_name`='".$lname."', `address`='".$add."', `city`='".$city."', `pincode`='".$pcode."',`state`='".$state."',`contact_no`='".$con_no."',`residence_no`='".$res_no."' WHERE `cust_id`='".$agent_id."'";
		else
		$q1="UPDATE `agent_table` SET `first_name`='".$fname."', `last_name`='".$lname."', `address`='".$add."', `city`='".$city."', `pincode`='".$pcode."',`state`='".$state."',`contact_no`='".$con_no."',`residence_no`='".$res_no."' WHERE `agent_id`='".$agent_id."'";
		mysql_query($q1,$dbc) or $e=1;
		
		if($e==1){
			echo '<p class="error">not Successfuly updated profile.</p>';
		}
		else
		{
			echo '<p class="valid">Successfuly updated profile.</p>';
		}
}
?>
<?php include("down.php"); ?>