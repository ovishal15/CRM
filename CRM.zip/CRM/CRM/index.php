<?php include("up.php");?>
<title>Home</title>
<img src="Images/home.png" width="760"  />
<?php include("down.php"); ?>