<?php include("up.php");require("comman_session.php"); include("chk_app.php");?>
<title>Buy Policy</title>
<form action="cust_two_add_vehicle.php" method="post">
	<fieldset>
	<legend>Buy New Polices</legend>
	<?php
  	if(isset($_POST['submit']))
	{
	$pid=$_POST['poli'];
	if($_SESSION['type']=='agent'){$cust=$_POST['cust']; $_SESSION['bcust']=$cust;}
	 $q='SELECT `title`,`policy_type`, `description`, `fixed_cover`, `discount` FROM `policy_table` where policy_id='.$pid.'';
	 $res=mysql_query($q,$dbc);
 	 $row=mysql_fetch_array($res);
	 echo "<table>";
	 echo '<tr><th width="150">Policy</th><td>'.$row[0].'</td></tr>';
	 echo '<tr><th width="150">Type</th><td>'.$row[1].'</td></tr>';
	 echo '<tr><th width="150">Description</th><td>'.$row[2].'</td></tr>';
 	 echo '<tr><th width="150">Special Discount</th><td>'.$row[4].'</td></tr>';
	 echo '<tr><th width="150">Fixed Cover</th><td>'.$row[3].'</td></tr></table>';
	 echo '<input type="hidden" name="id" value="'.$pid.'">';
	?>
    <input type="submit" name="submit" value="Submit" />
	</fieldset>
  </form>
<?php }include("down.php"); ?>