<?php include("up.php"); require("admin_session.php");?>
<title>Add FAQ</title>
<?php
	require("var/connect.php");
  	 $error = 0;
	if(isset($_POST['sub']))
	{
		$e=0;
		$qus=$_POST['qus'];
		$ans=$_POST['ans'];
		
		$q="INSERT INTO `faq_table`(`faq_id`, `qus`, `ans`) VALUES (0,'".$qus."','".$ans."')";
		mysql_query($q,$dbc) or $e=1;
		
			
		if($e==0){
			echo '<div class="valid">Success fuly Submited.....</div>';
		}
		else
		{
			echo '<div class="error">not Success fuly Submited.</div>';
		}
}

//First this if executed to view data
		if(isset($_POST['submit']))
		{
			$qus=$_POST['qus'];
			$ans=$_POST['ans'];
			?>
			<fieldset>
			<legend>Conform Data</legend>
			<label>Quesion:</label><?php echo $qus;?><br />
			<label>Answer:</label><?php echo $ans;?><br />
						
			<form action="add_faq_sub.php" method="post">
			<?php
			echo '<input type="hidden" name="qus" value="'.$qus.'" />';
			echo '<input type="hidden" name="ans" value="'.$ans.'" />';
			?>
			<input type="submit" name="sub" />
			</fieldset>
			</form>
			<?php
		}
		
?>
	
<?php include("down.php"); ?>