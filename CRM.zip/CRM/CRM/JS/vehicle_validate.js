function validateForm(theform){
	var err="";
	err = err + vali_rto(theform.rto);
	err = err + vali_no(theform.mil,"Milege");
	err = err + vali_no(theform.cn,"Chsis_no");
	err = err + vali_no(theform.elev,"ELE. ACC FITING VALUE");
	err = err + vali_no(theform.nelev,"NON- ELE.ACC. VALUE");
	err = err + vali_no(theform.clc,"CNG / LPG COST AMT");
	err = err + vali_no(theform.nop,"NO. OF PA PASSENGER");
	err = err + vali_empty(theform.manu,"Manufacturer");
	err = err + vali_empty(theform.mod,"Model");
	if(err===""){
	return true;	
	}
	else{
		var a=document.getElementById("errors");
		a.innerHTML="Errors<br>"+err;
		a.className="error";
		return false;
	}
}
function vali_empty(fld,tag){
	var error="";
	if(fld.value==-1){
		 fld.className="error"; 
        error = "Please select one of option "+tag+".\n<br>";
	}
	else{
		fld.className="";
	}
	return error;
}
function vali_rto(fld) {
 var error = "";
	 var ck_name = /^[A-Za-z0-9]{3,20}$/;
	 if (!ck_name.test(fld.value)){
		  fld.className="error"; 
        error = "In-valide value of  RTO.\n<br>";
	}else if (!(fld.value.length == 4)) {
        error = "The RTO number is the wrong length..\n<br>";
        fld.className="error";
    } 
	else{
		fld.className="";
	}
    return error;
}
function vali_no(fld,tag) {
    var error = "";
	if(fld.value>=1)
	{
    var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');     
	if (isNaN(parseInt(stripped))) {
        error = "The "+tag+" number contains illegal characters.\n<br>";
        fld.className="error";
    } else {
        fld.className="";
    }
	}
    return error;
}