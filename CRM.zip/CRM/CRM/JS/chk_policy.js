function validate_policy(form)
{
	var err="";
	err = err + vali_text(form.title,"Title");
	err = err + vali_text(form.cover,"Fixed Cover");
	err = err + vali_num(form.dis,"Special Discount");
	if(err===""){
	return true;	
	}
	else{
		var a=document.getElementById("errors");
		a.innerHTML="Errors<br>"+err;
		a.className="error";
		return false;
	}
}
function vali_text(fld,fn){
	 var error = "";
	 var ck_name = /^[A-Za-z0-9\s���]{3,20}$/;
	 if (!ck_name.test(fld.value)){
		  fld.className="error"; 
        error = "In-valide value of "+fn+".\n<br>";
	}
	else{
		fld.className="";
	}
    return error;
}
function vali_num(fld,fn){
	 var error = "";
	 var ck_name = /^[0-9]{1,3}$/;
	 if(fld.value.length>0)
	 {
	 if (!ck_name.test(fld.value)){
		  fld.className="error"; 
        error = "In-valide value of "+fn+". Please not use any Special charachter\n<br>";
	}
	else if(fld.value>100 || fld.value<1)
	{
		fld.className="error"; 
        error = fn+" Must Be between 1 to 100 Only.\n<br>";
	}
	else{
		fld.className="";
	}
	}
    return error;
}