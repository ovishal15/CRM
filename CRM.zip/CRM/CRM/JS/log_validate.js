function validate_form(theform){
	var err="";
	err = err + vali_email(theform.uemail);
	err = err + vali_text(theform.pass);
	if(err===""){
	return true;	
	}
	else{
		var a=document.getElementById("errors");
		a.innerHTML="Errors<br>"+err;
		a.className="error";
		return false;
	}
}
function vali_email(fld)
{ 
	var error="";
    var tfld = fld.value; // value of field with whitespace trimmed off
    var emailFilter = /^[^@]+@[^@.]+\.[^@]*\w\w$/ ;
    var illegalChars= /[\(\)\<\>\,\;\:\\\"\[\]]/ ;
    if (!emailFilter.test(tfld)) {              //test email for illegal characters
        fld.className="error";
        error = "Please enter a valid email address.\n<br>";
    } else if (fld.value.match(illegalChars)) {
        fld.className="error";
        error = "The email address contains illegal characters.\n<br>";
    } else {
        fld.className="";
    } 
    return error;
}
function vali_text(fld){
	var error="";
	var illegalChars = /\W/;
	if (illegalChars.test(fld.value)) {
		fld.className="error";
        error = "The password contains illegal characters.\n<br>";
    }else{
		fld.className="";
	}
	return error;
}