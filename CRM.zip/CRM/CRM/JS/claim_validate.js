function validate_form(theform){
	var err="";
	err = err + vali_cost(theform.tcost);
	if(err===""){
	return true;	
	}
	else{
		var a=document.getElementById("errors");
		a.innerHTML="Errors<br>"+err;
		a.className="error";
		return false;
	}
}

//validate pin code
function vali_cost(fld) {
    var error = "";
    var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');     
	if (isNaN(parseInt(stripped))) {
        error = "The Total Cost is not valid.\n<br>";
        fld.className="error";

    } else {
fld.className="";
    }
    return error;
}
