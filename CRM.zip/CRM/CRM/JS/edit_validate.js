function validateForm(theform){
	var err="";
	err = err + vali_text(theform.fname,"First Name");
	err = err + vali_text(theform.lname,"Last Name");
	err = err + vali_pcode(theform.pcode);
	err = err + vali_empty(theform.state,"State");
	err = err + vali_empty(theform.city,"City");
	err = err + vali_phono(theform.con_no);
	err = err + vali_resno(theform.res_no);
	if(err===""){
	return true;	
	}
	else{
		var a=document.getElementById("errors");
		a.innerHTML="Errors<br>"+err;
		a.className="error";
		return false;
	}
}
function vali_empty(fld,tag){
	var error="";
	if(fld.value==-1){
		 fld.className="error"; 
        error = "Please select one of option "+tag+".\n<br>";
	}
	else{
		fld.className="";
	}
	return error;
}
//valide pin code
function vali_pcode(fld) {
    var error = "";
    var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');     
	if (isNaN(parseInt(stripped))) {
        error = "The phone number contains illegal characters.\n<br>";
        fld.className="error";
    } else if (!(stripped.length == 6)) {
        error = "The pin code is the wrong length.\n<br>";
        fld.className="error";
    }  else {
        fld.className="";
    } 
    return error;
}
//validation of text
function vali_text(fld,fn){
	 var error = "";
	 var ck_name = /^[A-Za-z]{3,20}$/;
	 if (!ck_name.test(fld.value)){
		  fld.className="error"; 
        error = "In-valide value of "+fn+".\n<br>";
	}
	else{
		fld.className="";
	}
    return error;
}
//validate residence no
function vali_resno(fld) {
    var error = "";
    var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');  
	if(fld.value.length!=0){
	if (isNaN(parseInt(stripped))) {
        error = "The residence number contains illegal characters.\n<br>";
        fld.className="error";
    } else if (!(stripped.length == 11)) {
        error = "The residence number is the wrong length. Make sure you included an area code.\n<br>";
        fld.className="error";
    } else {
        fld.className="";
    }  
	}
    return error;
}
//validate phone no
function vali_phono(fld) {
    var error = "";
    var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');     
	if (isNaN(parseInt(stripped))) {
        error = "The phone number contains illegal characters.\n<br>";
        fld.className="error";
    } else if (!(stripped.length == 10)) {
        error = "The phone number is the wrong length. Make sure you not included +91.\n<br>";
        fld.className="error";
    } else {
        fld.className="";
    }  
    return error;
}