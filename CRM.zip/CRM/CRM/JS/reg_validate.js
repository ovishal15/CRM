function validateForm(theform){
	var err="";
	err = err + vali_text(theform.fname,"First Name");
	err = err + vali_text(theform.lname,"Last Name");
	err = err + vali_email(theform.email);
	err = err + vali_date(theform.dob);
	err = err + vali_pcode(theform.pcode);
	err = err + vali_empty(theform.state,"State");
	err = err + vali_empty(theform.city,"City");
	err = err + vali_phono(theform.con_no);
	err = err + vali_resno(theform.res_no);
	err = err + vali_pass(theform.pass,theform.con_pass);
	err = err + vali_ans(theform.ans,"Answer");
	if(err===""){
	return true;	
	}
	else{
		var a=document.getElementById("errors");
		a.innerHTML="Errors<br>"+err;
		a.className="error";
		return false;
	}
}
//dropdown list empty or not
function vali_empty(fld,tag){
	var error="";
	if(fld.value==-1){
		 fld.className="error"; 
        error = "Please select one of option "+tag+".\n<br>";
	}
	else{
		fld.className="";
	}
	return error;
}
//validation of e_mail
function vali_email(fld)
{ 
	var error="";
    var tfld = fld.value; // value of field with whitespace trimmed off
    var emailFilter = /^[^@]+@[^@.]+\.[^@]*\w\w$/ ;
    var illegalChars= /[\(\)\<\>\,\;\:\\\"\[\]]/ ;
    if (!emailFilter.test(tfld)) {              //test email for illegal characters
        fld.className="error";
        error = "Please enter a valid email address.\n<br>";
    } else if (fld.value.match(illegalChars)) {
        fld.className="error";
        error = "The email address contains illegal characters.\n<br>";
    } else {
        fld.className="";
    } 
    return error;
}
//validate Birth date
function vali_date(fld)
{
	var error="";
	var d = new Date();
  	var a=fld.value;
	var to_year=d.getFullYear();
	var birth_year=a.substr(0,4)
	if(birth_year<(to_year-18)){
	fld.className="";
	}
	else{
		fld.className="error";
        error = "Your age must be 18 or more.\n<br>";
	}
	return error;
}
//validate pin code
function vali_pcode(fld) {
    var error = "";
    var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');     
	if (isNaN(parseInt(stripped))) {
        error = "The Pin code contains illegal characters.\n<br>";
        fld.className="error";
    } else if (!(stripped.length == 6)) {
        error = "The pin code is the wrong length.\n<br>";
        fld.className="error";
    }  else {
        fld.className="";
    } 
    return error;
}
//validation of text
function vali_text(fld,fn){
	 var error = "";
	 var ck_name = /^[A-Za-z]{3,20}$/;
	 if (!ck_name.test(fld.value)){
		  fld.className="error"; 
        error = "In-valide value of "+fn+".\n<br>";
	}
	else{
		fld.className="";
	}
    return error;
}
//validation of answer
function vali_ans(fld,fn){
	 var error = "";
	 var ck_name = /^[A-Za-z0-9]{3,20}$/;
	 if (!ck_name.test(fld.value)){
		  fld.className="error"; 
        error = "In-valide value of "+fn+".\n<br>";
	}
	else{
		fld.className="";
	}
    return error;
}
//validate residence no
function vali_resno(fld) {
    var error = "";
    var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');  
	if(fld.value.length!=0){
	if (isNaN(parseInt(stripped))) {
        error = "The residence number contains illegal characters.\n<br>";
        fld.className="error";
    } else if (!(stripped.length == 11)) {
        error = "The residence number is the wrong length. Make sure you included an area code.\n<br>";
        fld.className="error";
    } else {
        fld.className="";
    }  
	}
    return error;
}
//validate phone no
function vali_phono(fld) {
    var error = "";
    var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');     
	if (isNaN(parseInt(stripped))) {
        error = "The phone number contains illegal characters.\n<br>";
        fld.className="error";
    } else if (!(stripped.length == 10)) {
        error = "The phone number is the wrong length. Make sure you not included +91.\n<br>";
        fld.className="error";
    } else {
        fld.className="";
    }  
    return error;
}
//password validate
function vali_pass(p1,p2){
	var error="";
	var illegalChars = /\W/;
	if(p1.value!=p2.value){
		error="Password not match <br>";
		p1.className="error";
		p2.className="error";
	}
	 else if (illegalChars.test(p1.value)) {
		 p2.className="error";
        p1.className="error"; 
        error = "The password contains illegal characters.\n<br>";
    }
	else if(p1.value.length < 8 || p1.value.length > 16){
		 p2.className="error";
        p1.className="error"; 
        error = "Please password with length 8 to 16 characters.\n<br>";
    }
	else{
		p1.className="";
		p2.className="";
	}
	return error;
}