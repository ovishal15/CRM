function validateForm(theform){
	var err="";
	err = err + vali_pass(theform.pass,theform.con_pass);
	if(err===""){
	return true;	
	}
	else{
		var a=document.getElementById("errors");
		a.innerHTML="Errors<br>"+err;
		a.className="error";
		return false;
	}
}
//password validate
function vali_pass(p1,p2){
	var error="";
	var illegalChars = /\W/;
	if(p1.value!=p2.value){
		error="Password not match <br>";
		p1.className="error";
		p2.className="error";
	}
	 else if (illegalChars.test(p1.value)) {
		 p2.className="error";
        p1.className="error"; 
        error = "The password contains illegal characters.\n<br>";
    }
	else if(p1.value.length < 8 || p1.value.length > 16){
		 p2.className="error";
        p1.className="error"; 
        error = "Please password with length 8 to 16 characters.\n<br>";
    }
	else{
		p1.className="";
		p2.className="";
	}
	return error;
}