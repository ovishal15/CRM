<?php 
	require("../var/connect.php");
	$id=$_POST['loadId'];
    $sql="SELECT city_id,name FROM `city_table` WHERE state_id=$id";
	$res=mysql_query($sql,$dbc) or die($sql);
	$check=mysql_num_rows($res);
	if($check > 0){
   		while($row=mysql_fetch_array($res)){
      	echo "<option value='".$row[0]."'>".$row['1']."</option>";
   		}
	}
?>