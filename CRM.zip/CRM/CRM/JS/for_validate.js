function vali_for(theform)
{
	err="";
	err+=vali_email(theform.email);
	err+=vali_phono(theform.con_no);
	if(err===""){
	return true;	
	}
	else{
		var a=document.getElementById("errors");
		a.innerHTML="Errors<br>"+err;
		a.className="error";
		return false;
	}
}
function vali_email(fld)
{ 
	var error="";
    var tfld = fld.value; // value of field with whitespace trimmed off
    var emailFilter = /^[^@]+@[^@.]+\.[^@]*\w\w$/ ;
    var illegalChars= /[\(\)\<\>\,\;\:\\\"\[\]]/ ;
    if (!emailFilter.test(tfld)) {              //test email for illegal characters
        fld.className="error";
        error = "Please enter a valid email address.\n<br>";
    } else if (fld.value.match(illegalChars)) {
        fld.className="error";
        error = "The email address contains illegal characters.\n<br>";
    } else {
        fld.className="";
    } 
    return error;
}
function vali_phono(fld) {
    var error = "";
    var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');     
	if (isNaN(parseInt(stripped))) {
        error = "The phone number contains illegal characters.\n<br>";
        fld.className="error";
    } else if (!(stripped.length == 10)) {
        error = "The phone number is the wrong length. Make sure you not included +91.\n<br>";
        fld.className="error";
    } else {
        fld.className="";
    }
    return error;
}

//validate cust_reg_forgot file data
function vali_ans(fld){
	 var ck_name = /^[A-Za-z0-9]{3,20}$/;
	 if (!ck_name.test(fld.value)){
		  fld.className="error"; 
		var a=document.getElementById("errors");
		a.innerHTML="Errors<br>In-valide value of Answer.<br>";
		a.className="error";
		return false;
	}
	else{
		fld.className="";
		return true;
	}
}