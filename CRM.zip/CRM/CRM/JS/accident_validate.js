function validate_form(theform){
	var err="";
	err = err + vali_text(theform.aname,"Police Attender");
	err = err + vali_text(theform.pname,"Police Station");
	if(err===""){
	return true;	
	}
	else{
		var a=document.getElementById("errors");
		a.innerHTML="Errors<br>"+err;
		a.className="error";
		return false;
	}
}
//validation of text
function vali_text(fld,fn){
	 var error = "";
	 var ck_name = /^[A-Za-z\s���]{3,20}$/;
	 if (!ck_name.test(fld.value)){
		  fld.className="error"; 
        error = "In-valide value of "+fn+".\n<br>";
	}
	else{
		fld.className="";
	}
    return error;
}