function validate_form(theform){
	var err="";
	err = err + vali_text(theform.gname,"Garage Name");
	err = err + vali_text(theform.mname,"Michanic Name");
	err = err + vali_cost(theform.cost);
	err = err + vali_pcode(theform.pcode);
	err = err + vali_empty(theform.state,"State");
	err = err + vali_empty(theform.city,"City");
	err = err + vali_phono(theform.con_no);
	if(err===""){
	return true;	
	}
	else{
		var a=document.getElementById("errors");
		a.innerHTML="Errors<br>"+err;
		a.className="error";
		return false;
	}
}
//dropdown list empty or not
function vali_empty(fld,tag){
	var error="";
	if(fld.value==-1){
		 fld.className="error"; 
        error = "Please select one of option "+tag+".\n<br>";
	}
	else{
		fld.className="";
	}
	return error;
}
function vali_cost(fld) {
    var error = "";
    var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');     
	if (isNaN(parseInt(stripped))) {
        error = "The Total Cost is not valid.\n<br>";
        fld.className="error";
    } else {
fld.className="";
    }
    return error;
}

//validate pin code
function vali_pcode(fld) {
    var error = "";
    var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');     
	if (isNaN(parseInt(stripped))) {
        error = "The Pin code contains illegal characters.\n<br>";
        fld.className="error";
    } else if (!(stripped.length == 6)) {
        error = "The pin code is the wrong length.\n<br>";
        fld.className="error";
    }  else {
        fld.className="";
    } 
    return error;
}
//validation of text
function vali_text(fld,fn){
	 var error = "";
	 var ck_name = /^[A-Za-z\s���]{3,20}$/;
	 if (!ck_name.test(fld.value)){
		  fld.className="error"; 
        error = "In-valide value of "+fn+".\n<br>";
	}
	else{
		fld.className="";
	}
    return error;
}
//validate phone no
function vali_phono(fld) {
    var error = "";
    var stripped = fld.value.replace(/[\(\)\.\-\ ]/g, '');     
	if (isNaN(parseInt(stripped))) {
        error = "The phone number contains illegal characters.\n<br>";
        fld.className="error";
    } else if (!(stripped.length == 10)) {
        error = "The phone number is the wrong length. Make sure you not included +91.\n<br>";
        fld.className="error";
    } else {
        fld.className="";
    }  
    return error;
}
function vali_date(fld)
{
	var error="";
	var d = new Date();
  	var a=fld.value;
	var to_year=d.getFullYear();
	var birth_year=a.substr(0,4)
	if(birth_year<(to_year-18)){
	fld.className="";
	}
	else{
		fld.className="error";
        error = "Your age must be 18 or more.\n<br>";
	}
	return error;
}
