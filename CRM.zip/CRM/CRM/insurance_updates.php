<?php include("up.php"); ?>
<title>Insurance Updates</title>
<h1 class="title" style="font-size: 36px;font-weight: bold;">Insurance Updates</h1><br>
<div>
    <input type="image" name="imageField" src="Images/about.jpg" />
    <h1 class="title" style="font-size: 16px;font-weight: bold;"> Customer Relationship Managment for VEHICLE insurance</h1>
  <p><h1 class="title">*The government has decided to bring in place an insurance scheme for the police personnel in the state.</h1> <br />
  The new insurance scheme will also be made applicable to the employees of jail department and fire and rescue services.</p>
  
  <h1 class="title">*Your parking slot may decide motor cover cost</h1>
  <p>While geography and your car's make and model have been the prime factors that determine premiums for motor insurance, <br />
    insurers are now taking into account other factors - from your driving history to the colour of your car or even the parking slot of your vehicle.</p>
  
  <p><h1 class="title">*Third-party motor cover may pinch, IRDA examines proposal that seeks highest 137% hike for entry-level cars</h1><br />
  Come April, your third party (TP) motor insurance will start pinching your pocket more.</p>
  
  <p><h1 class="title">*IRDA plans to free up motor third-party rates</h1><br />
  IRDA has drawn plans to free up pricing of motor third-party cover from 2015 even as insurance companies have raised objections to the proposed new rates.</p>
  <h1 class="title">The above are news updates which represants till 03/03/2014 </h1>
</div>
<?php include("down.php"); ?>