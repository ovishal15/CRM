<?php include("up.php");require("comman_session.php"); include("chk_app.php");?>
<title>Add Vehicle</title>
<?php 
if(isset($_POST['submit']))
{
	if($_SESSION['type']=='agent'){$cust=$_SESSION['bcust']; unset($_SESSION['bcust']);}
	elseif($_SESSION['type']=='customer'){$cust=$_SESSION['user_id'];}
	$rto=$_POST['rto'];
	$manu=$_POST['manu'];
	$mod=$_POST['mod'];
	$mil=$_POST['mil'];
	$cn=$_POST['cn'];
	$rd=$_POST['rd'];
	$pid=$_POST['pid'];
	
	$rto=$_POST['rto'];
	$age=$_POST['age'];
	$rt=4;
	$cc=$_POST['cc'];
	$idv=$_POST['idv'];
	$elev=$_POST['elev'];
	$nelev=$_POST['nelev'];
	$cli=$_POST['cli'];
	$clc=$_POST['clc'];
	$nop=$_POST['nop'];
	$amount=0;
	require_once 'Classes/PHPExcel.php';
require_once 'Classes/PHPExcel/IOFactory.php';
$zone="A";
$q='SELECT `discount` FROM `policy_table` WHERE `policy_id`='.$pid.'';
$res=mysql_query($q,$dbc);
$row=mysql_fetch_row($res);
$dis=$row[0];

$inputFileType = PHPExcel_IOFactory::identify('get_quote.xls');
$objPHPExcel = PHPExcel_IOFactory::load('get_quote.xls');

$objPHPExcel->setActiveSheetIndex(1);
$objPHPExcel->getActiveSheet()->setCellValue('J6',$zone);
$objPHPExcel->getActiveSheet()->setCellValue('J7',$age);
$objPHPExcel->getActiveSheet()->setCellValue('J8',$cc);
$objPHPExcel->getActiveSheet()->setCellValue('J9',$idv);
$objPHPExcel->getActiveSheet()->setCellValue('J10',$elev);
$objPHPExcel->getActiveSheet()->setCellValue('J11',$nelev);
$objPHPExcel->getActiveSheet()->setCellValue('J12',$cli);
$objPHPExcel->getActiveSheet()->setCellValue('J13',$clc);
$objPHPExcel->getActiveSheet()->setCellValue('J15',$nop);
$objPHPExcel->getActiveSheet()->setCellValue('M13',$dis);
$pre= $objPHPExcel->getActiveSheet()->getCell('N39')->getCalculatedValue();
	$err=0;
	$q1="INSERT INTO `vehicle_table`(`vehicle_id`, `rto`, `manufacture`, `model`, `milege`, `chasis_no`, `reg_type`, `reg_date`, `age_vehicle`, `idv`, `ele_acc`, `nele_acc`, `cli`, `clc`, class,no_pa, `cc`) VALUES (0,'".$rto."','".$manu."','".$mod."','".$mil."','".$cn."','".$rt."','".$rd."','".$age."','".$idv."','".$elev."','".$nelev."','".$cli."','".$clc."','".$zone."','".$nop."',$cc)";
	mysql_query($q1,$dbc) or $err=1;
	$q2="SELECT `vehicle_id` FROM `vehicle_table` WHERE `rto`='".$rto."' and `class`='".$zone."' and `manufacture`='".$manu."'and `model`='".$mod."'and `milege`='".$mil."'and `chasis_no`='".$cn."'";
	$res2=mysql_query($q2,$dbc);
	$row2=mysql_fetch_row($res2);
	$vid=$row2[0];
	$q='INSERT INTO `policy_cust_table`(`policy_cust_id`, `cust_id`, `policy_id`, `approve`, date, `premium`, `vehicle_id`) VALUES (0,'.$cust.','.$pid.',0,NOW(),'.$pre.','.$vid.')';
	mysql_query($q,$dbc) or $err=1;
	if($err==0){echo '<div class="warning">Your policy have been submited,we approve your policy when you pay money.</div>';}
	else{echo '<div class="error">Sorry, Some error found so try again later</div>';}

}else{echo '<div class="warning">Add vehicle information</div>';}
?>
<?php include("down.php"); ?>