<?php
	//session_start();
	if(isset($_SESSION['type']) && $_SESSION['type']=="admin"){
	include("admin_menu.php");
	}
	else if(isset($_SESSION['type']) && $_SESSION['type']=="agent"){
	include("agent_menu.php");
	}
	else if(isset($_SESSION['type']) && $_SESSION['type']=="customer"){
	include("cust_menu.php");
	}
	else{
	include("visitor_menu.php");
	}
?>