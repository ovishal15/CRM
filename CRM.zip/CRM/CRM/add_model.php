<?php include("up.php"); require("admin_session.php");?>
<script type="text/javascript" src="JS/jquery-2.0.3.min.js"></script>
<script type="text/javascript">
function selectmanufacturer(manufacturer_id){
  if(manufacturer_id!="-1"){
    loadData("model",manufacturer_id);
  }else{
    $("#model_dropdown").html("<option value='-1'>Select model</option>");
  }
}

/*This function is called when model dropdown value change*/
function selectmodel(vehicle_id){
 if(vehicle_id!="-1"){
   loadData('manufacturer',vehicle_id);
   $("#model_dropdown").html("<option value='-1'>Select model</option>");
 }else{
  	$("#manufacturer_dropdown").html("<option value='-1'>Select manufacturer</option>");
   $("#model_dropdown").html("<option value='-1'>Select model</option>");
 }
}

/*This is the main content load function, and it will
     called whenever any valid dropdown value changed.*/
function loadData(loadType,loadId){
  var dataString = 'loadType='+ loadType +'&loadId='+ loadId;
  $("#"+loadType+"_loader").show();
	 $.ajax({
     type: "POST",
     url: "JS/loadData.php",
     data: dataString,
     cache: false,
     success: function(result){
       $("#"+loadType+"_loader").hide();
       $("#"+loadType+"_dropdown").
       html("<option value='-1'>Select "+loadType+"</option>");
       $("#"+loadType+"_dropdown").append(result);
     }
   });
}
//validate
function validateForm(theform){
	var err="";
	err = err + vali_empty(theform.rt,"Registration Type");
	err = err + vali_empty(theform.manuf,"Manufacturer");
	err = err + vali_text(theform.model,"Model");
	if(err===""){
	return true;	
	}
	else{
		var a=document.getElementById("errors");
		a.innerHTML="Errors<br>"+err;
		a.className="error";
		return false;
	}
}
function vali_text(fld,fn){
	 var error = "";
	 var ck_name = /^[A-Za-z0-9]{3,20}$/;
	 if (!ck_name.test(fld.value)){
		  fld.className="error"; 
        error = "In-valide value of "+fn+".\n<br>";
	}
	else{
		fld.className="";
	}
    return error;
}


function vali_empty(fld,tag){
	var error="";
	if(fld.value==-1){
		 fld.className="error"; 
        error = "Please select one of option "+tag+".\n<br>";
	}
	else{
		fld.className="";
	}
	return error;
}

</script>
<div id="errors"></div>
<title>Add Model</title>
	<?php
	if(isset($_POST['submit']))
	{
	$err=0;
	require("var/connect.php");
	$type=$_POST['rt'];
	$manuf=$_POST['manuf'];
	$model=$_POST['model'];
	$q='INSERT INTO `model_table`(`model_id`, `name`, `type`, `manufacturer_id`) VALUES (0,"'.$model.'",'.$type.','.$manuf.')';
	mysql_query($q,$dbc) or $err=1;
	if($err==1){echo '<div class="error">New Model Susseccful not added</div>';}
	else{echo '<div class="valid">New Model Susseccful added</div>';}
	}
	else{
	?>
	<form action="add_model.php" method="post" onsubmit="return validateForm(this)">
	<fieldset>
	<legend>Add New Manufacturer</legend>
	<label>*Registration Type</label>
	<select name="rt" onChange="selectmodel(this.options[this.selectedIndex].value)" required="required">
    <option value="-1">Select vehicle</option>
    <option value="2">2</option>
    <option value="4">4</option>
    </option>
	</select><br>
	<label>*Manufacturer</label>
	<select id="manufacturer_dropdown" name="manuf" onChange="selectmanufacturer(this.options[this.selectedIndex].value)" required="required">
   	<option value="-1">Select manufacturer</option>
    </option>
	</select><br />
  	<label>*Model</label>
	<select id="model_dropdown" name="mod" required="required">
	<option value="-1">Select model</option>
	</select>
	<input type="text" name="model" required="required"/>
	<br>
	<input type="submit" name="submit" />
	</fieldset>
	</form>
<?php }include("down.php"); ?>
