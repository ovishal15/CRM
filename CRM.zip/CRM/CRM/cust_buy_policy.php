<?php include("up.php");  require("cust_session.php"); include("chk_app.php");?>
<title>Buy Policy</title>
<?php 
  	 $err = 0;
	 $q='SELECT `approve` FROM `cust_table` WHERE `cust_id`='.$_SESSION['user_id'].'';
	 $res=mysql_query($q,$dbc) or $err=1;
	 $row=mysql_fetch_array($res);
	 if($row[0]==0 || $err==1)
	 {
	 echo "You not yet approve or problem occur";
	 }
	 else{
?>
<form action="cust_buy_policy_sub.php" method="post">
	<fieldset>
	<legend>Buy New Polices</legend>
	<?php
	 $q='SELECT `policy_id`,`title`, `policy_type`, `description`  FROM `policy_table` where `active`=1 and policy_type="Four-wheeler"';
	 $res=mysql_query($q,$dbc);
	 ?>
	 <table><tr><th width="150">Policy</th><th width="150">Type</th><th width="250">description</th></tr>
	 <?php
	 while($row=mysql_fetch_array($res))
	 {
	 echo '<tr><td><input type="radio" required="required" name="poli" value="'.$row[0].'" />'.$row[1].'</td><td>'.$row[2].'</td><td>'.$row[3].'</td></tr>'; 
	 }
	?>
	</table>
    <input type="submit" name="submit" value="Submit" />
	</fieldset>
  </form>
<?php }include("down.php"); ?>