<?php include("up.php"); ?>
<title>Terms</title>
<b>Premium</b><br>
A premium is the amount of money paid to an insurance company in return for insurance protection.<br>

<b>Primary Residence</b><br>
A primary residence is the place where you will live for the majority of your policy term.<br>

<b>Primary Use</b><br>
Primary use is how you mainly use your vehicle. Primary use options include to/from work, business, pleasure or farm use.<br>

<b>Principal Driver</b><br>
The person who drives the car most often is the principal driver.<br>

<b>Property Damage Liability Coverage (PD)</b><br>
If an insured person is legally liable for an accident, PD coverage pays for damage to others' property resulting from the accident. PD also pays for legal defense costs if you are sued. Certain exclusions may apply. Refer to your policy.

<b>Rental Reimbursement Coverage</b><br>
Rental Reimbursement provides rental car coverage if you have a claim that is covered under Comprehensive or Collision coverage. Daily rental amounts are subject to the limit purchased.<br>

<b>Roadside Assistance Coverage</b><br>
Roadside Assistance provides services such as towing, flat tire change, locksmith service and battery jump-start to customers, who can elect the service for an additional premium if it is not already included with their insurance policy. <br>

<b>Salvage Titles</b><br>
State laws determine if a vehicle requires a salvage title.<br>
�	Some states base salvage titles on the extent of damage a vehicle has sustained. For example, in Louisiana, damage to a vehicle must equal or exceed 75 percent of the vehicle's retail value in order for it to require a salvage title, according to state law.
�	Other states, such as Florida, require a vehicle to have a salvage title if the insurance company declared the vehicle a total loss. These titles generally indicate whether the vehicle is "rebuildable" (can be repaired and driven on the road) or "not rebuildable" (must be sold for parts).<br>

<p><a href="terms2.php"> Previous </a> | <a href="terms4.php"> Next </a> </p>
<?php include("down.php"); ?>