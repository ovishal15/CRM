<?php include("up.php"); ?>
<title>View Feed Back</title>
<h1>Review's</h1>
<?php
	require("var/connect.php");
	$q="SELECT `feed_id`, `rate`, `description`, `id`, `type`, date FROM `feed_back_table` where approve=1 order by(date) DESC";
	$res=mysql_query($q,$dbc);
	echo '<table>';
	while($row=mysql_fetch_row($res)){
	echo '<tr><td>';
	if($row[4]=='customer'){
	$q1="SELECT `first_name`, `last_name`FROM `cust_table` WHERE cust_id=$row[3]";
	}
	else{
	$q1="SELECT `first_name`, `last_name`FROM `agent_table` WHERE agent_id=$row[3]";
	}	
	$res1=mysql_query($q1,$dbc);
	$row1=mysql_fetch_row($res1);
	echo "<b>Name:-</b> ".$row1[0].' '.$row1[1].'<br>';
	$rate=$row[1];
	$nrate=5-$rate;
	for($i=0;$i<$rate;$i++){echo '<img src="Images/star.png">';}
	for($i=0;$i<$nrate;$i++){echo '<img src="Images/nstar.png">';}
	echo '</td><td align="center" width="150">'.$row[2].'</td></tr>';
	}
	echo '</table>';
?>
<?php include("down.php"); ?>