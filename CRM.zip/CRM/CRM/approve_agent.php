<?php include("up.php"); require("admin_session.php");?>
<title>Approve Agent</title>
<?php
	require("var/connect.php");
  	 $error = 0;
	 if(!isset($_SESSION['aid']))
	 {
	 $q="SELECT `first_name`, `last_name`, `email_id`, `address`, `contact_no`, `agent_id` FROM `agent_table` WHERE `approve`=0";
	 $res=mysql_query($q,$dbc) or die("Problem in Access of data...............");
	 if(mysql_num_rows($res)>=1)
	 {
	 ?>
	 <table>
	 <tr><th width="100">Name</th><th width="150">E-mail Id</th><th width="150">Address</th><th width="200">Contact No</th><th>View Profile</th></tr>
	 <?php
	 $no=rand();
	 $_SESSION['key']=$no;
	 while($row=mysql_fetch_array($res)){
	 $v=$row[5]*$_SESSION['key'];
	 echo "<tr><td>$row[0] $row[1]</td>";
	 echo "<td>$row[2]</td>";
	 echo "<td>$row[3]</td>";
	 echo "<td>$row[4]</td>";
	 echo '<td><a href="view_agent.php?type=approve&vid='.$v.'">View Profile</a></td></tr>';
	 }
	  echo '</table>';
	 }
	 else {echo '<div class="warning">All curent agentes are approved early.........</div>';}
	 }
	else{
	$err=0;
	$agent_id = $_SESSION['aid'];
	unset($_SESSION['aid']);
	$q="UPDATE `agent_table` SET `approve`=1 where agent_id=$agent_id";
	mysql_query($q,$dbc) or $err=1;
	if($err==0){ echo '<div class="valid">Successful Approval of agent</div>';}
	else{echo '<div class="errors">Approval failed. Try Again........</div>';}
	}
?>
<?php include("down.php"); ?>