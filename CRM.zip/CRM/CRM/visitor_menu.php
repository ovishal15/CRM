<ul>
<li>
 <a class="menuitem submenuheader" href="">Get Quote</a>
<div class="submenu">
    <ul>
	<li><a href="two_get_quote.php">Two Wheeler</a></li>
	<li><a href="four_get_quote.php">Four Wheeler</a></li>
    </ul>
</div>
</li>
 <li><a href="cust_register.php">Customer Registration</a></li>
 <li><a href="agent_register.php">Agent Registration</a></li>
 <li><a href="login.php">Login</a></li>
 </ul>