<?php
  if ($_SESSION['type']!='agent') {
	 header('Location: http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/login.php');	
  }
	elseif(!isset($_SESSION['user_id']) && isset($_COOKIE['user_id'])){
	$_SESSION['user_id'] = $_COOKIE['user_id'];
    $_SESSION['username'] = $_COOKIE['username'];
	$_SESSION['type']="agent";
	}
?>