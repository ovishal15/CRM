<?php include("up.php"); require("admin_session.php");?>
<title>Add New Manufacturer<</title>
	<?php
	if(isset($_POST['submit']))
	{
	$err=0;
	require("var/connect.php");
	$type=$_POST['rt'];
	$manuf=$_POST['manuf'];
	$q='INSERT INTO `manufacturer_table`(`manufacturer_id`, `name`, `type`) VALUES (0,"'.$manuf.'",'.$type.')';
	mysql_query($q,$dbc) or $err=1;
	if($err==1){echo '<div class="error">New Manufacturer Susseccful not added</div>';}
	else{echo '<div class="valid">New Manufacturer Susseccful added</div>';}
	}
	else{
	?>
	<form action="add_manufacturer.php" method="post">
	<fieldset>
	<legend>Add New Manufacturer</legend>
	<label>Registration Type</label>
	<select name="rt" required="required">
	<option value="2">Tow-whiler</option>
	<option value="4">Four-whiler</option>
	</select><br>
	<label>*Manufacurer:</label><input type="text" name="manuf" required="required" /><br>
    <input type="submit" name="submit" value="Submit" />
    </label>
	</fieldset>
	</form>
<?php }include("down.php"); ?>
