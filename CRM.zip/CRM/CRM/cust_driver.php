<?php include("up.php"); require("comman_session.php"); include("chk_app.php");?>
<title>Add Driver</title>
<script type="text/javascript" src="JS/jquery-2.0.3.min.js"></script>
<script type="text/javascript">
function selectcity(state_id){
 if(state_id!="-1"){
   loadData(state_id);
   $("#city_dropdown").html("<option value='-1'>Select City</option>");
 }else{
   $("#city_dropdown").html("<option value='-1'>Select City</option>");
 }
}
function loadData(loadId){
  var dataString ='loadId='+ loadId;
  $("#city_loader").show();
	 $.ajax({
     type: "POST",
     url: "JS/loadcity.php",
     data: dataString,
     cache: false,
     success: function(result){
       $("#city_loader").hide();
       $("#city_dropdown").
       html("<option value='-1'>Select City</option>");
       $("#city_dropdown").append(result);
     }
   });
}
</script>
<script src="JS/driver_validate.js"></script>
<div id="errors"></div>
<?php
if(isset($_POST['submit']))
{
	$err=0;
	$tcost=$_POST['tcost'];
	$pid=$_POST['pid'];
	if($_SESSION['type']=='customer')
	$cust_id=$_SESSION['user_id'];
	else{
	$cust_id=$_SESSION['ccust_id'];
	unset($_SESSION['ccust_id']);
}
	$_SESSION['cclim']='INSERT INTO `claim_table`(`claim_id`, `policy_cust_id`, `total_cost`, `cust_id`) VALUES (0,'.$pid.','.$tcost.','.$cust_id.')';
	$_SESSION['cclima']='SELECT `claim_id` FROM `claim_table` WHERE `policy_cust_id`='.$pid.' and `total_cost`='.$tcost.' and `cust_id`='.$cust_id.'';
}
if(isset($_POST['submit']) && $err==0){
?>
<form action="cust_witness.php" method="post" onSubmit="return validate_form(this)">
<fieldset>
	<legend>Driver Details</legend>
	<label>*First Name</label><input type="text" name="fname" required="required"><br>
	<label>*Last Name</label><input type="text" name="lname" required="required"><br>
	<label>*Type</label><input type="text" name="tp" required="required"><br>
	<label>*Drug Influence</label><input type="radio" name="di" required="required" value="No">NO <input type="radio" name="di" value="Yes" required="required">Yes<br>
	<label>*Lic No</label><input type="text" name="licno" required="required"><br>
	<label>*Exp date</label><input type="date" name="edate" required="required"><br>
	<label>*Lic Type</label><input type="text" name="lictype" required="required"><br>
	<label>*Address </label><textarea name="add" required="required"></textarea><br />
<label>*State</label>
<select id="state_dropdown"  name="state" onChange="selectcity(this.options[this.selectedIndex].value)" required="required">
<option value="-1">Select State</option>
   	 <?php
	$q="SELECT `state_id`, `name` FROM `state_table`";
	$res=mysql_query($q,$dbc);
	while($row=mysql_fetch_array($res))
	{
	echo '<option value="'.$row[0].'">'.$row[1].'</option>';
	}
	?>
</select><br>
<label>*City</label>
<select id="city_dropdown" name="city" required="required">
<option value="-1">Select City</option>
</select><br />
<label>*Pincode</label><input type="text" name="pcode" required="required" /><br />
<label>*Contact No </label><input type="text" name="con_no" required="required" /><br />
<input type="submit" name="submit">
</fieldset>
</form>
<?php } include("down.php"); ?>