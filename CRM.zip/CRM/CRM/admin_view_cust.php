<?php include("up.php"); require("admin_session.php");?>
<title>View Customer</title>
<form action="admin_view_cust.php" method="get">
	<fieldset>
	<legend>Search Box</legend>
    <label for="usersearch">Find:</label>
    <input type="text" id="usersearch" name="search" /><br />
    <input type="submit" name="submit" value="Submit" />
	</fieldset>
  </form>
<?php
	require("var/connect.php");
	 $error = 0;
	 if(!empty($_GET['search'])){
	 $q="SELECT `first_name`, `last_name`, `email_id`, `address`, `contact_no`, `cust_id` FROM `cust_table` ";
	 $field=array('first_name', 'last_name', 'email_id', 'address', 'contact_no','state','city','residence_no','title');
	 $q = build_query($q,$_GET['search'],$field);
	 }
	 else{
	 $q="SELECT `first_name`, `last_name`, `email_id`, `address`, `contact_no`, `cust_id` FROM `cust_table`";
	 }
	 $res=mysql_query($q,$dbc) or die("Problem in Access of data...............");
	 if(mysql_num_rows($res)>=1)
	 {
	 ?>
	 <table>
	 <tr><th width="100">Name</th><th width="150">E-mail Id</th><th width="150">Address</th><th width="200">Contact No</th><th>View Profile</th></tr>
	 <?php
	 $no=rand();
	 $_SESSION['key']=$no;
	 while($row=mysql_fetch_array($res)){
	 $v=$row[5]*$_SESSION['key'];
	 echo "<tr><td>$row[0] $row[1]</td>";
	 echo "<td>$row[2]</td>";
	 echo "<td>$row[3]</td>";
	 echo "<td>$row[4]</td>";
	 echo '<td><a href="view_customer.php?vid='.$v.'">View Profile</a></td></tr>';
	 }
	  echo '</table>';
	  }
?>
<?php include("down.php"); ?>