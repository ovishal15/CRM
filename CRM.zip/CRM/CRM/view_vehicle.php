<?php include("up.php");  require("admin_session.php");?>
<?php
	if(isset($_SESSION['key'])){
	$err=0;
	require("var/connect.php");
	$vid=$_GET['vid']/$_SESSION['key'];
	unset($_SESSION['key']);
	$q="SELECT `rto`, `class`, `manufacture`, `model`, `milege`, `chasis_no`, `reg_type`, `reg_date`, `age_vehicle`, `idv`, `ele_acc`, `nele_acc`, `cli`, `clc`, `no_pa`, `cc` FROM `vehicle_table` WHERE `vehicle_id`=$vid";
	$data=mysql_query($q,$dbc)or $err=1;
	if(mysql_num_rows($data)==1)
	{
			$row=mysql_fetch_array($data);
		?>
			<fieldset>
			<legend>View Vehicle</legend>
			<label>User Name:</label><?php echo $_GET['username'];?><br />
			<label>RTO:</label><?php echo $row[0];?><br />
			<label>Registration Type:</label><?php echo $row[6].'Wheeler';?><br />
			<label>Class:</label><?php echo $row[1];?><br />
			<label>Manufacture:</label><?php echo $row[2];?><br />
			<label>Model:</label><?php echo $row[3];?><br />
			<label>Milege:</label><?php echo $row[4];?><br />
			<label>Chsis_no:</label><?php echo $row[5];?><br />
			<label>Age of Vehicle:</label><?php echo $row[8];?><br />
			<label>IDV:</label><?php echo $row[9];?><br />
			<label>CC:</label><?php echo $row[15];?><br />
			<label>ELE. ACC FITING VALUE:</label><?php echo $row[10];?><br />
			<label>NON- ELE.ACC. VALUE:</label><?php echo $row[11];?><br />
			<label>CNG / LPG Inbult:</label><?php echo $row[12];?><br />
			<label>CNG / LPG COST AMT:</label><?php echo $row[13];?><br />
			<label>NO. OF PA PASSENGER:</label><?php echo $row[14];?><br />
			<label>Registration Date</label><?php echo $row[7];?><br /><br />
			<a href="approve_policy.php">Back to Approve Policy</a>
	</fieldset>
	<?php
	}
	else{$err=1;}
	if($err==1)	echo '<div class="error">Problem to view proifle.</div>';
	}
	else{echo '<div class="error">NO customer Vehicle select.</div>';}
?>
<?php include("down.php"); ?>