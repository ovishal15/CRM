<?php
	require("var/connect.php");
	if(isset($_SESSION['user_id']) || isset($_COOKIE['user_id']))
	{
		if($_SESSION['type']=='customer')
		{
			$q='SELECT `approve` FROM `cust_table` WHERE `cust_id`='.$_SESSION['user_id'].'';
			$res=mysql_query($q,$dbc);
			$row=mysql_fetch_array($res);
			if($row[0]==0)
			{
				header('Location: http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/error.php');
			}
		}
		elseif($_SESSION['type']=='agent')
		{
			$q='SELECT `approve` FROM `agent_table` WHERE `agent_id`='.$_SESSION['user_id'].'';
			$res=mysql_query($q,$dbc);
			$row=mysql_fetch_array($res);
			if($row[0]==0)
			{
				header('Location: http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/error.php');
			}
		}
	}
?>