<?php include("up.php"); require("comman_session.php");?>
<title>View Profile</title>
<?php
	$err=0;
	require("var/connect.php");
	$cust_id=$_SESSION['user_id'];
	if($_SESSION['type']=='customer')
	$q="SELECT `title`, `first_name`, `last_name`, `dob`, `email_id`, `picture`,`address`, `city`, `pincode`, `state`, `contact_no`, `residence_no` FROM `cust_table` WHERE `cust_id`='".$cust_id."'";
	else
	$q="SELECT `title`, `first_name`, `last_name`, `dob`, `email_id`, `picture`,`address`, `city`, `pincode`, `state`, `contact_no`, `residence_no` FROM `agent_table` WHERE `agent_id`='".$cust_id."'";
	$data=mysql_query($q,$dbc)or $err=1;
	if(mysql_num_rows($data)==1)
	{
		$row=mysql_fetch_array($data);
			$title=$row[0];	$fname=$row[1];	$lname=$row[2];	$bod=$row[3];$email=$row[4];$pic=$row[5];$add=$row[6];$pcode=$row[8];$con_no=$row[10];$res_no=$row[11];
		$q1="select st.name as state_name,ct.name as city_name from state_table as st inner join city_table as ct where ct.city_id='".$row[7]."' and st.state_id='".$row[9]."'";
		$res1=mysql_query($q1,$dbc);
		$row1=mysql_fetch_array($res1);
		$state=$row1[0];
		$city=$row1[1];
	}
	else{$err=1;}
	if($err==0){
	?>
	<fieldset>
			<legend>View Profile</legend>
			<table>
			<tr>
			<td>
			<label>Name:</label><?php echo $fname.' '.$lname;?><br />
			<label>E-mail ID:</label><?php echo $email;?><br />
			<label>Title:</label><?php echo $title;?><br />
			<label>Date of Birth:</label><?php echo $bod;?><br />
			<label>Contect No:</label><?php echo $con_no;?><br />
			<label>Residence No:</label><?php echo $res_no;?><br />
			<label>Address:</label><?php echo $add;?><br />
			<label>Pincode:</label><?php echo $pcode;?><br />
			<label>State:</label><?php echo $state;?><br />
			<label>City:</label><?php echo $city;?><br />
			</td>
			<td align="center">
			<label>Profile Picture:</label></td><td><img src="<?php echo  up_path.$pic; ?>"  width="200" height="200" />
			</td>
			</tr>
			</table>
	</fieldset>
	<?php
	}
	else 
	{
		echo '<p class="error">Problem to using your proifle.</p>';
	}
	
	
?>
<?php include("down.php"); ?>