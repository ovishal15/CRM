<?php include("up.php"); ?>
<script src="JS/contact_validate.js" type="text/javascript"></script>
<title>Contact Us</title>
<?php
	$err=0;
	if(isset($_POST['submit']))
	{
		require("var/connect.php");
		$name=$_POST['name'];
		$con_no=$_POST['con_no'];
		$email=$_POST['email'];
		$msg=$_POST['msg'];
		$q='INSERT INTO `contact_table`(`contact_id`, `name`, `email_id`, `contact_no`, `message`,date) VALUES (0,"'.$name.'","'.$email.'",'.$con_no.',"'.$msg.'",now())';
		mysql_query($q,$dbc) or ($err=1);
		if($err==1){echo '<div id="errors" class="error">Sorry, due to some problem please Try Again.</div>';}
		else{echo '<div id="errors" class="valid">Thank you for submition we contact you sortly.</div>';}
	}
	if(!isset($_POST['submit']) || $err==1){
?>
<h2>Contact Form</h2>
<div id="errors"></div>
<form action="contact_us.php" method="post" onSubmit="return validateForm(this);">
     <fieldset>
       <label>Name:-</label><input type="text" name="name" required="required"><br>
	   <label>Email-ID:-</label><input type="text" name="email" required="required"><br>
	   <label>Contact No:-</label><input type="text" name="con_no" required="required"><br>
	   <label>Message:-</label><textarea name="msg" required="required"></textarea><br>
	   <input type="submit" name="submit">
     </fieldset>  
</form> 
<?php } include("down.php"); ?>