<?php include("up.php"); ?>
<title>Terms</title>
<b>Limits</b><br>
An insurance coverage limit is selected by you and is the most an insurance company will pay for damages or injuries that apply to the coverage. Most states have laws that specify the minimum limit that must be purchased for each required insurance coverage.<br>

<b>Loan/Lease Payoff Coverage</b><br>
Loan/Lease Payoff coverage, sometimes called "gap" coverage, pays the difference between what you owe on your vehicle and what your insurance pays if your vehicle is declared a total loss or stolen and not recovered, less your Comprehensive or Collision deductible.<br>

<b>Named Insured</b><br>
The first person in whose name the insurance policy is issued.<br>

<b>Medical Payments (MedPay) Coverage</b><br>
MedPay is an optional insurance coverage that pays for reasonable and necessary medical and funeral expenses for covered persons. These expenses must be incurred as a result of an auto accident.<br>

<b>Occasional Driver</b><br>
A person who is not the primary or principal driver of the insured vehicle is an occasional driver.<br>

<b>Personal Injury Protection (PIP) Coverage</b><br>
PIP is a coverage in which the auto insurance company pays, within the specified limits, the medical, hospital and funeral expenses of the insured person, people in the insured vehicle and pedestrians struck by the insured vehicle. PIP is the basic coverage implemented in no-fault automobile insurance states.<br>

<b>Policy Expiration Date</b><br>
Your current insurance policy ends on your policy expiration date, which is found on your current policy documents, Declarations Page (Dec Page), insurance identification card or recent cancellation notice. This date should not be confused with payment due dates.<br>

<b>Policy Term</b><br>
The length of time your policy is active and in force is your policy term.<br>

<p><a href="terms1.php"> Previous </a> | <a href="terms3.php"> Next </a> </p>
<?php include("down.php"); ?>