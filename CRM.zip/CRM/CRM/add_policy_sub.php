<?php include("up.php"); require("admin_session.php");?>
<title>Add Policy</title>
<?php
	require("var/connect.php");
  	 $error = 0;
	if(isset($_POST['sub']))
	{
		$e=0;
		$title=$_POST['title'];
		$desc=$_POST['desc'];
		$ptype=$_POST['ptype'];
		$cover=$_POST['cover'];
		$dis=$_POST['dis'];
		
		$q="INSERT INTO `policy_table`(`title`, `description`, `policy_id`, `policy_type`, `issued_date`, `fixed_cover`,`discount`) VALUES ('".$title."', '".$desc."', 0, '".$ptype."',NOW(),'".$cover."','".$dis."')";
		mysql_query($q,$dbc) or $e=1;

			
			
		if($e==0){
			echo '<div class="valid">Success fuly Submited</div>';
		}
		else
		{
			echo '<div class="error">not Success fuly Submited</div>';
		}
}

//First this if executed to view data
		if(isset($_POST['submit']))
		{
			$title=$_POST['title'];
			$desc=$_POST['desc'];
			$ptype=$_POST['ptype'];
			$cover=$_POST['cover'];
			?>
			<fieldset>
			<legend>Conform Data</legend>
			<label>Title:</label><?php echo $title;?><br />
			<label>Policy details:</label><?php echo $desc;?><br />
			<label>Policy type:</label><?php echo $ptype;?><br />
			<label>Fixed cover:</label><?php echo $cover;?><br />
						
			<form action="add_policy_sub.php" method="post">
			<?php
			echo '<input type="hidden" name="title" value="'.$title.'" />';
			echo '<input type="hidden" name="desc" value="'.$desc.'" />';
			echo '<input type="hidden" name="ptype" value="'.$ptype.'" />';
			echo '<input type="hidden" name="cover" value="'.$cover.'" />';
			?>
			<input type="submit" name="sub" />
			</fieldset>
			</form>
			<?php
		}
		
?>
	
<?php include("down.php"); ?>