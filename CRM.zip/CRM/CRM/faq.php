<?php include("up.php"); ?>
<title>FAQ</title>
<form action="faq.php" method="get">
	<fieldset>
	<legend>FAQ Search Box</legend>
    <label for="usersearch">Find Your FAQ:</label>
    <input type="text" id="usersearch" name="usersearch" /><br />
    <input type="submit" name="submit" value="Submit" />
	</fieldset>
  </form>

<?php
	require("var/connect.php");
  	if(isset($_GET['usersearch']))
	{
	  $user_search = $_GET['usersearch'];
	}
	else{
	  $user_search = '';
	}

  // Calculate pagination information
  $cur_page = isset($_GET['page']) ? $_GET['page'] : 1;
  $results_per_page = 5;  // number of results per page
  $skip = (($cur_page - 1) * $results_per_page);

  
  // Query to get the total results 
  $q='SELECT * FROM faq_table';
  $q = build_query($q,$user_search,'qus');
  $res = mysql_query($q,$dbc);
  $total = mysql_num_rows($res);
  $num_pages = ceil($total / $results_per_page);

  // Query again to get just the subset of results
  $q =  $q . " LIMIT $skip, $results_per_page";
  $result = mysql_query($q,$dbc);
  while ($row = mysql_fetch_array($result)) {
  echo '<table>';
  echo '<tr align="left"><th>'.$row['qus'].'</th></tr>';
  echo '<tr><td>'.$row['ans'].'</td></tr>';
  echo '</table>';
  } 
  

  // Generate navigational page links if we have more than one page
  if ($num_pages > 1) {
    echo generate_page_links($user_search, $cur_page, $num_pages);
  }

?>
<?php include("down.php"); ?>