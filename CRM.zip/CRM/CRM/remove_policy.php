<?php include("up.php"); require("admin_session.php");?>
<title>Remove Policy</title>
  <?php
  require("var/connect.php");
  	 $error = 0;
  if(isset($_POST['submit']))
  {
  $poli=$_POST['poli'];
  foreach($poli as $p){
  	$q='UPDATE `policy_table` SET `active`=0 WHERE `policy_id`='.$p;
	mysql_query($q,$dbc) or die($error=1);
  	}
	if($error==0){
			echo "Successfully Deactive policy.";
		}
		else
		{
			echo '<div class="error">not Successfully deactive policy.</div>';
		}
  }
  ?>
  
  
<form action="remove_policy.php" method="post">
	<fieldset>
	<legend>Remove Polices</legend>
	<?php
	 $q='SELECT `policy_id`,`title`, `policy_type`, `description`  FROM `policy_table` where `active`=1';
	 $res=mysql_query($q,$dbc);
	 ?>
	 <table><tr><th width="150">Policy</th><th width="150">Type</th><th width="250">description</th></tr>
	 <?php
	 while($row=mysql_fetch_array($res))
	 {
	 echo '<tr><td><input type="checkbox" name="poli[]" value="'.$row[0].'" />'.$row[1].'</td><td>'.$row[2].'</td><td>'.$row[3].'</td></tr>'; 
	 }
	?>
	</table>
    <input type="submit" name="submit" value="Submit" />
	</fieldset>
  </form>
<?php include("down.php"); ?>