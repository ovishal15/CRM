<?php include("up.php"); ?>
<title>About Us</title>
<style type="text/css">
<!--
.style1 {
	font-size: 36px;
	font-weight: bold;
}
.style2 {font-size: 16px}
.style3 {font-size: 24px}
-->
</style>

<span class="style1">About us: </span><br>
<div>
  <p>&nbsp;</p>
  <p>
    <input type="image" name="imageField" src="Images/about.jpg" />
    <span class="style2"> Customer RelationshipManagment for generl insurance(VEHICLE)</span> </p>
  <p>&nbsp;</p>
  <p class="style3">As the name suggest system manages all the relationship of costumer for company.<br />
    This  system help the insurance company to provide best opportunity to deal good relationship with customers.<br />
    This system also provide best view to customer for dealing in vehicle insurance at a detailed level.<br />
    It helps customer to create a friendly and stress less  environment related to vehicle insurance.<br />
    Costumer Relationship Management is core of any companies.<br />
    This is important because it is related to costumer and provided services.<br />
    Our system is manages all the information related to insurance polices.<br />
  Our system is provide best way to take insurance polices to costumer.</p>
  <p class="style3">
    THANK YOU <br />
  </p>
</div>
<?php include("down.php"); ?>