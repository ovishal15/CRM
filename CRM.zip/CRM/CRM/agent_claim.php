<?php include("up.php"); require("agent_session.php");?>
<title>Add Claim</title>
<?php
	require("var/connect.php");
  	 $err = 0;
	 $cust_id=$_POST['cust_id'];
	$q1="SELECT `policy_id` FROM `policy_cust_table` WHERE cust_id=$cust_id and approve=1";
	 $res1=mysql_query($q1,$dbc);
	 if(mysql_num_rows($res1)>=1)
	 {
	 ?>
<script src="JS/claim_validate.js"></script>
<div id="errors"></div>
<form name="log" action="agent_driver.php" method="post" onSubmit="return validate_form(this)">
<label>Total cost</label><input type="text" name="tcost" required="required" />
<?php
  	 $error = 0;
	$q1="SELECT `policy_id` FROM `policy_cust_table` WHERE cust_id=$cust_id and approve=1";
	 $res1=mysql_query($q1,$dbc);
	 while($row1=mysql_fetch_row($res1)){
	 $pid=$row1[0];
	$q='SELECT `policy_id`,`title`,`policy_type`, `description`, `premium`,  `fixed_cover` FROM `policy_table` where policy_id='.$pid.'';
	 $res=mysql_query($q,$dbc);
	 ?>
	 <table><tr><th width="150">Policy</th><th width="150">Type</th><th width="250">description</th></tr>
	 <?php
	 while($row=mysql_fetch_array($res))
	 {
	 echo '<tr><td><input type="radio" required="required" name="pid" value="'.$row[0].'" />'.$row[1].'</td><td>'.$row[2].'</td><td>'.$row[3].'</td></tr>'; 
	 }
	 }
	?>
	</table>
	<input type="hidden" name="cust_id" value="<?php echo $cust_id;?>">
<input type="submit" name="submit" value="Submit" />
</form>
<?php }	 else{	 echo "Your policy not approved yet";}include("down.php"); ?>