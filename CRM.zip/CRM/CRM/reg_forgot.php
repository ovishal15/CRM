<?php include("up.php"); ?>
<title>user forgot Password</title>
<?php
$err=0;
	$ans="";
	$user_id="";
	$qus="";
	if(isset($_POST['submit']))
	{
	require("var/connect.php");
	$email=$_POST['email'];
	$con_no=$_POST['con_no'];
	$q="SELECT `cust_id` FROM `cust_table` WHERE contact_no=$con_no and `email_id`='".$email."'";
	$data=mysql_query($q,$dbc) or $err=1;
	if(mysql_num_rows($data)==1 && $err!=1)
	{
	$row=mysql_fetch_array($data);
	$user_id=$row[0];
	$type="customer";
	}
	else{
	$q="SELECT `agent_id` FROM `agent_table` WHERE contact_no=$con_no and `email_id`='".$email."'";
	$data=mysql_query($q,$dbc) or $err=1;
	$row=mysql_fetch_array($data);
	$user_id=$row[0];
	$type="agent";
	}
	
	if($err==0)
	{
	$q1="SELECT `log_in_id`,`qus`, `ans` FROM `login_table` WHERE user_id=$user_id and type='".$type."'";
	$data1=mysql_query($q1,$dbc) or $err=1;
	if($err!=1)
	{
	if(mysql_num_rows($data1)==1)
	{
	$row=mysql_fetch_array($data1);
	$_SESSION['lid']=$row[0];
	$qus=$row[1];
	$_SESSION['cans']=$row[2];
	}
	}
	}
	if($err==1 || $_SESSION['cans']=="")
	{
	echo '<div id="errors">Plese enter correct information<br><a href="for_pass.php">Click Here to enter data</a>.</div>';
	}
	else{
	?>
	<div id="errors"></div>
	<script src="JS/for_validate.js"></script>
<form action="reg_forgot_sub.php" method="post" onSubmit="return vali_ans(this.ans)">
<fieldset>
<legend>Forgot password details</legend>
<label>Security Qusition</label><label><?php echo $qus; ?></label><br>
<label>*Security Answer</label><input type="text" name="ans" required="required"><br>
<input type="submit" value="Next" name="submit">
</fieldset>
</form>	
	<?php
	}
}
 	?>
<?php include("down.php"); ?>