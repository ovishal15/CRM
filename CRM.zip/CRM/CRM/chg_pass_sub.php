<?php include("up.php"); require("comman_session.php");?>
	<title>Change Password</title>
	<script src="JS/chg_validate.js"></script>
	<?php
	require("var/connect.php");
  	 $error = 0;
	if(isset($_POST['submit']))
	{
	$pass=$_POST['pass'];
	$q="SELECT `email_id` FROM `login_table` WHERE `user_id`='".$_SESSION['user_id']."' && `type`='".$_SESSION['type']."' && `password`=SHA('".$pass."')";
	$data=mysql_query($q,$dbc) or $error=1;
		if(mysql_num_rows($data)!=1){$error=1;}
	}
	
	
	if(isset($_POST['sub']) && $error==0)
	{
	$pass=$_POST['pass'];
	$q1="UPDATE `login_table` SET `password`=SHA('".$pass."') WHERE `user_id`='".$_SESSION['user_id']."'";
	if(mysql_query($q1,$dbc)){
	echo '<div class="valid">Successfully updated your password.</div>';
	}
	
	else{
	echo '<div class="error">Sorry.....Problem in changing your password.Please do all process again.</div>';
	}
}
	if($error==0 && isset($_POST['submit']))
	{
	?>
	<div id="errors"></div>
	<fieldset>
	<legend>Change Password</legend>
	<form action="chg_pass_sub.php" method="post" onSubmit="return validateForm(this)">
	<label>*New Password</label><input type="password" name="pass" required="required"><br>
	<label>*Conform New Password</label><input type="password" name="con_pass" required="required"><br>
	<input type="submit" name="sub">
	</fieldset>
	</form>
	<?php
	}
	if($error==1)
	{
		echo '<div class="error">You enter wrong Password.......<br>For Re-enter Password <a href="chg_pass.php">Click Here</a></div>';
	}
	?>
<?php include("down.php"); ?>