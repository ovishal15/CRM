<?php include("up.php"); require("admin_session.php");?>
<title>View Claims</title>
<?php
	require("var/connect.php");
	 $error = 0;
	 $q='SELECT `claim_id`, `policy_cust_id`, `cust_id`, `total_cost` FROM `claim_table` WHERE `approve`=0';
	 $res=mysql_query($q,$dbc) or die("Problem in Access of data...............");
	 if(mysql_num_rows($res)>=1)
	 {
	 ?><table><tr><th width="80">Claim_no</th><th width="150">Customer Name</th><th width="150">E-mail</th><th width="150">Chasis No</th><th>Total Cost</th><th>Full Detail</th></tr>
	 <?php
	 	$no=rand();
		$_SESSION['key']=$no;
	 	while($row=mysql_fetch_array($res)){
		$cid=$row[0];
		$pcid=$row[1];
		$v=$cid*$no;
		$cust_id=$row[2];
		$tot=$row[3];
		$q1='SELECT `first_name`, `last_name`, `email_id` FROM `cust_table` WHERE cust_id='.$cust_id.'';
		$res1=mysql_query($q1,$dbc);
		$row1=mysql_fetch_array($res1);
		$fname=$row1[0];
		$lname=$row1[1];
		$email=$row1[2];
		$q3='SELECT `vehicle_id` FROM `policy_cust_table` WHERE `policy_cust_id`='.$pcid.'';
		$res3=mysql_query($q3,$dbc);
		$row3=mysql_fetch_array($res3);
		$vid=$row3[0];
		$q2='SELECT `chasis_no` FROM `vehicle_table` WHERE vehicle_id='.$vid.'';
		$res2=mysql_query($q2,$dbc);
		$row2=mysql_fetch_array($res2);
		$cn=$row2[0];
		echo '<tr><td>'.$cid.'</td><td>'.$fname.' '.$lname.'</td><td>'.$email.'</td><td>'.$cn.'</td><td>'.$tot.'</td><td><a href="view_claim.php?cid='.$v.'">View</a></td></tr>';
		}
	}
?>
</table>
<?php include("down.php"); ?>