<?php include("up.php");?>
<title>View New Polices</title>
	<fieldset>
	<legend>View New Polices</legend>
	<?php
	require("var/connect.php");
  	 $error = 0;
	$q='SELECT `title`,`policy_type`, `description`, `fixed_cover` FROM `policy_table` where `active`=1 ORDER BY issued_date';
	 $res=mysql_query($q,$dbc);
 	 
 	 while($row=mysql_fetch_array($res)){
	echo '<fieldset style="border:double 1px"><legend>'.$row[0].'</legend>';
	 echo '<label>Policy</label><td>'.$row[0].'<br>';
	 echo '<label>Type</label><td>'.$row[1].'<br>';
	 echo '<label>Description</label><td>'.$row[2].'<br>';
	 echo '<label>Fixed Cover</label>'.$row[3].'<br>';
	 echo '</fieldset>';
	 }
	 
	?>
	</fieldset>
<?php include("down.php"); ?>