<ul>
<li><a href="view_profile.php" >View Profile</a></li>
<li><a href="edit_profile.php" >Edit Profile</a></li>
<li><a href="cust_policy.php" >View Current Policy</a></li>
<li>
<a class="menuitem submenuheader" href="">Get Quote</a>
<div class="submenu">
    <ul>
	<li><a href="two_get_quote.php">Two Wheeler</a></li>
	<li><a href="four_get_quote.php">Four Wheeler</a></li>
    </ul>
</div>
</li>
<li>
<a class="menuitem submenuheader" href="">Buy New Policy</a>
<div class="submenu">
    <ul>
	<li><a href="cust_buy_two_policy.php">Two Wheeler</a></li>
	<li><a href="cust_buy_policy.php">Four Wheeler</a></li>
    </ul>
</div>
</li>
<li><a href="cust_renew_policy.php" >Re New Policy</a></li>
<li><a href="cust_claim.php" >Claim Policy</a></li>
<li><a href="give_feed_back.php" >Give Feed Back</a></li>
<li><a href="chg_pass.php" >Change Password</a></li>
<li><a href="log_out.php" >Log Out</a></li>
</ul>