<?php include("up.php"); require("comman_session.php"); include("chk_app.php");?>
<title>Add Accident</title>
<script src="JS/accident_validate.js"></script>
<?php
if(isset($_POST['submit']))
{
$err=0;
$fname=$_POST['fname'];
$dob=$_POST['dob'];
$desc=$_POST['desc'];
$add=$_POST['add'];
$pcode=$_POST['pcode'];
$state=$_POST['state'];
$city=$_POST['city'];
$con_no=$_POST['con_no'];
$_SESSION['cthird']='INSERT INTO `third_party_table`(`third_party_id`, `name`, `description`, `dob`, `address`, `city`, `pincode`, `state`, `contact_no`, `claim_id`) VALUES (0,"'.$fname.'","'.$desc.'","'.$dob.'","'.$add.'",'.$city.','.$pcode.',"'.$state.'",'.$con_no.',claim_no)';
}
if(isset($_POST['submit']) && $err==0){
?>

<div id="errors"></div>
<form method="post" action="cust_accident_sub.php" onSubmit="return validate_form(this)">
<fieldset>
	<legend>Accident Details</legend>
	<label>*Police Station</label><input type="text" name="pname" required="required"><br>
	<label>*Police Attender</label><input type="text" name="aname" required="required"><br>
	<label>*Description </label><textarea name="desc" required="required"></textarea><br />
	<input type="submit" name="submit">
</fieldset>
</form>
<?php }include("down.php"); ?>