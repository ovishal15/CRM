<?php include("up.php"); require("comman_session.php"); include("chk_app.php");?>
<title>Add Claim</title>
<?php
  	 $error = 0;
	 if($_SESSION['type']=='customer')
	 $cust_id=$_SESSION['user_id'];
	 elseif($_SESSION['type']=='agent'){ 
	  $cust_id=$_POST['cust_id'];
	 $_SESSION['ccust_id']=$cust_id;
	 }
	$q1="SELECT `policy_cust_id` FROM `policy_cust_table` WHERE cust_id=$cust_id and approve=1";
	 $res1=mysql_query($q1,$dbc)or die($q1);
	 if(mysql_num_rows($res1)>=1)
	 {
	 ?>
<script src="JS/claim_validate.js"></script>
<div id="errors"></div>
<form name="log" action="cust_driver.php" method="post" onSubmit="return validate_form(this)">
<label>Total cost</label><input type="text" name="tcost" required="required" />
	 <table><tr><th width="150">Policy</th><th width="250">Policy No</th><th width="150">Type</th><th width="250">description</th></tr>
	 <?php
	 while($row1=mysql_fetch_row($res1)){
	 $pcid=$row1[0];
	 	$q2='SELECT `policy_id` FROM `policy_cust_table` WHERE `policy_cust_id`='.$pcid;
		$res2=mysql_query($q2,$dbc);
			while($row2=mysql_fetch_array($res2))
			{
			$pid=$row2[0];
			$q='SELECT `title`,`policy_type`, `description` FROM `policy_table` where policy_id='.$pid.'';
			$res=mysql_query($q,$dbc);
				if(mysql_num_rows($res)>=1)
				{
					while($row=mysql_fetch_array($res))
					{
	 				echo '<tr><td><input type="radio" required="required" name="pid" value="'.$pcid.'" />'.$row[0].'</td><td>'.$pcid.'</td><td>'.$row[1].'</td><td>'.$row[2].'</td></tr>'; 
					}
				 }
				 else{
				 echo '<div class="error">You not buy any policy</div>';
				 }
			 }
	 }
	?>
	</table>
<input type="submit" name="submit" value="Submit" />
</form>
<?php
}
else{	 echo '<div class="warning">Your policy not approved yet</div>';}
include("down.php"); ?>