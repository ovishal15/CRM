<?php include("up.php"); require("comman_session.php");?>
<title>Change Password</title>
	<fieldset>
	<legend>Change Password</legend>
	<form action="chg_pass_sub.php" method="post">
	<label>*Current Password</label><input type="password" name="pass" required="required"><br />
	<input type="submit" name="submit">
	</fieldset>
	</form>
<?php include("down.php"); ?>