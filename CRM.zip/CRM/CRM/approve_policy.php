<?php include("up.php"); require("admin_session.php");?>
<title>Approve Policy</title>
 <?php
  require("var/connect.php");
  	 $error = 0;
  if(isset($_POST['submit']))
  {
  $poli=$_POST['poli'];
  foreach($poli as $p){
  	$q='UPDATE `policy_cust_table` SET approve=1 WHERE `policy_cust_id`='.$p;
	mysql_query($q,$dbc) or die($error=1);
	
	$q1='SELECT `policy_id`,`cust_id`,`premium`  FROM `policy_cust_table` WHERE `policy_cust_id`='.$p;
	$res1=mysql_query($q1,$dbc) or die($error=1);
	$row1=mysql_fetch_array($res1);
	$pid=$row1[0];
	$cust_id=$row1[1];
	$pay=$row1[2];
	$q3='INSERT INTO `payment_table`(`payment_id`, `payment_amount`, `payment_date`, `policy_id`, `cust_id`) VALUES (0,'.$pay.',now(),'.$pid.','.$cust_id.')';
	mysql_query($q3,$dbc) or die($error=1);
	
  	}
	if($error==0){
			echo '<div class="valid">Success fuly approve policy.</div>';
		}
		else
		{
			echo '<div class="error">not Success fuly approve policy.</div>';
		}
  }
  else{
	 $q='SELECT pc.`policy_cust_id`, pt.`title`,pc.`premium`, cu.`first_name`,cu.`last_name`,cu.`contact_no`,pc.`vehicle_id` FROM `policy_cust_table` as pc '.
	 'INNER JOIN cust_table AS cu USING (cust_id) INNER JOIN policy_table AS pt USING (policy_id) WHERE pc.approve=0';
	 $res=mysql_query($q,$dbc);
	 if(mysql_num_rows($res)>=1)
	 {
	 ?>
	 <form action="approve_policy.php" method="post">
	<fieldset>
	<legend>Approve Polices</legend>
	 <table><tr><th width="150">Policy</th><th width="150">Premium</th><th width="150">Name</th><th width="150">Contact No</th><th>View Vehicle</th></tr>
	 <?php
	 $no=rand();
	 $_SESSION['key']=$no;
	 while($row=mysql_fetch_array($res)){
	 $v=$row[6]*$_SESSION['key'];
	 echo '<tr><td><input type="checkbox" name="poli[]" value="'.$row[0].'" />'.$row[1].'</td><td>'.$row[2].'</td><td>'.$row[3].' '.$row[4].'</td><td>'.$row[5].'</td><td><a href="view_vehicle.php?username='.$row[3].' '.$row[4].'&vid='.$v.'">View Vehicle</a></td></tr>'; 
	 }
	?>
	</table>
    <input type="submit" name="submit" value="Submit" />
	</fieldset>
  </form>
<?php }	 else {echo '<div class="warning">All polices are approved early.........</div>';} }include("down.php"); ?>