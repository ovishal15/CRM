<?php include("up.php"); ?>
<title>Privacy</title>
<h1 class="title" style="font-size: 36px;font-weight: bold;">Privacy </h1><br>
<div>
    <input type="image" name="imageField" src="Images/about.jpg" /><br />
    <h1 class="title" style="font-size: 16px;font-weight: bold;"> Customer Relationship Managment for VEHICLE insurance</h1>
	
  <h1 class="title">Log Files</h2>
  <p class="style4">As is true of most Web sites, we gather certain information automatically and store it in log files. This information includes internet protocol (IP) addresses, browser type, internet service provider (ISP), referring/exit pages, operating system, date/time stamp, and clickstream data.</h1>
  <p class="style4">We use this information, which does not identify individual users, to analyze trends, to administer the site, to track users movements around the site and to gather demographic information about our user base as a whole.</p>
  
  <h1 class="title">Use of Cookies</h1>
  <p class="style4">We store a cookie on your computer when you visit our Web site. A cookie is a small text file that is stored on a users computer for record-keeping purposes. The primary purpose of these cookies is to analyze how users move within our Web site. Our cookies let you view customized pages while transacting with us. Our cookies do not have confidential or personally identifiable information.</p>
  
  <h1 class="title">Updating your personal information</h1>
  <p class="style4">If you need to update your personal information or there is any change in the personal information, or if you no longer desire our service, you may update or delete on our page.</p>
  
  <h1 class="title">Security</h1>
  <p class="style4">The security of your personal information is important to us. When you enter sensitive information such as credit card number on our registration or order forms.</p>
  
  <h1 class="title">Changes in this Privacy Statement</h1>
  <p class="style4">We reserve the right to modify this privacy statement at any time by posting the same on the Website, so please review it frequently on the Website. If we materially change our privacy practices we will notify you by sending an email or by posting a notice on our web site.<br />
  </p>
</div>
<?php include("down.php"); ?>