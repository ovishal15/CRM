<?php include("up.php");  require("admin_session.php");?>
<?php
if(isset($_SESSION['key'])){
	$err=0;
	require("var/connect.php");
	$cid=$_GET['cid']/$_SESSION['key'];
	unset($_SESSION['key']);
	$q='SELECT `first_name`, `last_name`, `type`, `drug_influence`, `lic_no`, `exp_date`, `lic_type`, `address`, `city`, `pincode`, `state`, `contact_no` FROM `driver_table` WHERE `claim_id`='.$cid.'';
	$data=mysql_query($q,$dbc)or $err=1;
	if(mysql_num_rows($data)==1)
	{
		$row=mysql_fetch_array($data);
		$q1='select st.name,ct.name from state_table as st inner join city_table as ct using(state_id) where ct.state_id='.$row[10].' and ct.city_id='.$row[8].'';
			$res1=mysql_query($q1,$dbc) or $err=1;
			$row1=mysql_fetch_array($res1);
			$state=$row1[0];
			$city=$row1[1];
		?>
		<fieldset>
		<legend>Driver Details</legend>
		<label>First Name</label><?php echo $row[0]; ?><br>
		<label>Last Name</label><?php echo $row[1]; ?><br>
		<label>Type</label><?php echo $row[2]; ?><br>
		<label>Drug Influence</label><?php echo $row[3]; ?><br>
		<label>Lic No</label><?php echo $row[4]; ?><br>
		<label>Exp date</label><?php echo $row[5]; ?><br>
		<label>Lic Type</label><?php echo $row[6]; ?><br>
		<label>Address </label><?php echo $row[7]; ?><br>
		<label>State</label><?php echo $state; ?><br>
		<label>City</label><?php echo $city; ?><br>
		<label>Pincode</label><?php echo $row[9]; ?><br>
		<label>Contact No </label><?php echo $row[11]; ?><br>
		</fieldset>
		<?php
	}
	
	$q='SELECT `name`, `dob`, `address`, `city`, `pincode`, `state`, `contact_no`FROM `witness_table` WHERE `claim_id`='.$cid.'';
	$data=mysql_query($q,$dbc)or $err=1;
	if(mysql_num_rows($data)==1)
	{
		$row=mysql_fetch_array($data);
		$q1='select st.name,ct.name from state_table as st inner join city_table as ct using(state_id) where ct.state_id='.$row[5].' and ct.city_id='.$row[3].'';
			$res1=mysql_query($q1,$dbc) or $err=1;
			$row1=mysql_fetch_array($res1);
			$state=$row1[0];			
			$city=$row1[1];
		?>
		<fieldset>
		<legend>Withness Details</legend>
		<label>Full Name</label><?php echo $row[0]; ?><br>
		<label>Date of Birth</label><?php echo $row[1]; ?><br>
		<label>Address </label><?php echo $row[2]; ?><br>
		<label>State</label><?php echo $state; ?><br>
		<label>City</label><?php echo $city; ?><br>
		<label>Pincode</label><?php echo $row[4]; ?><br>
		<label>Contact No </label><?php echo $row[6]; ?><br>
		</fieldset>
		<?php
	}
	
	$q='SELECT `name`, `cost`, `doc_name`, `address`, `city`, `pincode`, `state`, `contact_no` FROM `hospital_table` WHERE `claim_id`='.$cid.'';
	$data=mysql_query($q,$dbc)or $err=1;
	if(mysql_num_rows($data)==1)
	{
		$row=mysql_fetch_array($data);
		$q1='select st.name,ct.name from state_table as st inner join city_table as ct using(state_id) where ct.state_id='.$row[6].' and ct.city_id='.$row[4].'';
			$res1=mysql_query($q1,$dbc) or $err=1;
			$row1=mysql_fetch_array($res1);
			$state=$row1[0];			
			$city=$row1[1];
	?>
	<fieldset>
	<legend>Hospital Details</legend>
	<label>Hospital Name</label><?php echo $row[0]; ?><br>
	<label>Dr. Name</label><?php echo $row[2]; ?><br>
	<label>Cost</label><?php echo $row[1]; ?><br>
	<label>Address </label><?php echo $row[3]; ?><br>
	<label>State</label><?php echo $state; ?><br>
	<label>City</label><?php echo $city; ?><br>
	<label>Pincode</label><?php echo $row[5]; ?><br>
	<label>Contact No </label><?php echo $row[7]; ?><br>
	</fieldset>
	<?php
	}
	
	$q='SELECT `garage_name`, `name`, `cost`, `address`, `city`, `pincode`, `state`, `contact_no`FROM `garage_table` WHERE `claim_id`='.$cid.'';
	$data=mysql_query($q,$dbc)or $err=1;
	if(mysql_num_rows($data)==1)
	{
		$row=mysql_fetch_array($data);
		$q1='select st.name,ct.name from state_table as st inner join city_table as ct using(state_id) where ct.state_id='.$row[6].' and ct.city_id='.$row[4].'';
			$res1=mysql_query($q1,$dbc) or $err=1;
			$row1=mysql_fetch_array($res1);
			$state=$row1[0];			
			$city=$row1[1];		
		?>
		<fieldset>
		<legend>Garage Details</legend>
		<label>Garage Name</label><?php echo $row[0]; ?><br>
		<label>Mechanic Name</label><?php echo $row[1]; ?><br>
		<label>Cost</label><?php echo $row[2]; ?><br>
		<label>Address </label><?php echo $row[3]; ?><br>
		<label>State</label><?php echo $state; ?><br>
		<label>City</label><?php echo $city; ?><br>
		<label>Pincode</label><?php echo $row[5]; ?><br>
		<label>Contact No </label><?php echo $row[7]; ?><br>
		</fieldset>
		<?php
	}
	
	$q='SELECT `name`, `description`, `dob`, `address`, `city`, `pincode`, `state`, `contact_no`FROM `third_party_table` WHERE `claim_id`='.$cid.'';
	$data=mysql_query($q,$dbc)or $err=1;
	if(mysql_num_rows($data)==1)
	{
		$row=mysql_fetch_array($data);
		$q1='select st.name,ct.name from state_table as st inner join city_table as ct using(state_id) where ct.state_id='.$row[6].' and ct.city_id='.$row[4].'';
			$res1=mysql_query($q1,$dbc) or $err=1;
			$row1=mysql_fetch_array($res1);
			$state=$row1[0];			
			$city=$row1[1];
		?>
		<fieldset>
		<legend>Third Party Details</legend>
		<label>Full Name</label><?php echo $row[0]; ?><br>
		<label>Date of Birth</label><?php echo $row[2]; ?><br>
		<label>Description </label><?php echo $row[1]; ?><br>
		<label>Address </label><?php echo $row[3]; ?><br>
		<label>State</label><?php echo $state; ?><br>
		<label>City</label><?php echo $city; ?><br>
		<label>Pincode</label><?php echo $row[5]; ?><br>
		<label>Contact No </label><?php echo $row[7]; ?><br>
		</fieldset>
		<?php
	}
	
	$q='SELECT `rep_date`,`police_station`, `police_attender`, `description` FROM `accident_table` WHERE `claim_id`='.$cid.'';
	$data=mysql_query($q,$dbc)or $err=1;
	if(mysql_num_rows($data)==1)
	{
		$row=mysql_fetch_array($data);
		?>
		<fieldset>
	<legend>Accident Details</legend>
	<label>Police Station</label><?php echo $row[1]; ?><br>
	<label>Report Date</label><?php echo $row[0]; ?><br>
	<label>Police Attender</label><?php echo $row[2]; ?><br>
	<label>Description </label><?php echo $row[3]; ?><br>
	</fieldset>
		<?php
	}
	if($err==1)
	{
		echo '<div class="error">Problem to View Claim.</div>';
	}
	}
	else{echo '<div class="error">NO Claim Select.</div>';}
	
?>
<?php include("down.php"); ?>