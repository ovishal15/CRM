<?php include("up.php"); ?>
<title>Get Quote</title>
<script type="text/javascript" src="JS/jquery-2.0.3.min.js"></script>
<script src="JS/quote_validate.js"></script>
<div id="errors"></div>
	<form action="four_get_quote_sub.php" method="post" onsubmit="return validateForm(this)">
	<fieldset>
	<legend>Get Quote</legend>
	<label>*RTO No:</label><input type="text" name="rto" required="required" /><br>
	Cite vehicle where the vehicle was registered<br />
	<label>*Age of Vehicle</label><select name="age" required="required">
   	<option value="5">UP TO 5 Year</option>
    <option value="6">UP TO 5-10 Year</option>
	<option value="10">More then 10 Year</option>
    </option>
	</select><br>
	<label>*Enter CC</label><input type="text" name="cc" required="required" /><br>
	<label>*Enter IDV</label><input type="text" name="idv" required="required" /><br>
	<label>ELE. ACC FITING VALUE</label><input type="text" name="elev" /><br>
	<label>NON- ELE.ACC. VALUE</label><input type="text" name="nelev" /><br>
	<label>CNG / LPG Inbult</label><select name="cli" >
	<option value="N">No</option>
	<option value="Y">Yes</option>
	</select>
	<br>
	<label>CNG / LPG COST AMT.</label><input type="text" name="clc" /><br>
	<label>NO. OF PA PASSENGER </label><input type="text" name="nop" /><br>
    <label>*Mobile No. +91</label><input type="text" name="num" required="required" /><br>
	<label>*Email-ID</label><input type="text" name="id" required="required" /><br>
    <input type="submit" name="submit" value="Get Quote" />
    </label>
	</fieldset>
	</form>
<?php include("down.php"); ?>