<?php include("up.php"); require("agent_session.php"); include("chk_app.php");?>
<title>Renew Policy</title>
	<form action="cust_renew_policy.php" method="post">
	<?php
	echo '<fieldset><legend>Select Customer</legend>';
	 $agent_id=$_SESSION['user_id'];
	 $q="SELECT `first_name`, `last_name`, `email_id`, `address`, `contact_no`, `cust_id` FROM `cust_table` where agent_id=$agent_id";
	 $res=mysql_query($q,$dbc) or die("Problem in Access of data...............");
	 if(mysql_num_rows($res)>=1)
	 {
	 ?>
	 <table>
	 <tr><th width="100">Name</th><th width="150">E-mail Id</th><th width="150">Address</th><th width="200">Contact No</th></tr>
	 <?php
	 while($row=mysql_fetch_array($res)){
	 echo '<tr><td><input type="radio" name="cust" value="'.$row[5].'" />'.$row[0].' '.$row[1].'</td><td>'.$row[2].'</td><td>'.$row[3].'</td><td>'.$row[4].'</td></tr>'; 
	 }
	  echo '</table>';
	  }
	?>

    <input type="submit" name="submit" value="Submit" />
	</fieldset>
  </form>
<?php include("down.php"); ?>