<?php include("up.php"); require("agent_session.php");?>
<title>Add Vehicle</title>
<?php 
	require("var/connect.php");
if(isset($_POST['submit']))
{
	$rto=$_POST['rto'];
	$manu=$_POST['manu'];
	$mod=$_POST['mod'];
	$mil=$_POST['mil'];
	$cn=$_POST['cn'];
	$rt=$_POST['rt'];
	$rd=$_POST['rd'];
	$pid=$_POST['pid'];
	$cust=$_POST['cust'];
	$err=0;
	
	$rto=$_POST['rto'];
	$age=$_POST['age'];
	$rt=2;
	$cc=$_POST['cc'];
	$idv=$_POST['idv'];
	$elev=$_POST['elev'];
	$nelev=$_POST['nelev'];
	$amount=0;
	require_once 'Classes/PHPExcel.php';
require_once 'Classes/PHPExcel/IOFactory.php';
$zone="A";
$q='SELECT `discount` FROM `policy_table` WHERE `policy_id`='.$pid.'';
	$res=mysql_query($q,$dbc);
	$row=mysql_fetch_row($res);
	$dis=$row[0];

$inputFileType = PHPExcel_IOFactory::identify('get_quote.xls');
$objPHPExcel = PHPExcel_IOFactory::load('get_quote.xls');

$objPHPExcel->setActiveSheetIndex(1);
$objPHPExcel->getActiveSheet()->setCellValue('I2',"TWO WHEELERS");
$objPHPExcel->getActiveSheet()->setCellValue('J6',$zone);
$objPHPExcel->getActiveSheet()->setCellValue('J5',$today);
$objPHPExcel->getActiveSheet()->setCellValue('J7',$age);
$objPHPExcel->getActiveSheet()->setCellValue('J8',$cc);
$objPHPExcel->getActiveSheet()->setCellValue('J9',$idv);
$objPHPExcel->getActiveSheet()->setCellValue('J10',$elev);
$objPHPExcel->getActiveSheet()->setCellValue('J11',$nelev);
$objPHPExcel->getActiveSheet()->setCellValue('M13',$dis);
$pre= $objPHPExcel->getActiveSheet()->getCell('N39')->getCalculatedValue();


$pre= $objPHPExcel->getActiveSheet()->getCell('N39')->getCalculatedValue();
	$q='INSERT INTO `policy_cust_table`(`policy_cust_id`, `cust_id`, `policy_id`, `approve`, `date`,`premium`) VALUES (0,'.$cust.','.$pid.',0,now(),'.$pre.')';
	mysql_query($q,$dbc) or $err=1;
	$q1="INSERT INTO `vehicle_table`(`vehicle_id`, `rto`, `manufacture`, `model`, `milege`, `chasis_no`, `reg_type`, `reg_date`, `policy_id`, `age_vehicle`, `idv`, `ele_acc`, `nele_acc`, `class`) VALUES (0,'".$rto."','".$manu."','".$mod."','".$mil."','".$cn."','".$rt."','".$rd."','".$pid."','".$age."','".$idv."','".$elev."','".$nelev."','".$zone."')";
	mysql_query($q1,$dbc) or $err=1;
	if($err==0){echo '<div class="valid">Your policy have been submited,we approve your policy when you pay money</div>';}
	else{echo '<div class="error">Sorry, Some error found so try again later</div>';}
}
s
?>
<?php include("down.php"); ?>