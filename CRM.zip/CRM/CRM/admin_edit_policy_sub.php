<?php include("up.php"); require("admin_session.php");?>
<title>Update Policy</title>
<script src="JS/chk_policy.js"></script>
	<?php
	require("var/connect.php");
	if(isset($_POST['submit']))
	{
	$pid=$_POST['poli'];
	$_SESSION['epid']=$pid;
	 $q='SELECT `title`, `description`, `fixed_cover`, `discount` FROM `policy_table` WHERE `policy_id`='.$pid.'';
	 $res=mysql_query($q,$dbc);
	 $row=mysql_fetch_array($res);
	 ?>
	<div id="errors"></div>
	<form action="admin_edit_policy_sub.php" method="post" onsubmit="return validate_policy(this)">
	<fieldset>
	<legend>Add New Policy</legend>
	 <label>*Title:</label><input type="text" name="title" required="required" value="<?php echo $row[0];?>" /><br>
    <label>*Policy details</label><textarea name="desc" rows="6" cols="30" required="required"><?php echo $row[1];?></textarea>
    <br>
  	<label>*Fixed cover</label><input type="text" name="cover" required="required" value="<?php echo $row[2];?>"  /><br>
	<label>Special Discount</label><input type="text" name="dis" required="required"  value="<?php echo $row[3];?>" /><br>
    <input type="submit" name="sub" value="Submit" />
    </label>
	</fieldset>
	</form>
	<?php
	}
	if(isset($_POST['sub'])){
	$e=0;
		$title=$_POST['title'];
		$desc=$_POST['desc'];
		$cover=$_POST['cover'];
		$dis=$_POST['dis'];
		$pid=$_SESSION['epid'];
		unset($_SESSION['epid']);
		$q="UPDATE `policy_table` SET `title`='".$title."',`description`='".$desc."',`fixed_cover`='".$cover."',`discount`='".$dis."' WHERE `policy_id`='".$pid."'";
		mysql_query($q,$dbc) or $e=1;

			
			
		if($e==0){
			echo '<div class="valid">Success fuly Updated</div>';
		}
		else
		{
			echo '<div class="error">not Success fuly Updated</div>';
		}
	}
	?>
<?php include("down.php"); ?>