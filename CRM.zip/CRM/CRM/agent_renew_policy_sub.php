<?php include("up.php"); require("agent_session.php"); ?>
<title>Renew Policy</title>
	<?php
	require("var/connect.php");
	if(isset($_POST['submit'])){
	 $cust_id=$_POST['cust'];
	 $q1="SELECT `policy_id`, date,policy_cust_id FROM `policy_cust_table` WHERE cust_id=$cust_id and approve=1";
	 $res1=mysql_query($q1,$dbc);
	  if(mysql_num_rows($res1)>=1){
	 while($row1=mysql_fetch_row($res1)){
	 $pid=$row1[0];
	 $td=substr($row1[1],0,10);//split date form database
	 $apdate = date_create($td);//create date which get using database
	 $todate=date_create(date("Y-m-d")); //create currnet date
	 $diff=date_diff($apdate,$todate);//get diffrence
	 $day=$diff->format("%a");//splite diffrence of day form $diff
	 if($day>=365){
	?>
	<form action="agent_renew_policy_submit.php" method="post">
	<fieldset>
	<legend>Renew Polices</legend>
	<?php
	 $q='SELECT `policy_id`,`title`, `policy_type`, `description`  FROM `policy_table` where policy_id='.$pid.'';
	 $res=mysql_query($q,$dbc);
	 ?>
	 <table><tr><th width="150">Policy</th><th width="150">Type</th><th width="250">description</th></tr>
	 <?php
	 while($row=mysql_fetch_array($res))
	 {
	 echo '<tr><td><input type="radio" name="poli" value="'.$row[0].'" />'.$row[1].'</td><td>'.$row[2].'</td><td>'.$row[3].'</td></tr>'; 
	 }
	?>
	</table>
	<input type="hidden" name="id" value="<?php echo $cust_id;?>">
    <input type="submit" name="submit" value="Submit" />
	</fieldset>
  </form>
	<?php
	 }
	 else {
	echo "You no need to renew policy";
}
	 	}
			}
else {
	echo "You need to buy policy";
}
}
	 
	?>
<?php include("down.php"); ?>