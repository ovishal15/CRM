<link href="css/default.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="JS/jquery.min.js"></script>
<script type="text/javascript" src="JS/ddaccordion.js"></script>
<script type="text/javascript">
ddaccordion.init({
	headerclass: "submenuheader", //Shared CSS class name of headers group
	contentclass: "submenu", //Shared CSS class name of contents group
	revealtype: "click", //Reveal content when user clicks or onmouseover the header? Valid value: "click", "clickgo", or "mouseover"
	mouseoverdelay: 200, //if revealtype="mouseover", set delay in milliseconds before header expands onMouseover
	collapseprev: true, //Collapse previous content (so only one open at any time)? true/false 
	defaultexpanded: [], //index of content(s) open by default [index1, index2, etc] [] denotes no content
	onemustopen: false, //Specify whether at least one header should be open always (so never all headers closed)
	animatedefault: false, //Should contents open by default be animated into view?
	persiststate: true, //persist state of opened contents within browser session?
	toggleclass: ["", ""], //Two CSS classes to be applied to the header when it's collapsed and expanded, respectively ["class1", "class2"]
	togglehtml: ["suffix", "<img src='images/plus.gif' class='statusicon' />", "<img src='images/minus.gif' class='statusicon' />"], //Additional HTML added to the header when it's collapsed and expanded, respectively  ["position", "html1", "html2"] (see docs)
	animatespeed: "fast", //speed of animation: integer in milliseconds (ie: 200), or keywords "fast", "normal", or "slow"
	oninit:function(headers, expandedindices){ //custom code to run when headers have initalized
		//do nothing
	},
	onopenclose:function(header, index, state, isuseractivated){ //custom code to run whenever a header is opened or closed
		//do nothing
	}
})
</script>
<body>
<!-- start header -->
<div id="header">
	<div id="logo">
		<h1><a href="index.php"><span>Customer Relationship</span> Management</a></h1>
		<p>Vehicle insurance</p>
	</div>
	<div id="menu">
		<ul id="main">
			<li><a href="index.php">Homepage</a></li>
			<li><a href="view_policy.php">Policy</a></li>
			<li><a href="about_us.php">About Us</a></li>
			<li><a href="contact_us.php">Contact Us</a></li>
			<li><a href="faq.php">FAQ</a></li>
			<li style="color:#FFFFFF;text-align:center;float:right;padding:15px 10px 0px 0px">
			<?php session_start();
				if(isset($_SESSION['user_id']))
					echo 'Welcome '.$_SESSION['username'];
				else 
					echo 'Welcome Visitor';
			?>
			</li>
		</ul>
	</div>
	
</div>
<!-- end header -->
<div id="wrapper">
	<!-- start page -->
	<div id="page">
		<div id="sidebar1" class="sidebar">
			<ul>
				<li>
					<h2>Side Menu</h2>
					<div class="sidebarmenu">
					<?php include("menu.php"); ?>
				</li>
			</ul>
		</div>
		<!-- start content -->
		<div id="content">
