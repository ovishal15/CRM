<?php include("up.php"); ?>
<title>Agent Forgote Passeord</title>
<script src="JS/for_validate.js"></script>
<div id="errors"></div>
<form action="reg_forgot.php" method="post" onSubmit="return vali_for(this)">
<fieldset>
<legend>Forgot password details</legend>
<label>Email-ID</label><input type="text" name="email" required="required"><br>
<label>Contact No</label><input type="text" name="con_no" required="required"><br>
<input type="submit" value="Next" name="submit">
</fieldset>
</form>
<?php include("down.php"); ?>