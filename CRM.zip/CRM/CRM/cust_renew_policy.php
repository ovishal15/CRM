<?php include("up.php");  require("comman_session.php"); include("chk_app.php");?>
<title>Renew Policy</title>
	<?php
	$err=0;
	$e=0;
	if($_SESSION['type']=='customer')$cust_id=$_SESSION['user_id'];
	else{ $cust_id=$_POST['cust']; $_SESSION['rcust']=$cust_id;}
	 $q1="SELECT `policy_id`, date,policy_cust_id FROM `policy_cust_table` WHERE cust_id=$cust_id and approve=1";
	 $res1=mysql_query($q1,$dbc);
	 if(mysql_num_rows($res1)>=1){
	 
	 $pidarr = new ArrayObject(array());
	 $pcidarr = new ArrayObject(array());
	 while($row1=mysql_fetch_row($res1)){
	 $pid=$row1[0];
	 $td=$row1[1];//split date form database
	 $apdate = date_create($td);//create date which get using database
	 $todate=date_create(date("Y-m-d")); //create currnet date
	 $diff=date_diff($apdate,$todate);//get diffrence
	 $day=$diff->format("%a");//splite diffrence of day form $diff
	 if($day>=365){
	 $pidarr->append($pid);
	 $pcidarr->append($row1[2]);
	 }
	 else{
	 $e=1;
	 }
	 }
	 if(count($pidarr)>=1){
	 
	 ?>
	<form action="cust_renew_policy_sub.php" method="post">
	<fieldset>
	<legend>Renew Polices</legend>
	 <table><tr><th width="150">Policy</th><th width="150">Policy No</th><th width="150">Type</th><th width="250">description</th></tr>
	<?php
	for($i=0;$i<count($pidarr);$i++)
	{
	 $q='SELECT `policy_id`,`title`, `policy_type`, `description`  FROM `policy_table` where policy_id='.$pidarr[$i].'';
	 $res=mysql_query($q,$dbc);
	 while($row=mysql_fetch_array($res))
	 {
	 echo '<tr><td><input type="radio" name="poli" value="'.$pcidarr[$i].'" required="required" />'.$row[1].'</td><td>'.$pcidarr[$i].'</td><td>'.$row[2].'</td><td>'.$row[3].'</td></tr>'; 
	 }
	 }
	?>
	</table>
    <input type="submit" name="submit" value="Submit" />
	</fieldset>
  </form>
	<?php
	
	 }
	 else {echo '<div class="warning">No need to renew policy</div>';}
	 }
else {
	echo '<div class="error">You need to buy policy</div>';
}
	?>
<?php include("down.php"); ?>