<?php include("up.php"); ?>
<title>user forgot Password</title>
<?php
	$err=0;
	require("var/connect.php");
	if(isset($_POST['sub']))
	{
	$pass=$_POST['pass'];
	$lid=$_SESSION['lid'];
	unset($_SESSION['lid']);
	$q='UPDATE `login_table` SET `password`=SHA('.$pass.') WHERE `log_in_id`='.$lid.'';
	mysql_query($q,$dbc) or $err=1;
	if($err==1){echo '<div id="errors">Plese enter correct information<br><a href="for_pass.php">Click Here to enter data</a>.</div>';}
	else{echo '<div class="valid">Your password sussfuly updated........</div>';}
	}	
	
	if(isset($_POST['submit']))
	{
	$lid=$_SESSION['lid'];
	$cans=$_SESSION['cans'];
	unset($_SESSION['cans']);
	$ans=$_POST['ans'];
	
	if($ans!=$cans){$err=1;}
	if($err==1)
	{
	echo '<div id="errors">Plese enter correct information<br><a href="for_pass.php">Click Here to enter data</a>.</div>';
	}
	else{
	?>
	<div id="errors"></div>
	<script src="JS/for_sub_validate.js"></script>
<form action="reg_forgot_sub.php" method="post" onSubmit="return validateForm(this)">
<fieldset>
<legend>Forgot password details</legend>
<label>*New Password</label><label><input type="password" name="pass" required="required"></label><br>
<label>*Conform new Password</label><input type="password" name="con_pass" required="required"><br>
<input type="submit" value="Next" name="sub">
</fieldset>
</form>	
	<?php
	}
}
 	?>
<?php include("down.php"); ?>