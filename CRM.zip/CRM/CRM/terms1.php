<?php include("up.php"); ?>
<title>Terms</title>
<h2 class="title"> Declarations Page (Dec Page)</h2><br>
Also known as an auto insurance coverage summary, this page is provided by your insurance company and lists the following:<br>
�	Types of coverage you have elected<br>
�	Limit for each coverage<br>
�	Cost for each coverage<br>
�	Specified vehicles covered by the policy<br>
�	Types of coverage for each vehicle covered by the policy<br>
�	Other information applicable to the policy<br>

<h2 class="title"> Deductible</h2><br>
A deductible is the amount you agree to pay out of pocket for damage resulting from a specific loss or accident. Generally, choosing a higher deductible will lower your premium.<br>

<h2 class="title">Driver Improvement Course</h2><br>
Drivers age 55 and older can take a voluntary driver improvement course to refresh and enhance their driving skills. Taking this course may qualify these drivers for a discount if they meet eligibility requirements.<br>

<h2 class="title">Driver Status</h2><br>
People can be added to policies with the following types of driver status:<br>
�	Rated  Actively drive vehicles on the policy<br>
�	Excluded- Not allowed to drive vehicles on the policy and will not be covered under your policy in the event of an accident<br>
<h2 class="title">Full Coverage</h2><br>
"Full coverage" is a common term that people use to describe how much auto insurance coverage they have. Though there is no such thing as "full coverage," it often implies that the policy has more than just Liability coverage.

<h2 class="title">Garaging Location</h2><br>
A garaging location is the place you primarily park your vehicle when you're not using it. Generally, this is your primary residence.<br>

<p><a href="terms.php"><< Previous </a> | </p>
<?php include("down.php"); ?>