<?php include("up.php");?>
<div class="warning">You are not valid  customer so you not use this page<br>Please contact us for this problem  or submit your document's</div>
<?php include("down.php"); ?>