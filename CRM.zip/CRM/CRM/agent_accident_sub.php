<?php include("up.php"); require("agent_session.php");?>
<title>Add Accident</title>
<?php
if(isset($_POST['submit']))
{
require("var/connect.php");
$err=0;
$cid=$_POST['cid'];
$pname=$_POST['pname'];
$aname=$_POST['aname'];
$desc=$_POST['desc'];
$q='INSERT INTO `accident_table`(`accident_id`, `rep_date`, `claim_id`, `police_station`, `police_attender`, `description`) VALUES (0,now(),'.$cid.',"'.$pname.'","'.$aname.'","'.$desc.'")';
mysql_query($q,$dbc) or $err=1;
	if($err==1){echo '<div class="error">Accident Susseccful not added</div>';}
	else{echo '<div class="valid">Accident Susseccful added</div>';}
}
?>
<?php include("down.php"); ?>