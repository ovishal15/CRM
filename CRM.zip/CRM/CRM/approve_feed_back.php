<?php include("up.php"); require("admin_session.php");?>
<title>Approve Policy</title>
 <?php
  require("var/connect.php");
  $error = 0;
  if(isset($_POST['submit']))
  {
  $poli=$_POST['poli'];
  foreach($poli as $p){
  	$q='UPDATE feed_back_table SET approve=1 WHERE feed_id='.$p;
	mysql_query($q,$dbc) or die($error=1);
	}
	if($error==0){
			echo '<div class="valid">Successfully approve of Feed Backs.</div>';
		}
		else
		{
			echo '<div id="errors">not Success fuly approve of Feed Backs.</div>';
		}
  }
  if(isset($_POST['sub_del']))
  {
  $poli=$_POST['poli'];
  foreach($poli as $p){
  	$q='DELETE FROM `feed_back_table` WHERE feed_id='.$p;
	mysql_query($q,$dbc) or die($error=1);
	}
	if($error==0){
			echo '<div class="valid">Successfully deletion of Feed Backs.</div>';
		}
		else
		{
			echo '<div id="errors">not Success fuly deletion of Feed Backs.</div>';
		}
  }
  if(!isset($_POST['submit']) || !isset($_POST['sub_del'])){
	 $q='SELECT `feed_id`, `rate`, `description`, `id`, `type` FROM `feed_back_table` WHERE approve=0';
	 $res=mysql_query($q,$dbc);
	 if(mysql_num_rows($res)>=1)
	 {
	 ?>
	 <form action="approve_feed_back.php" method="post">
	<fieldset>
	<legend>Approve Polices</legend>
	 <table><tr><th width="150">Name</th><th width="150">Type</th><th width="150">Rate</th><th width="150">Description</th><th width="150">View</th></tr>
	 <?php
	 $no=rand();
	 $_SESSION['key']=$no;
	 while($row=mysql_fetch_array($res)){
	 $v=$row[3]*$_SESSION['key'];
	 if($row[4]=='agent')
	 {
	 	$q1='SELECT `first_name`, `last_name` FROM `agent_table` WHERE agent_id='.$row[3].'';
		$res1=mysql_query($q1,$dbc);
		$row1=mysql_fetch_array($res1);
		echo '<tr><td><input type="checkbox" name="poli[]" value="'.$row[0].'" />'.$row1[0].' '.$row1[1].'</td><td>'.$row[4].'</td><td>'.$row[1].'</td><td>'.$row[2].'</td><td><a href="view_agent.php?vid='.$v.'">View Profile</a></td></tr>'; 
	 }
	 else{
	 	$q1='SELECT `first_name`, `last_name` FROM `cust_table` WHERE cust_id='.$row[3].'';
		$res1=mysql_query($q1,$dbc);
	 	$row1=mysql_fetch_array($res1);
		echo '<tr><td><input type="checkbox" name="poli[]" value="'.$row[0].'" />'.$row1[0].' '.$row1[1].'</td><td>'.$row[4].'</td><td>'.$row[1].'</td><td>'.$row[2].'</td><td><a href="view_customer.php?vid='.$v.'">View Profile</a></td></tr>'; 
	 }
	 }
	?>
	</table>
    <input type="submit" name="submit" value="Submit" />
	<input type="submit" name="sub_del" value="Delete" />
	</fieldset>
  </form>
<?php }else {echo '<div class="warning">NO feed Back is avliable for activetion.</div>';} }include("down.php"); ?>