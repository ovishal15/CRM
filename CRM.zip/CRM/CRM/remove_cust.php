<?php include("up.php"); require("admin_session.php");?>
<title>Remove Cutomer</title>
<form action="remove_cust.php" method="get">
	<fieldset>
	<legend>Search Box</legend>
    <label for="usersearch">Find:</label>
    <input type="text" name="search" /><br />
    <input type="submit" name="submit" value="Submit" />
	</fieldset>
  </form>
<?php
	require("var/connect.php");
  	 $error = 0;
	 if(!isset($_SESSION['rid']))
	 {
	 
	 if(!empty($_GET['search']))
	 {
	 $q="SELECT `first_name`, `last_name`, `email_id`, `address`, `contact_no`, `cust_id` FROM `cust_table`";
	 $field=array('first_name', 'last_name', 'email_id', 'address', 'contact_no','state','city','residence_no','title');
	 $q = build_query($q,$_GET['search'],$field);
	 }
	 else{
	 $q="SELECT `first_name`, `last_name`, `email_id`, `address`, `contact_no`, `cust_id` FROM `cust_table`";
	 }

	 $res=mysql_query($q,$dbc) or die("Problem in Access of data...............");
	 if(mysql_num_rows($res)>=1)
	 {
	 ?>
	 <table>
	 <tr><th width="100">Name</th><th width="150">E-mail Id</th><th width="150">Address</th><th width="200">Contact No</th><th>View Profile</th></tr>
	 <?php
	 $no=rand();
	 $_SESSION['key']=$no;
	 while($row=mysql_fetch_array($res)){
 	 $q2='SELECT `user_id` FROM `login_table` WHERE `type`="customer" and `user_id`='.$row[5].' and `active`=1';
	 $re=mysql_query($q2,$dbc) or die("Problem in Access of data...............");
	 if(mysql_num_rows($re)>=1)
	 {
	 $v=$row[5]*$_SESSION['key'];
	 echo "<tr><td>$row[0] $row[1]</td>";
	 echo "<td>$row[2]</td>";
	 echo "<td>$row[3]</td>";
	 echo "<td>$row[4]</td>";
	 echo '<td><a href="view_customer.php?type=remove&vid='.$v.'">View Profile</a></td></tr>';
	 }
	 }
	  echo '</table>';
	 }
	 else {echo "No customer";}
	 }
	else{
	$err=0;
	$cust_id = $_SESSION['rid'];
	unset($_SESSION['rid']);
	$q1="UPDATE `login_table` SET `active`=0 WHERE `user_id`=$cust_id and type='customer'";
	mysql_query($q1,$dbc) or ($err=1);
	if($err==0){ echo '<div class="valid">Successful removal of customer</div>';}
	else{echo '<div class="errors">Removal failed. Try Again........</div>';}
	
	}
?>
<?php include("down.php"); ?>