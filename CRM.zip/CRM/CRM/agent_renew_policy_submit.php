<?php include("up.php"); require("agent_session.php");?>
<title>Renew Policy</title>
<?php 
	require("var/connect.php");
	if(isset($_POST['submit'])){
	$pid=$_POST['poli'];
	$cust_id=$_POST['id'];
	$err=0;
	$q='UPDATE `policy_cust_table` SET `approve`=0,`date`=now() WHERE cust_id='.$cust_id.' and `policy_id`='.$pid.'';
	mysql_query($q,$dbc) or $err=1;
	if($err==0){echo "Your policy have been submited,we approve your policy when you pay money.";}
	else{echo '<p id="error">Sorry, Some error found so try again later</p>';}

	}
	?>
<?php include("down.php"); ?>