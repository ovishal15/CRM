<?php include("up.php"); require("comman_session.php"); ?>
<title>Edit Profile</title>
<?php
	require("var/connect.php");
  	 $error = 0;
	if(isset($_POST['submit']))
	{
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$add=$_POST['add'];
		$pcode=$_POST['pcode'];
		$state=$_POST['state'];
		$con_no=$_POST['con_no'];
		$res_no=$_POST['res_no'];
		$city=$_POST['city'];
		$old_pic=$_POST['old_pic'];
		$cust_id=$_SESSION['user_id'];
		$old_pic=$_POST['old_pic'];
		$new_pic = trim($_FILES['new_pic']['name']);
    	$new_pic_type = $_FILES['new_pic']['type'];
	    $new_pic_size = $_FILES['new_pic']['size']; 

    // Validate and move the uploaded picture file, if necessary
    	 if (!empty($new_pic)) {
         if ((($new_pic_type == 'image/gif') || ($new_pic_type == 'image/jpeg') || ($new_pic_type == 'image/pjpeg') ||
        ($new_pic_type == 'image/png')) && ($new_pic_size > 0) && ($new_pic_size <= 3276800)) {

          // Move the file to the target upload folder
          $target = up_path . basename($new_pic);
          if (move_uploaded_file($_FILES['new_pic']['tmp_name'], $target)) {
              @unlink(MM_UPLOADPATH . $old_picture);
          }
          else {
            // The new picture file move failed, so delete the temporary file and set the error flag
            @unlink($_FILES['new_pic']['tmp_name']);
            $error = 1;
            echo '<p class="error">Sorry, there was a problem uploading your picture.</p>';
          }
        
      }
      else {
        // The new picture file is not valid, so delete the temporary file and set the error flag
        @unlink($_FILES['new_pic']['tmp_name']);
        $error = 1;
        echo '<p class="error">Your picture must be a GIF, JPEG, or PNG image file no greater than ' . (3276800 / 1024) .' KB.</p>';
      }
    }else if(empty($new_pic)){
	$new_pic=$old_pic;
	}
		
		$e=0;
		if($_SESSION['type']=='customer')
		$q1="UPDATE `cust_table` SET `first_name`='".$fname."', `last_name`='".$lname."', `picture`='".$new_pic."', `address`='".$add."', `city`='".$city."', `pincode`='".$pcode."',`state`='".$state."',`contact_no`='".$con_no."',`residence_no`='".$res_no."' WHERE `cust_id`='".$cust_id."'";
		else
		$q1="UPDATE `agent_table` SET `first_name`='".$fname."', `last_name`='".$lname."', `picture`='".$new_pic."', `address`='".$add."', `city`='".$city."', `pincode`='".$pcode."',`state`='".$state."',`contact_no`='".$con_no."',`residence_no`='".$res_no."' WHERE `agent_id`='".$cust_id."'";
	
		if(mysql_query($q1,$dbc)){$e=1;}
		if($e==1){
			echo '<div class="valid">Successfully updated your profile.</div>';
		}
		else
		{
			echo '<div class="error">not Successfully updated your profile.</div>';
		}
}
?>
<?php include("down.php"); ?>