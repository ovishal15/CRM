-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 09, 2014 at 05:14 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `crm`
--

-- --------------------------------------------------------

--
-- Table structure for table `accident_table`
--

CREATE TABLE IF NOT EXISTS `accident_table` (
  `accident_id` int(11) NOT NULL AUTO_INCREMENT,
  `rep_date` date NOT NULL,
  `claim_id` int(11) NOT NULL,
  `police_station` text NOT NULL,
  `police_attender` text NOT NULL,
  `description` varchar(300) NOT NULL,
  PRIMARY KEY (`accident_id`),
  KEY `vehicle_id` (`claim_id`),
  KEY `claim_id` (`claim_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `accident_table`
--

INSERT INTO `accident_table` (`accident_id`, `rep_date`, `claim_id`, `police_station`, `police_attender`, `description`) VALUES
(1, '2014-05-09', 1, 'Raipur polic station', 'ramesh ', 'description');

-- --------------------------------------------------------

--
-- Table structure for table `agent_table`
--

CREATE TABLE IF NOT EXISTS `agent_table` (
  `agent_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `dob` date NOT NULL,
  `picture` varchar(50) NOT NULL DEFAULT 'no_pic.jpg',
  `email_id` varchar(50) NOT NULL,
  `approve` int(11) NOT NULL DEFAULT '0',
  `address` varchar(200) NOT NULL,
  `city` int(11) NOT NULL,
  `pincode` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `contact_no` bigint(10) NOT NULL,
  `residence_no` bigint(11) DEFAULT '0',
  PRIMARY KEY (`agent_id`),
  UNIQUE KEY `email_id` (`email_id`),
  KEY `city` (`city`,`state`),
  KEY `state` (`state`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `agent_table`
--

INSERT INTO `agent_table` (`agent_id`, `title`, `first_name`, `last_name`, `dob`, `picture`, `email_id`, `approve`, `address`, `city`, `pincode`, `state`, `contact_no`, `residence_no`) VALUES
(4, 'Male', 'Sagar', 'Chauhan', '1985-10-05', 'agent.png', 'agent@gmail.com', 1, '1355,pipla pole,astodia', 1, 380001, 1, 9033767946, 0);

-- --------------------------------------------------------

--
-- Table structure for table `city_table`
--

CREATE TABLE IF NOT EXISTS `city_table` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `state_id` int(11) NOT NULL,
  PRIMARY KEY (`city_id`),
  KEY `state_id` (`state_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `city_table`
--

INSERT INTO `city_table` (`city_id`, `name`, `state_id`) VALUES
(1, 'Ahmedabad', 1),
(2, 'Surat', 1),
(3, 'Mumbai', 2),
(4, 'mehsana', 1),
(5, 'Bhuj', 1),
(6, 'Vadodra', 1),
(7, 'Daman', 1),
(8, 'Pune', 2),
(9, 'Nagpur', 2),
(10, 'Nasik', 2),
(11, 'Ratnagiri', 2);

-- --------------------------------------------------------

--
-- Table structure for table `claim_table`
--

CREATE TABLE IF NOT EXISTS `claim_table` (
  `claim_id` int(11) NOT NULL AUTO_INCREMENT,
  `policy_cust_id` int(11) NOT NULL,
  `total_cost` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `approve` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`claim_id`),
  KEY `policy_id` (`policy_cust_id`),
  KEY `cust_id` (`cust_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `claim_table`
--

INSERT INTO `claim_table` (`claim_id`, `policy_cust_id`, `total_cost`, `cust_id`, `approve`) VALUES
(1, 3, 5000, 9, 0);

-- --------------------------------------------------------

--
-- Table structure for table `contact_table`
--

CREATE TABLE IF NOT EXISTS `contact_table` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `contact_no` bigint(10) NOT NULL,
  `message` varchar(500) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `contact_table`
--

INSERT INTO `contact_table` (`contact_id`, `name`, `email_id`, `contact_no`, `message`, `date`) VALUES
(2, 'Meet', 'meet@gmail.com', 9033767946, 'inquiry to understand insurance', '2014-05-09');

-- --------------------------------------------------------

--
-- Table structure for table `cust_table`
--

CREATE TABLE IF NOT EXISTS `cust_table` (
  `cust_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `dob` date NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `picture` varchar(60) NOT NULL DEFAULT 'no_pic.jpg',
  `approve` int(11) NOT NULL DEFAULT '0',
  `agent_id` int(11) DEFAULT NULL,
  `address` varchar(200) NOT NULL,
  `city` int(11) NOT NULL,
  `pincode` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `contact_no` bigint(10) NOT NULL,
  `residence_no` bigint(11) DEFAULT NULL,
  PRIMARY KEY (`cust_id`),
  UNIQUE KEY `email_id` (`email_id`),
  KEY `agent_id` (`agent_id`),
  KEY `city` (`city`),
  KEY `state` (`state`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `cust_table`
--

INSERT INTO `cust_table` (`cust_id`, `title`, `first_name`, `last_name`, `dob`, `email_id`, `picture`, `approve`, `agent_id`, `address`, `city`, `pincode`, `state`, `contact_no`, `residence_no`) VALUES
(8, 'Male', 'Rajan', 'Panchal', '1991-10-09', 'customer@gmail.com', 'Fotolia_24531635_X-06.jpg', 1, NULL, '1352,pipla pole,astodia', 1, 380001, 1, 9725917623, 0),
(9, 'Male', 'meet', 'Panchal', '1995-11-18', 'meet@gmail.com', 'Lighthouse.jpg', 0, 4, '1352,pipla pole,astodia', 1, 380001, 1, 9033767946, 0),
(10, 'Male', 'ram', 'patel', '1995-12-15', 'ram@gmail.com', 'no_pic.jpg', 1, 4, '70,naranpura soci,', 1, 380002, 1, 9756842310, 0);

-- --------------------------------------------------------

--
-- Table structure for table `driver_table`
--

CREATE TABLE IF NOT EXISTS `driver_table` (
  `driver_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `type` text NOT NULL,
  `drug_influence` text NOT NULL,
  `lic_no` int(11) NOT NULL,
  `exp_date` date NOT NULL,
  `lic_type` text NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` int(11) NOT NULL,
  `pincode` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `contact_no` bigint(10) NOT NULL,
  `claim_id` int(11) NOT NULL,
  PRIMARY KEY (`driver_id`),
  KEY `claim_id` (`claim_id`),
  KEY `city` (`city`,`state`),
  KEY `state` (`state`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `driver_table`
--

INSERT INTO `driver_table` (`driver_id`, `first_name`, `last_name`, `type`, `drug_influence`, `lic_no`, `exp_date`, `lic_type`, `address`, `city`, `pincode`, `state`, `contact_no`, `claim_id`) VALUES
(1, 'vishal', 'oza', 'owner', 'No', 1234567, '2020-12-12', 'permenant', '1324,haveli ni pole', 1, 380001, 1, 9756842310, 1);

-- --------------------------------------------------------

--
-- Table structure for table `faq_table`
--

CREATE TABLE IF NOT EXISTS `faq_table` (
  `faq_id` int(11) NOT NULL AUTO_INCREMENT,
  `qus` varchar(150) NOT NULL,
  `ans` varchar(1000) NOT NULL,
  PRIMARY KEY (`faq_id`),
  UNIQUE KEY `faq_id` (`faq_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `faq_table`
--

INSERT INTO `faq_table` (`faq_id`, `qus`, `ans`) VALUES
(3, 'Why do I need to insure my vehicle?', 'Vehicle Insurance is important not only to protect your vehicle, but also to save you from any financial loss caused by accidents'),
(4, ' What are the types of Car Insurance in India?', 'There are two types of car insurance: \r\n1.Third Party Insurance  \r\n2.Comprehensive Insurance.\r\n\r\nThird party insurance protects a policy holder against losses which arise due to bodily injury/death to a third party or any damage to its property. It is mandatory by law to have third party insurance.\r\n\r\nComprehensive car insurance is purchased when you want to be compensated for any damages to you, your co-passengers and your vehicle in addition to third party coverage\r\n'),
(5, 'What are the different types of vehicles that can be insured online?', 'Only private vehicles (two-wheelers and four-wheelers) can be insured online.\r\n'),
(6, ' What are the documents required to buy policy online?', 'When buying a motor insurance policy online, you do not need to submit any documents. However, you will have to provide with details like registration no, engine no, chassis no, previous policy number if you are holding any, month and year of vehicle manufacture, date and city of purchase, your address, phone no and email id. Keep your RC copy handy.\r\n'),
(7, ' What are the benefits of buying insurance online?', 'The biggest advantage the online platform offers you is the ability to make any purchase decision in a simple and convenient manner. You can sit comfortably at your place and indulge in the process of buying health or motor or travel plan. Since there are a host of competitor websites available in for all searches, this platform can be used very effectively to make quick comparisons between cost and features of various policies.\r\n\r\nOnline insurance offers facilities like renewal reminder, secure payment gateway and tracking. You can also calculate your premium online and get a clear picture of the kind of expense you would need to bear for buying the insurance plan. There are multiple payment options like net banking and credit card for the benefit of the customer. It caters to the need of trouble free insurance.\r\n'),
(8, ' In case of my job and place change, what happens to my policy?', 'Your policy will be unaffected. Only change must be in your address and phone no. You can make the changes online or can visit any of the nearby branches.\r\n\r\nHowever, depending on which city you are shifting to, you might see change in the premium. Motor insurance rates are decided on the basis of the zone of registration of the vehicle - all metro cities (Ahmedabad, Bangalore, Chennai, Hyderabad, Kolkata, Mumbai, New Delhi and Pune) are part of Zone A which has a higher rate of premium than the rest of the country (Zone B).'),
(9, ' What are the factors affecting/reducing the premium of your car?', 'The factors that decide the premium of your vehicle are:\r\n\r\n- Insured declared value or IDV (present market value of the vehicle).\r\n- Cubic capacity of the vehicle.\r\n- Place of vehicle registration.\r\n- Type of model.\r\n- Age of the vehicle.\r\n- Type of cover- whether comprehensive or third party only.\r\n- Add-on covers like Nil Depreciation, PA cover, electronic devices fitted in your car etc. chosen by the customer.\r\n- Retaining NCB will help avail discount on the premium\r\n'),
(10, ' What to do if my car got stolen?', 'In case your vehicle is stolen, you would need to immediately report to the police for registering a claim. A delay in reporting to the concerned authorities will reflect on your claim as your insurer could deny the liability.\r\n'),
(11, ' When should I report to the police?', 'In the event of damage to third party property, bodily injury to third party or self, or theft, you should immediately report to the nearest police station.\r\n'),
(12, 'Can I choose not to claim if the damage is minimal? What do I gain out of it?', 'Never rush to make a claim for every small dent on your car. You are entitled to a no-claim bonus (NCB) for every claim-free year. If you dont make any claim on your car insurance policy for a few years, the NCB can reduce your premium cost to half the price. Many a times, it has been seen that what you spend on repairs in the garage could be less than the amount you stand to lose as no-claim bonus.\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `feed_back_table`
--

CREATE TABLE IF NOT EXISTS `feed_back_table` (
  `feed_id` int(11) NOT NULL AUTO_INCREMENT,
  `rate` int(1) NOT NULL,
  `description` varchar(100) NOT NULL,
  `id` int(11) NOT NULL,
  `type` text NOT NULL,
  `date` date NOT NULL,
  `approve` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`feed_id`),
  KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `feed_back_table`
--

INSERT INTO `feed_back_table` (`feed_id`, `rate`, `description`, `id`, `type`, `date`, `approve`) VALUES
(1, 4, 'nice work', 4, 'agent', '2014-05-09', 0);

-- --------------------------------------------------------

--
-- Table structure for table `garage_table`
--

CREATE TABLE IF NOT EXISTS `garage_table` (
  `garage_id` int(11) NOT NULL AUTO_INCREMENT,
  `garage_name` text NOT NULL,
  `name` text NOT NULL,
  `cost` int(11) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` int(11) NOT NULL,
  `pincode` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `contact_no` bigint(10) NOT NULL,
  `claim_id` int(11) NOT NULL,
  PRIMARY KEY (`garage_id`),
  KEY `claim_id` (`claim_id`),
  KEY `city` (`city`),
  KEY `state` (`state`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `garage_table`
--

INSERT INTO `garage_table` (`garage_id`, `garage_name`, `name`, `cost`, `address`, `city`, `pincode`, `state`, `contact_no`, `claim_id`) VALUES
(1, 'vadwala', 'raju', 4000, '29,near ambavadi', 1, 380001, 1, 9632587410, 1);

-- --------------------------------------------------------

--
-- Table structure for table `hospital_table`
--

CREATE TABLE IF NOT EXISTS `hospital_table` (
  `hospital_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `cost` int(11) NOT NULL,
  `doc_name` text NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` int(11) NOT NULL,
  `pincode` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `contact_no` bigint(10) NOT NULL,
  `claim_id` int(11) NOT NULL,
  PRIMARY KEY (`hospital_id`),
  KEY `claim_id` (`claim_id`),
  KEY `city` (`city`),
  KEY `state` (`state`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `hospital_table`
--

INSERT INTO `hospital_table` (`hospital_id`, `name`, `cost`, `doc_name`, `address`, `city`, `pincode`, `state`, `contact_no`, `claim_id`) VALUES
(1, 'civil hospital', 1000, ' RH kaleriya', '15,sumathi nath soci', 1, 380007, 1, 9845653212, 1);

-- --------------------------------------------------------

--
-- Table structure for table `login_table`
--

CREATE TABLE IF NOT EXISTS `login_table` (
  `log_in_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email_id` varchar(40) NOT NULL,
  `type` text NOT NULL,
  `password` varchar(40) NOT NULL,
  `qus` varchar(50) NOT NULL,
  `ans` varchar(50) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`log_in_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `login_table`
--

INSERT INTO `login_table` (`log_in_id`, `user_id`, `email_id`, `type`, `password`, `qus`, `ans`, `active`) VALUES
(1, 100, 'admin@gmail.com', 'admin', 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', '', '', 1),
(12, 8, 'customer@gmail.com', 'customer', 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'What is your first friend name?', 'meet', 1),
(13, 4, 'agent@gmail.com', 'agent', 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'What is your first friend name?', 'darshan', 1),
(14, 9, 'meet@gmail.com', 'customer', 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'What is your first friend name?', 'vishal', 1),
(15, 10, 'ram@gmail.com', 'customer', 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'What is your pet name?', 'ram', 1);

-- --------------------------------------------------------

--
-- Table structure for table `manufacturer_table`
--

CREATE TABLE IF NOT EXISTS `manufacturer_table` (
  `manufacturer_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`manufacturer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `manufacturer_table`
--

INSERT INTO `manufacturer_table` (`manufacturer_id`, `name`, `type`) VALUES
(1, 'FIAT', 4),
(2, 'FORD', 4),
(3, 'Mitsubishi', 4),
(4, 'HONDA', 4),
(5, 'Hyundai', 4),
(6, 'MarutiSuzuki', 4),
(7, 'Renault', 4),
(8, 'Skoda', 4),
(9, 'TATA', 4),
(10, 'Toyota', 4),
(11, 'BAJAJ', 2),
(12, 'Electrotherm', 2),
(13, 'Hero Honda', 2),
(14, 'Hero electric', 2),
(15, 'LML india', 2),
(16, 'Royal enfield', 2),
(17, 'Suzuki Motors', 2),
(18, 'TVS motors', 2),
(19, 'Yamaha', 2),
(20, 'test', 2),
(21, 'Audi', 4);

-- --------------------------------------------------------

--
-- Table structure for table `model_table`
--

CREATE TABLE IF NOT EXISTS `model_table` (
  `model_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `type` int(11) NOT NULL,
  `manufacturer_id` int(11) NOT NULL,
  PRIMARY KEY (`model_id`),
  KEY `manufacturer_id` (`manufacturer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=80 ;

--
-- Dumping data for table `model_table`
--

INSERT INTO `model_table` (`model_id`, `name`, `type`, `manufacturer_id`) VALUES
(1, 'Fiat Grande Punto', 4, 1),
(2, 'Linea', 4, 1),
(3, 'Linea Classic', 4, 1),
(4, 'EcoSport', 4, 2),
(5, 'Endeavour', 4, 2),
(6, 'Fiesta', 4, 2),
(7, 'Figo', 4, 2),
(8, 'Cedia', 4, 3),
(9, 'Pajero Sport', 4, 3),
(10, 'Accord', 4, 4),
(11, 'Amaze', 4, 4),
(12, 'Brio', 4, 4),
(13, 'CR V', 4, 4),
(14, 'New City', 4, 4),
(15, 'Accent', 4, 5),
(16, 'Elantra', 4, 5),
(17, 'Grand i10', 4, 5),
(18, 'i10', 4, 5),
(19, 'New EON', 4, 5),
(20, 'New i20', 4, 5),
(21, 'New Sonata', 4, 5),
(22, 'Verna', 4, 5),
(23, 'Santro Xing', 4, 5),
(24, 'A Star', 4, 6),
(25, 'Alto 800', 4, 6),
(26, 'Ertiga', 4, 6),
(27, 'Gypsy', 4, 6),
(28, 'New Swift', 4, 6),
(29, 'New Swift Dzire', 4, 6),
(30, 'Wagon R', 4, 6),
(31, 'Omni', 4, 6),
(32, 'SX4', 4, 6),
(33, 'Duster', 4, 7),
(34, 'Fluence', 4, 7),
(35, 'Koleos', 4, 7),
(36, 'Scala', 4, 7),
(37, 'Fabia', 4, 8),
(38, 'Laura', 4, 8),
(39, 'Octavia', 4, 8),
(40, 'Rapid', 4, 8),
(41, 'Aria', 4, 9),
(42, 'Indica Vista', 4, 9),
(43, 'Manza Club Class', 4, 9),
(44, 'Nano', 4, 9),
(45, 'Safari', 4, 9),
(46, 'Etios Liva', 4, 10),
(47, 'Innova', 4, 10),
(48, 'New Camry', 4, 10),
(49, 'Prado', 4, 10),
(50, 'Platina', 2, 11),
(51, 'Pulsar 180 DTSi', 2, 11),
(52, 'Avenger DTS-I', 2, 11),
(53, 'XCD 135 DTS-i', 2, 11),
(54, 'Yo Smart', 2, 12),
(55, 'Super Splendor', 2, 13),
(56, 'Karizma', 2, 13),
(57, 'Passion Plus', 2, 13),
(58, 'Hunk', 2, 13),
(59, 'Hero Electric Maxi', 2, 14),
(60, 'Hero Electric Zippy', 2, 14),
(61, 'Hero Electric Wave DX', 2, 14),
(62, 'LML Adreno FX', 2, 15),
(63, 'LML Energy FX', 2, 15),
(64, 'Freedom DX', 2, 15),
(65, 'LML Graptor', 2, 15),
(66, 'Bullet Machismo 500', 2, 16),
(67, 'Classic 500', 2, 16),
(68, 'Classic Chrome', 2, 16),
(69, 'Zeus 125X', 2, 17),
(70, 'Intruder M1800R', 2, 17),
(71, 'Gladius', 2, 17),
(72, 'Apache RTR FI', 2, 18),
(73, 'Centra', 2, 18),
(74, 'Fiero F2', 2, 18),
(75, 'TVS Victor GLX', 2, 18),
(76, 'Crux', 2, 19),
(77, 'Enticer', 2, 19),
(78, 'Alba 106', 2, 19),
(79, 'A10', 4, 21);

-- --------------------------------------------------------

--
-- Table structure for table `payment_table`
--

CREATE TABLE IF NOT EXISTS `payment_table` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_amount` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `policy_id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `policy_id` (`policy_id`),
  KEY `cust_id` (`cust_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `payment_table`
--

INSERT INTO `payment_table` (`payment_id`, `payment_amount`, `payment_date`, `policy_id`, `cust_id`) VALUES
(3, 576, '2014-05-09', 21, 9);

-- --------------------------------------------------------

--
-- Table structure for table `policy_cust_table`
--

CREATE TABLE IF NOT EXISTS `policy_cust_table` (
  `policy_cust_id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_id` int(11) NOT NULL,
  `policy_id` int(11) NOT NULL,
  `approve` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `premium` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  PRIMARY KEY (`policy_cust_id`),
  KEY `cust_id` (`cust_id`),
  KEY `policy_id` (`policy_id`),
  KEY `vehicle_id` (`vehicle_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `policy_cust_table`
--

INSERT INTO `policy_cust_table` (`policy_cust_id`, `cust_id`, `policy_id`, `approve`, `date`, `premium`, `vehicle_id`) VALUES
(3, 9, 21, 1, '2014-05-09', 576, 3);

-- --------------------------------------------------------

--
-- Table structure for table `policy_table`
--

CREATE TABLE IF NOT EXISTS `policy_table` (
  `title` varchar(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `policy_id` int(11) NOT NULL AUTO_INCREMENT,
  `policy_type` text NOT NULL,
  `issued_date` datetime NOT NULL,
  `fixed_cover` varchar(500) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`policy_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `policy_table`
--

INSERT INTO `policy_table` (`title`, `description`, `policy_id`, `policy_type`, `issued_date`, `fixed_cover`, `active`, `discount`) VALUES
('policy 1', 'protection against serious damage', 20, 'Two-wheeler', '2014-05-09 08:03:01', 'damage', 1, 0),
('policy 2', 'protection against serious damage for four wheeler', 21, 'Four-wheeler', '2014-05-09 08:03:40', 'damage', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `state_table`
--

CREATE TABLE IF NOT EXISTS `state_table` (
  `state_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`state_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `state_table`
--

INSERT INTO `state_table` (`state_id`, `name`) VALUES
(1, 'Gujrat'),
(2, 'Maharashtra');

-- --------------------------------------------------------

--
-- Table structure for table `third_party_table`
--

CREATE TABLE IF NOT EXISTS `third_party_table` (
  `third_party_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` varchar(200) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` int(11) NOT NULL,
  `pincode` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `contact_no` bigint(10) NOT NULL,
  `claim_id` int(11) NOT NULL,
  PRIMARY KEY (`third_party_id`),
  KEY `claim_id` (`claim_id`),
  KEY `city` (`city`),
  KEY `state` (`state`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `third_party_table`
--

INSERT INTO `third_party_table` (`third_party_id`, `name`, `description`, `dob`, `address`, `city`, `pincode`, `state`, `contact_no`, `claim_id`) VALUES
(1, 'vivel patel', 'description', '1994-05-05', '1290,haveli ni pole', 1, 380001, 1, 9874562310, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_table`
--

CREATE TABLE IF NOT EXISTS `vehicle_table` (
  `vehicle_id` int(11) NOT NULL AUTO_INCREMENT,
  `rto` text NOT NULL,
  `class` text NOT NULL,
  `manufacture` text NOT NULL,
  `model` text NOT NULL,
  `milege` int(11) NOT NULL,
  `chasis_no` bigint(11) NOT NULL,
  `reg_type` int(11) NOT NULL,
  `reg_date` date NOT NULL,
  `age_vehicle` int(11) NOT NULL,
  `idv` bigint(20) NOT NULL,
  `ele_acc` bigint(11) NOT NULL,
  `nele_acc` bigint(11) NOT NULL,
  `cli` bigint(11) NOT NULL DEFAULT '0',
  `clc` bigint(11) NOT NULL,
  `no_pa` bigint(11) NOT NULL,
  `cc` int(11) NOT NULL,
  PRIMARY KEY (`vehicle_id`),
  UNIQUE KEY `chasis_no` (`chasis_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `vehicle_table`
--

INSERT INTO `vehicle_table` (`vehicle_id`, `rto`, `class`, `manufacture`, `model`, `milege`, `chasis_no`, `reg_type`, `reg_date`, `age_vehicle`, `idv`, `ele_acc`, `nele_acc`, `cli`, `clc`, `no_pa`, `cc`) VALUES
(3, 'AH21', 'A', '11', '50', 60, 1239515, 2, '2000-12-15', 5, 40000, 1000, 0, 0, 0, 0, 125);

-- --------------------------------------------------------

--
-- Table structure for table `witness_table`
--

CREATE TABLE IF NOT EXISTS `witness_table` (
  `witness_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` int(11) NOT NULL,
  `pincode` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `contact_no` bigint(10) NOT NULL,
  `claim_id` int(11) NOT NULL,
  PRIMARY KEY (`witness_id`),
  KEY `claim_id` (`claim_id`),
  KEY `city` (`city`),
  KEY `state` (`state`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `witness_table`
--

INSERT INTO `witness_table` (`witness_id`, `name`, `dob`, `address`, `city`, `pincode`, `state`, `contact_no`, `claim_id`) VALUES
(1, 'aditya vyas', '1995-11-06', '20,parijat app', 1, 380001, 1, 9756842310, 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accident_table`
--
ALTER TABLE `accident_table`
  ADD CONSTRAINT `accident_table_ibfk_1` FOREIGN KEY (`claim_id`) REFERENCES `claim_table` (`claim_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `agent_table`
--
ALTER TABLE `agent_table`
  ADD CONSTRAINT `agent_table_ibfk_1` FOREIGN KEY (`city`) REFERENCES `city_table` (`city_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `agent_table_ibfk_2` FOREIGN KEY (`state`) REFERENCES `state_table` (`state_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `city_table`
--
ALTER TABLE `city_table`
  ADD CONSTRAINT `city_table_ibfk_1` FOREIGN KEY (`state_id`) REFERENCES `state_table` (`state_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `claim_table`
--
ALTER TABLE `claim_table`
  ADD CONSTRAINT `claim_table_ibfk_2` FOREIGN KEY (`cust_id`) REFERENCES `cust_table` (`cust_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `claim_table_ibfk_3` FOREIGN KEY (`policy_cust_id`) REFERENCES `policy_cust_table` (`policy_cust_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cust_table`
--
ALTER TABLE `cust_table`
  ADD CONSTRAINT `cust_table_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agent_table` (`agent_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `cust_table_ibfk_4` FOREIGN KEY (`city`) REFERENCES `city_table` (`city_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `cust_table_ibfk_5` FOREIGN KEY (`state`) REFERENCES `state_table` (`state_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `driver_table`
--
ALTER TABLE `driver_table`
  ADD CONSTRAINT `driver_table_ibfk_1` FOREIGN KEY (`claim_id`) REFERENCES `claim_table` (`claim_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `driver_table_ibfk_2` FOREIGN KEY (`city`) REFERENCES `city_table` (`city_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `driver_table_ibfk_3` FOREIGN KEY (`state`) REFERENCES `state_table` (`state_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `garage_table`
--
ALTER TABLE `garage_table`
  ADD CONSTRAINT `garage_table_ibfk_1` FOREIGN KEY (`claim_id`) REFERENCES `claim_table` (`claim_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `garage_table_ibfk_2` FOREIGN KEY (`city`) REFERENCES `city_table` (`city_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `garage_table_ibfk_3` FOREIGN KEY (`state`) REFERENCES `state_table` (`state_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hospital_table`
--
ALTER TABLE `hospital_table`
  ADD CONSTRAINT `hospital_table_ibfk_1` FOREIGN KEY (`claim_id`) REFERENCES `claim_table` (`claim_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hospital_table_ibfk_2` FOREIGN KEY (`city`) REFERENCES `city_table` (`city_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `hospital_table_ibfk_3` FOREIGN KEY (`state`) REFERENCES `state_table` (`state_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `model_table`
--
ALTER TABLE `model_table`
  ADD CONSTRAINT `model_table_ibfk_1` FOREIGN KEY (`manufacturer_id`) REFERENCES `manufacturer_table` (`manufacturer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `payment_table`
--
ALTER TABLE `payment_table`
  ADD CONSTRAINT `payment_table_ibfk_1` FOREIGN KEY (`policy_id`) REFERENCES `policy_table` (`policy_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_table_ibfk_2` FOREIGN KEY (`cust_id`) REFERENCES `cust_table` (`cust_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `policy_cust_table`
--
ALTER TABLE `policy_cust_table`
  ADD CONSTRAINT `policy_cust_table_ibfk_2` FOREIGN KEY (`cust_id`) REFERENCES `cust_table` (`cust_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `policy_cust_table_ibfk_3` FOREIGN KEY (`policy_id`) REFERENCES `policy_table` (`policy_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `policy_cust_table_ibfk_4` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle_table` (`vehicle_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `third_party_table`
--
ALTER TABLE `third_party_table`
  ADD CONSTRAINT `third_party_table_ibfk_1` FOREIGN KEY (`claim_id`) REFERENCES `claim_table` (`claim_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `third_party_table_ibfk_2` FOREIGN KEY (`city`) REFERENCES `city_table` (`city_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `third_party_table_ibfk_3` FOREIGN KEY (`state`) REFERENCES `state_table` (`state_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `witness_table`
--
ALTER TABLE `witness_table`
  ADD CONSTRAINT `witness_table_ibfk_1` FOREIGN KEY (`claim_id`) REFERENCES `claim_table` (`claim_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `witness_table_ibfk_2` FOREIGN KEY (`city`) REFERENCES `city_table` (`city_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `witness_table_ibfk_3` FOREIGN KEY (`state`) REFERENCES `state_table` (`state_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
