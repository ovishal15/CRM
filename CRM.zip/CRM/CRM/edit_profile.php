<?php include("up.php"); require("comman_session.php"); ?>
<title>Edit Profile</title>
<script src="JS/edit_validate.js"></script>
<script type="text/javascript" src="JS/jquery-2.0.3.min.js"></script>
<script type="text/javascript">
function selectcity(state_id){
 if(state_id!="-1"){
   loadData(state_id);
   $("#city_dropdown").html("<option value='-1'>Select City</option>");
 }else{
   $("#city_dropdown").html("<option value='-1'>Select City</option>");
 }
}
function loadData(loadId){
  var dataString ='loadId='+ loadId;
  $("#city_loader").show();
	 $.ajax({
     type: "POST",
     url: "JS/loadcity.php",
     data: dataString,
     cache: false,
     success: function(result){
       $("#city_loader").hide();
       $("#city_dropdown").
       html("<option value='-1'>Select City</option>");
       $("#city_dropdown").append(result);
     }
   });
}
</script>
<title>Edit Profile</title>
<?php
	$err=0;
	require("var/connect.php");
	$cust_id=$_SESSION['user_id'];
	if($_SESSION['type']=='customer')
	$q="SELECT `first_name`, `last_name`, `residence_no`, `dob`, `email_id`, `picture` ,`address`, `city`, `pincode`, `state`, `contact_no` FROM `cust_table` WHERE `cust_id`='".$cust_id."'";
	else
	$q="SELECT `first_name`, `last_name`, `residence_no`, `dob`, `email_id`, `picture`,`address`, `city`, `pincode`, `state`, `contact_no` FROM `agent_table` WHERE `agent_id`='".$cust_id."'";
	$data=mysql_query($q,$dbc)or $err=1;
	if(mysql_num_rows($data)==1)
	{
		$row=mysql_fetch_array($data);
		$fname=$row[0];$lname=$row[1];$bod=$row[3];$email=$row[4];$pic=$row[5];	$add=$row[6];$city=$row[7];$pcode=$row[8];$state=$row[9];$con_no=$row[10];$res_no=$row[2];
	}
	else{$err=1;}
	if($err==0){
	?>
	<div id="errors"></div>
	<form name="edit" action="edit_profile_sub.php" onSubmit="return validateForm(this);" method="post" enctype="multipart/form-data">
	<fieldset>
			<legend>Edit Profile</legend>
	<label>* First Name</label><input type="text" name="fname" required="required" value="<?php echo $fname; ?>" /><br />
	<label>* Last Name</label><input type="text" name="lname" required="required" value="<?php echo $lname; ?>"/><br />
	<label>*Address </label><textarea name="add" required="required"><?php echo $add;?></textarea><br />
	<label>*State</label>
<select id="state_dropdown"  name="state" onChange="selectcity(this.options[this.selectedIndex].value)" required="required">
<option value="-1">Select State</option>
   	 <?php
	$q="SELECT `state_id`, `name` FROM `state_table`";
	$res=mysql_query($q,$dbc);
	while($row=mysql_fetch_array($res))
	{
	echo '<option value="'.$row[0].'">'.$row[1].'</option>';
	}
	?>
	</select><br>
	<label>*City</label>
	<select id="city_dropdown" name="city" required="required">
	<option value="-1">Select City</option>
	</select><br />
	<label>*Pincode</label><input type="text" name="pcode" required="required" value="<?php echo $pcode;?>" /><br />
	<label>*Contact No </label><input type="text" name="con_no" required="required"  value="<?php echo $con_no;?>" /><br />
	<label>Residence No</label><input type="text" name="res_no" value="<?php echo $res_no;?>"/><br />
	<label>Current Accout Picture:</label><img src="<?php echo  up_path.$pic; ?>"  width="200" height="200" /><br>
	<input type="hidden" name="old_pic" value="<?php echo $pic; ?>" />
	<label>Accout Picture:</label><input type="file" name="new_pic" /><br />
	<input type="submit" name="submit" value="Submit"/>
	</fieldset>
	</form>
	</fieldset>
	<?php
	}
	else 
	{
		echo '<div class="errors">Problem to using your proifle.</div>';
	}
?>
<?php include("down.php"); ?>