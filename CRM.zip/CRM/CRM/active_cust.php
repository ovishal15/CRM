<?php include("up.php"); require("admin_session.php");?>
<title>Active Customer</title>
<?php
	require("var/connect.php");
  	 $error = 0;
	 if(!isset($_SESSION['acid']))
	 {
	 $q2='SELECT `user_id`,`active` FROM `login_table` WHERE `type`="customer"';
	$res2=mysql_query($q2,$dbc);
	if(mysql_num_rows($res2)>=1)
	 {
	 ?>
	 <table>
	 <tr><th width="100">Name</th><th width="150">E-mail Id</th><th width="150">Address</th><th width="200">Contact No</th><th>View Profile</th></tr>
	 <?php
	while($row=mysql_fetch_array($res2))
	{
	 if($row[1]==0)
	 {
	 $q="SELECT `first_name`, `last_name`, `email_id`, `address`, `contact_no`, `cust_id` FROM `cust_table` WHERE cust_id=$row[0]";
	 $res=mysql_query($q,$dbc) or die("Problem in Access of data...............");
	 if(mysql_num_rows($res)>=1)
	 {
	 $t=0;
	 $no=rand();
	 $_SESSION['key']=$no;
	 while($row=mysql_fetch_array($res)){
	 $v=$row[5]*$_SESSION['key'];
	 echo "<tr><td>$row[0] $row[1]</td>";
	 echo "<td>$row[2]</td>";
	 echo "<td>$row[3]</td>";
	 echo "<td>$row[4]</td>";
	 echo '<td><a href="view_customer.php?type=active&vid='.$v.'">View Profile</a></td></tr>';
	 }
	 }
	 else {$t=1;}
	 }else {$t=1;}
	 }
	 	  echo '</table>';
	 }else {$t=1;}
	 if($t==1){echo '<div class="warning">All curent Customer are Actived early.........</div>';}
	 }
	else{
	$err=0;
	$cust_id = $_SESSION['acid'];
	unset($_SESSION['acid']);
	$q="UPDATE `login_table` SET `active`=1 where user_id=$cust_id and type='customer'";
	mysql_query($q,$dbc) or die ($err=1);
	if($err==0){ echo '<div class="valid">Successful Activation of Customer</div>';}
	else{echo '<div class="error">Activation failed. Try Again........</div>';}
	
	}
?>
<?php include("down.php"); ?>