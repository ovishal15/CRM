<?php include("up.php"); require("admin_session.php");?>
<title>Add FAQ</title>
	<form action="add_faq.php" method="post">
	<fieldset>
	<legend>Add New FAQ</legend>
	 <label>*Question:</label><input type="text" name="qus" required="required" /><br>
    <label>*Answer</label><textarea name="ans" rows="5" cols="30" required="required"></textarea><br>
    <input type="submit" name="submit" value="Submit" />
    </label>
	</fieldset>
	</form>
	<?php
	require("var/connect.php");
  	 $error = 0;
	if(isset($_POST['submit']))
	{
		$e=0;
		$qus=$_POST['qus'];
		$ans=$_POST['ans'];
		
		$q="INSERT INTO `faq_table`(`faq_id`, `qus`, `ans`) VALUES (0,'".$qus."','".$ans."')";
		mysql_query($q,$dbc) or $e=1;
		
			
		if($e==0){
			echo '<div class="valid">Success fuly Submited.....</div>';
		}
		else
		{
			echo '<div id="error">not Success fuly Submited.</div>';
		}
}
include("down.php"); ?>