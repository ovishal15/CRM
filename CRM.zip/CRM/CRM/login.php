<?php include("up.php"); ?>
<title>LogIn</title>
<script src="JS/log_validate.js"></script>
<?php
	$submit=0;
	require("var/connect.php");
	if(!isset($_SESSION['user_id']))
	{
	if(isset($_POST['submit'])){
		//session_start();
		$uemail=$_POST['uemail'];
		$pass=$_POST['pass'];
		$q="SELECT `user_id`,`type` FROM `login_table` WHERE `email_id`='".$uemail."' && `password`=SHA('".$pass."')";
		$result=mysql_query($q,$dbc) or $submit=1;
		if(mysql_num_rows($result)){
		$row=mysql_fetch_row($result);
		$user_id=$row[0];
		$type=$row[1];
		
			if($type=="agent")
			{
			$q2='SELECT `active` FROM `login_table` WHERE `user_id`='.$user_id.' and `type`="agent"';
			$res2=mysql_query($q2,$dbc);
			if(mysql_num_rows($res2)){
			$row=mysql_fetch_array($res2);
			if($row[0]==1)
			{
			$q1="SELECT `first_name`,last_name FROM `agent_table` WHERE agent_id='".$user_id."'";
			$result1=mysql_query($q1,$dbc);
			if(mysql_num_rows($result1)){
				$row1=mysql_fetch_array($result1);
				$_SESSION['user_id'] = $user_id;
	            $_SESSION['username'] = $row1[0].' '.$row1[1];
				$_SESSION['type']="agent";
      	  	    setcookie('user_id', $user_id, time() + (60 * 60 * 24 * 30));    // expires in 30 days
    	        setcookie('username', $row1[0], time() + (60 * 60 * 24 * 30));  // expires in 30 days
				setcookie('type', "agent", time() + (60 * 60 * 24 * 30));
	            header('Location: ' . home_url);				
				}
				else{
				$submit=1;
				}
				}
				else{echo '<div class="warning">Dear Agent, You are not active.....</div>';}
				}
			}
			elseif ($type=="customer") {
			$q2='SELECT `active` FROM `login_table` WHERE `user_id`='.$user_id.' and `type`="customer"';
			$res2=mysql_query($q2,$dbc);
			if(mysql_num_rows($res2)){
			$row=mysql_fetch_array($res2);
			if($row[0]==1)
			{
				$q1="SELECT `first_name`,last_name FROM `cust_table` WHERE cust_id='".$user_id."'";
			$result1=mysql_query($q1,$dbc);
			if(mysql_num_rows($result1)){
				$row1=mysql_fetch_array($result1);
				$_SESSION['user_id'] = $user_id;
	            $_SESSION['username'] = $row1[0].' '.$row1[1];
				$_SESSION['type']="customer";
      	  	    setcookie('user_id', $user_id, time() + (60 * 60 * 24 * 30));    // expires in 30 days
    	        setcookie('username', $row1[0], time() + (60 * 60 * 24 * 30));  // expires in 30 days
				setcookie('type', "customer", time() + (60 * 60 * 24 * 30));
	            header('Location: ' . home_url);
				}
				else{
				$submit=1;
				}
				}
				else{echo '<div class="warning">Dear Customer, You are not active.....</div>';}
				}
			}
			elseif ($type=="admin") {
			$q="SELECT `user_id` FROM `login_table` WHERE `type`='admin' && `email_id`='".$uemail."' && `password`=SHA('".$pass."')";
			$result=mysql_query($q,$dbc) or $submit=1;
			if(mysql_num_rows($result)){
			$row=mysql_fetch_row($result);
			$user_id=$row[0];
			$_SESSION['user_id'] = $user_id;
    	    $_SESSION['username'] = "Admin";
			$_SESSION['type']="admin";
	 	    setcookie('user_id', $user_id, time() + (60 * 60 * 24 * 30));    // expires in 30 days
    	    setcookie('username', "Admin", time() + (60 * 60 * 24 * 30));  // expires in 30 days
			setcookie('type', "admin", time() + (60 * 60 * 24 * 30));  // expires in 30 days
	        header('Location: ' . home_url);
		}
		else{$submit=1;}
			}
		}
		else{$submit=1;}
		if($submit==1){
		?>
		<div id="errors" class="error">Please enter correct infomation and Try Again.</div>
		<?php
		}
	}
	if($submit==1 || !isset($_POST['submit'])){
?>
<div id="errors"></div>
<form name="log" action="login.php" method="post" onSubmit="return validate_form(this)">
<fieldset>
<legend>Log-In Information</legend>
<label>Registred E-Mail Id</label><input type="text" name="uemail" required="required" /><br />
<label>Password</label><input type="password" name="pass" required="required" /><br />
<input type="submit" name="submit" value="Log In" />
</form>
<a href="for_pass.php">Forgote Password</a>
<?php }
}else
{header('Location: ' . home_url);}
include("down.php"); ?>