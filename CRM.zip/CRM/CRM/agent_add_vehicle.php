<?php include("up.php"); require("agent_session.php");?>
<script type="text/javascript" src="JS/jquery-2.0.3.min.js"></script>
<script type="text/javascript" src="JS/vehicle_validate.js"></script>
<script type="text/javascript">
function selectmanufacturer(manufacturer_id){
  if(manufacturer_id!="-1"){
    loadData("model",manufacturer_id);
  }else{
    $("#model_dropdown").html("<option value='-1'>Select model</option>");
  }
}
function loadData(loadType,loadId){
  var dataString = 'loadType='+ loadType +'&loadId='+ loadId;
  $("#"+loadType+"_loader").show();
	 $.ajax({
     type: "POST",
     url: "JS/loadData.php",
     data: dataString,
     cache: false,
     success: function(result){
       $("#"+loadType+"_loader").hide();
       $("#"+loadType+"_dropdown").
       html("<option value='-1'>Select "+loadType+"</option>");
       $("#"+loadType+"_dropdown").append(result);
     }
   });
}
</script>
<title>Add Vehicle</title>
<div id="errors"></div>
<?php 
	if(isset($_POST['submit']))
	{
	require("var/connect.php");
	$pid=$_POST['id'];
	$cust=$_POST['cust'];
	?>
<form action="agent_add_vehicle_sub.php" method="post" onsubmit="return validateForm(this)">
	<fieldset>
	<legend>Vehicle Details</legend>
	<label>RTO No</label><input type="text" name="rto" required="required"><br>
	<label>*Manufacturer</label>
	<select id="manufacturer_dropdown" name="manu" onChange="selectmanufacturer(this.options[this.selectedIndex].value)" required="required">
   	<option value="-1">Select Manufacturer</option>
		<?php
		 $sql="SELECT `manufacturer_id`, `name` FROM `manufacturer_table` WHERE `type`=4";
		 $res=mysql_query($sql,$dbc) or die($sql);
		 if(mysql_num_rows($res) >= 1){
		while($row=mysql_fetch_array($res)){
      	echo "<option value='".$row[0]."'>".$row['1']."</option>";
		   }
		}
	?>
    </option>
	</select><br />
  	<label>*Model</label>
	<select id="model_dropdown" name="mod" required="required">
	<option value="-1">Select model</option>
	</select><br>
	<label>Milege</label><input type="text" name="mil" required="required"><br>
	<label>Chsis_no</label><input type="text" name="cn" required="required"><br>
	<label>*Age of Vehicle</label><select name="age" required="required">
   	<option value="5">UP TO 5 Year</option>
    <option value="6">UP TO 5-10 Year</option>
	<option value="10">More then 10 Year</option>
    </option>
	</select><br>
	<label>*Enter CC</label><input type="text" name="cc" required="required" /><br>
	<label>*Enter IDV</label><input type="text" name="idv" required="required" /><br>
	<label>ELE. ACC FITING VALUE</label><input type="text" name="elev" /><br>
	<label>NON- ELE.ACC. VALUE</label><input type="text" name="nelev" /><br>
	<label>CNG / LPG Inbult</label><select name="cli" >
	<option value="N">No</option>
	<option value="Y">Yes</option>
	</select>
	<br>
	<label>CNG / LPG COST AMT.</label><input type="text" name="clc" /><br>
	<label>NO. OF PA PASSENGER </label><input type="text" name="nop" /><br>
	<label>Registration Date</label><input type="date" name="rd" required="required"><br>
	<input type="hidden" name="cust" value="<?php echo $cust;?>">
	<input type="hidden" name="pid" value="<?php echo $pid;?>">
    <input type="submit" name="submit" value="Submit" />
	</fieldset>
  </form>
<?php }include("down.php"); ?>