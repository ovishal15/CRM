<?php
  if (!isset($_SESSION['user_id'])) {
	 header('Location: http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/login.php');	
  }
?>