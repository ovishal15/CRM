<?php include("up.php"); ?>
<title>Terms</title>
<h2 class="title">Additional Interest Insured</h2><br>
A company or person who has been named as an additional interest insured on a policy can be liable for an accident that involves an insured person or vehicle. For example, a lienholder can be an additional interest insured.<br>

<h2 class="title">Anti-Theft Device</h2><br>
A device, either active or passive, that attempts to prevent vehicle theft. Active anti-theft devices can track and recover a vehicle and automatically contact a response center to begin the vehicle recovery process. Passive anti-theft devices attempt to prevent theft by using sophisticated electronic car alarms, simple steering wheel locks, etc.<br>

<h2 class="title">Bodily Injury Liability Coverage (BI)</h2><br>
If an insured person is legally liable for an accident, BI coverage pays for injuries/death to people involved in the accident other than the insured driver. BI also pays for legal defense costs if you are sued. Certain exclusions may apply. Refer to your policy.<br>

<h2 class="title">Comprehensive Coverage</h2><br>
If your insured vehicle is damaged due to an event other than a collision, Comprehensive coverage will pay for the damage. This includes damages from fire, theft, windstorm, flood and vandalism. If your vehicle is stolen, Comprehensive covers transportation and loss of use expenses when applicable.<br>

<h2 class="title">Collision Coverage</h2><br>
When your insured vehicle overturns or collides with another object, Collision coverage pays for the damage to your vehicle. Collision coverage also may extend to a non-owned vehicle or one rented for personal use that is in your custody or that you are operating. Certain exclusions may apply. Refer to your policy.<br>
<h2 class="title"> Continuously Insured</h2><br>
Being continuously insured means your insurance coverage from an insurer or more than one insurer was in effect at all times, without a break or lapse in coverage for any reason.<br>

<a href="terms1.php">Next >></a>

<?php include("down.php"); ?>
