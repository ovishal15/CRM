<?php include("up.php"); require("comman_session.php"); include("chk_app.php");?>
<title>Give Feed Back</title>
	<?php
	if(isset($_POST['submit']))
	{
	  	$error = 0;
		$review=$_POST['review'];
		$rate=$_POST['rate'];
		$id=$_SESSION['user_id'];
		$type=$_SESSION['type'];
		$q="INSERT INTO `feed_back_table`(`feed_id`, `rate`, `description`, `id`, `type`, date) VALUES (0,$rate,'".$review."',$id,'".$type."',now())";
		mysql_query($q,$dbc) or ($error=1);
		if($error==0){echo '<div class="valid">Your Review have been submited</div>';}
		else{ echo '<div id="errors">Problem is found try agine later</div>';}
	}
	else{
	?>
	<fieldset>
	<legend>Feed Back</legend>
	<form action="give_feed_back.php" method="post">
	<label>*YOUR REVIEW</label><textarea name="review" required="required"></textarea><br />
	<label>*RATE</label><select name="rate">
      <option value="1">1</option>
      <option value="2">2</option>
      <option value="3">3</option>
      <option value="4">4</option>
      <option value="5">5</option>
    </select>
	<input type="submit" name="submit">
	</form>
	</fieldset>
<?php }include("down.php"); ?>