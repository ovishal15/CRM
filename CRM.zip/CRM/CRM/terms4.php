<?php include("up.php"); ?>
<title>Terms</title>
<b>Second Named Insured </b><br>
The named insured or listed agent/broker on a policy may request to designate any other person listed on the policy as a second named insured. The second named insured has the same coverage under the policy as the named insured.<br>

<b>SR-22</b><br>
An SR-22 is a document required by the court that demonstrates proof of financial responsibility for persons convicted of certain traffic violations.<br>

<b>Uninsured Motorist Coverage (UM)</b><br>
If a driver or owner of a vehicle does not have insurance and is legally liable for an accident, you can use UM coverage for injuries, including death, that you, your resident relatives, and occupants of your insured vehicle sustain, up to the limits you select. Certain exclusions may apply. Refer to your policy.<br>

<b>Underinsured Motorist Coverage (UIM)</b><br>
If a driver or owner of a vehicle is legally liable for an accident but does not have enough insurance, you can use UIM coverage for injuries, including death, that you, your resident relatives, and occupants of your insured vehicle sustain, up to the limits you select. Certain exclusions may apply. Refer to your policy.<br>

<b>Uninsured/Underinsured Motorist Property Damage Coverage (UMPD)</b><br>
If driver or owner of a vehicle is legally liable for an accident but does not have insurance or does not have enough insurance, you can use UMPD to cover damage to your insured vehicle, up to the limits you select. In some states, UMPD is available as an alternative to Collision coverage. Certain exclusions may apply. Refer to your policy.<br>

<b>Vehicle Identification Number (VIN)</b><br>
The Vehicle Identification Number (VIN) for your vehicle is usually found on the driver's side of your dashboard, the vehicle registration or the title. The VIN is a combination of 17 letters and numbers that can be used to identify the make, model and year of a car.<br>

<p><a href="terms3.php"> Previous </a> 
<?php include("down.php"); ?>