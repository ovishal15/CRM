<?php include("up.php"); require("admin_session.php");?>
<title>Update Policy</title>
<form action="admin_edit_policy_sub.php" method="post">
	<fieldset>
	<legend>Select Policy</legend>
	<?php
	require("var/connect.php");
	 $q='SELECT `policy_id`,`title`, `policy_type`, `description`  FROM `policy_table` where `active`=1';
	 $res=mysql_query($q,$dbc);
	 ?>
	 <table><tr><th width="150">Policy</th><th width="150">Type</th><th width="250">description</th></tr>
	 <?php
	 while($row=mysql_fetch_array($res))
	 {
	 echo '<tr><td><input type="radio" required="required" name="poli" value="'.$row[0].'" />'.$row[1].'</td><td>'.$row[2].'</td><td>'.$row[3].'</td></tr>'; 
	 }
	 ?></table>
    <input type="submit" name="submit" value="Submit" />
	</fieldset>
  </form>
<?php include("down.php"); ?>