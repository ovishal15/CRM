<?php include("up.php"); require("comman_session.php"); include("chk_app.php");?>
<title>Add Accident</title>
<?php
if(isset($_POST['submit']) && isset($_SESSION['cclim']) && isset($_SESSION['cclima']) && isset($_SESSION['cdriver']) && isset($_SESSION['cwitness']) && isset($_SESSION['chos']) && isset($_SESSION['cgar']) && isset($_SESSION['cthird']))
{
$err=0;

mysql_query($_SESSION['cclim'],$dbc) or $err=1;

$res=mysql_query($_SESSION['cclima'],$dbc);
$row=mysql_fetch_array($res);
$cid=$row[0];

$cd=str_replace("claim_no",$cid,$_SESSION['cdriver']);
mysql_query($cd,$dbc) or $err=1;

$cw=str_replace("claim_no",$cid,$_SESSION['cwitness']);
mysql_query($cw,$dbc) or $err=1;

$ch=str_replace("claim_no",$cid,$_SESSION['chos']);
mysql_query($ch,$dbc) or $err=1;

$cg=str_replace("claim_no",$cid,$_SESSION['cgar']);
mysql_query($cg,$dbc) or $err=1;

$ct=str_replace("claim_no",$cid,$_SESSION['cthird']);
mysql_query($ct,$dbc) or $err=1;
unset($_SESSION['cclim']);
unset($_SESSION['cclima']);
unset($_SESSION['cdriver']);
unset($_SESSION['cwitness']);
unset($_SESSION['chos']);
unset($_SESSION['cgar']);
unset($_SESSION['cthird']);
$pname=$_POST['pname'];
$aname=$_POST['aname'];
$desc=$_POST['desc'];
$q='INSERT INTO `accident_table`(`accident_id`, `rep_date`, `claim_id`, `police_station`, `police_attender`, `description`) VALUES (0,now(),'.$cid.',"'.$pname.'","'.$aname.'","'.$desc.'")';
mysql_query($q,$dbc) or $err=1;
	if($err==0){
			echo '<div class="valid">Success fully Add Claim.</div>';
		}
		else
		{
			echo '<div class="error">not Success fully add claim Try Again.</div>';
		}
}
?>
<?php include("down.php"); ?>