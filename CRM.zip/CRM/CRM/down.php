</div>
<div style="clear: both;">&nbsp;</div>
	</div>
</div>
<div id="footer">
	<p class="copyright">&copy;&nbsp;&nbsp;2014 All Rights Reserved for CRM.</p>
	<p class="link" ><a href="insurance_video.php">Insurance Video</a>&nbsp;&#8226;&nbsp;<a href="view_feed_back.php">Feed Back</a>&nbsp;&#8226;&nbsp;<a href="how to claim.php">How to claim?</a>&nbsp;&#8226;&nbsp;<a href="insurance_updates.php">Insurance Updates</a>&nbsp;&#8226;&nbsp;<a href="privacy.php">Privacy Policy</a>&nbsp;&#8226;&nbsp;<a href="terms.php">Terms of Use</a></p>
</div>