<?php include("up.php");  require("cust_session.php"); require("chk_app.php");?>
<title>Customer Policy</title>
	<?php
  	 $error = 0;
	 $cust_id=$_SESSION['user_id'];
	 $q1="SELECT `policy_id`,`premium`,`policy_cust_id`  FROM `policy_cust_table` WHERE cust_id=$cust_id and approve=1";
	 $res1=mysql_query($q1,$dbc);
	 if(mysql_num_rows($res1)>=1)
	 {
	 ?>
	<fieldset>
	<legend>Customer's Polices</legend>
	<?php
	 while($row1=mysql_fetch_row($res1)){
	 $pid=$row1[0];
	 $pre=$row1[1];
	 $pcid=$row1[2];
	$q='SELECT `title`,`policy_type`, `description`, `fixed_cover` FROM `policy_table` where policy_id='.$pid.'';
	 $res=mysql_query($q,$dbc);
	 if(mysql_num_rows($res)==1){
 	 while($row=mysql_fetch_array($res)){
	echo '<fieldset style="border:double 1px"><legend>'.$user_name.'</legend>';
	 echo '<label>Policy No</label><td>'.$pcid.'<br>';
	 echo '<label>Policy</label><td>'.$row[0].'<br>';
	 echo '<label>Type</label><td>'.$row[1].'<br>';
	 echo '<label>Description</label><td>'.$row[2].'<br>';
	 echo '<label>Premium</label><td>'.$pre.'<br>';
	 echo '<label>Fixed Cover</label>'.$row[3].'<br>';
	 echo '</fieldset>';
	 }
	 }
	 }
	 }
	 else {
		 echo '<div class="warning">You not has any policy or not yet active.</div>';
	 }
	 
	?>
	</fieldset>
<?php include("down.php"); ?>