<a class="menuitem submenuheader" href="">View</a>
<div class="submenu">
    <ul>
	<li><a href="admin_view_cust.php">View Customers</a></li>
	<li><a href="admin_view_agent.php">View Agents</a></li>
	<li><a href="admin_cust_policy.php">View Customer's Policy</a></li>
	<li><a href="admin_view_claim.php">View Claim Request</a></li>
	<li><a href="admin_contact_request.php">View Contact Request</a></li>
    </ul>
</div>
<br>
<a class="menuitem submenuheader" href="" >Approve</a>
<div class="submenu">
    <ul>
    <li><a href="approve_cust.php">Approve Customer</a></li>
	<li><a href="approve_agent.php">Approve Agent</a></li>
	<li><a href="approve_policy.php">Approve Polices</a></li>
	<li><a href="approve_feed_back.php">Approve Feed Back</a></li>
	<li><a href="approve_claim.php">Approve Claim</a></li>
    </ul>
</div>
<br>
<a class="menuitem submenuheader" href="">Active</a>
<div class="submenu">
    <ul>
    <li><a href="active_cust.php">Active Customer</a></li>
	<li><a href="active_agent.php">Active Agent</a></li>
    </ul>
</div>
<br>
<a class="menuitem submenuheader" href="">Add new</a>
<div class="submenu">
    <ul>
    <li><a href="add_policy.php">Add new Polices</a></li>
    <li><a href="add_faq.php">Add FAQ</a></li>
    <li><a href="add_manufacturer.php">Add Manufacturer</a></li>
    <li><a href="add_model.php">Add Model</a></li>
    </ul>
</div>
<br>
<a class="menuitem submenuheader" href="" >Update</a>
<div class="submenu">
    <ul>
    <li><a href="admin_edit_cust.php">Update Customer</a></li>
	<li><a href="admin_edit_agent.php">Update Agent</a></li>
	<li><a href="admin_edit_policy.php">Update Polices</a></li>
    </ul>
</div>
<br>
<a class="menuitem submenuheader" href="">Remove</a>
<div class="submenu">
    <ul>
    <li><a href="remove_cust.php">Remove Customer</a></li>
    <li><a href="remove_agent.php">Remove Agent</a></li>
    <li><a href="remove_policy.php">Remove Polices</a></li>
    </ul>
</div>
<br>
<a href="chg_pass.php">Change Password</a></li>
<a href="log_out.php">Log Out</a></li>