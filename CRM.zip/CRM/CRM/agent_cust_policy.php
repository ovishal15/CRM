<?php include("up.php"); require("agent_session.php"); include("chk_app.php");?>
<title>Customer Policy</title>
<?php
  	 $error = 0;
	 $agent_id=$_SESSION['user_id'];
	 $q="SELECT `first_name`, `last_name`, `email_id`, `address`, `contact_no`, `cust_id` FROM `cust_table` where agent_id=$agent_id";
	 $res=mysql_query($q,$dbc) or die("Problem in Access of data...............");
	 if(mysql_num_rows($res)>=1)
	 {
	 ?>
	 <table>
	 <tr><th width="100">Name</th><th width="150">E-mail Id</th><th width="150">Address</th><th width="200">Contact No</th><th>View Policy</th></tr>
	 <?php
	 $no=rand();
	 $_SESSION['key']=$no;
	 while($row=mysql_fetch_array($res)){
	 $v=$row[5]*$_SESSION['key'];
	 echo "<tr><td>$row[0] $row[1]</td>";
	 echo "<td>$row[2]</td>";
	 echo "<td>$row[3]</td>";
	 echo "<td>$row[4]</td>";
	 echo '<td><a href="agent_view_cust_poli.php?user_name='.$row[0].' '. $row[1].'&vid='.$v.'">View Policy</a></td></tr>';
	 }
	  echo '</table>';
	 }
	 else{echo '<div class="error">No Customer available.</div>';}

?>
<?php include("down.php"); ?>