<?php include("up.php"); require("agent_session.php");?>
<title>Customer Registration</title>
<?php
	require("var/connect.php");
  	 $error = 0;
	if(isset($_POST['sub']))
	{
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$email=$_POST['email'];
		$dob=$_POST['dob'];
		$add=$_POST['add'];
		$pcode=$_POST['pcode'];
		$state=$_POST['state'];
		$con_no=$_POST['con_no'];
		$res_no=$_POST['res_no'];
		$title=$_POST['title'];
		$city=$_POST['city'];
		$pass=$_POST['pass'];
		$qus=$_POST['qus'];
		$ans=$_POST['ans'];
		
		
		 $new_pic = trim($_FILES['new_pic']['name']);
    	 $new_pic_type = $_FILES['new_pic']['type'];
	     $new_pic_size = $_FILES['new_pic']['size']; 

    // Validate and move the uploaded picture file, if necessary
    	 if (!empty($new_pic)) {
         if ((($new_pic_type == 'image/gif') || ($new_pic_type == 'image/jpeg') || ($new_pic_type == 'image/pjpeg') ||
        ($new_pic_type == 'image/png')) && ($new_pic_size > 0) && ($new_pic_size <= 3276800)) {

          // Move the file to the target upload folder
          $target = up_path . basename($new_pic);
          if (move_uploaded_file($_FILES['new_pic']['tmp_name'], $target)) {
            
          }
          else {
            // The new picture file move failed, so delete the temporary file and set the error flag
            @unlink($_FILES['new_pic']['tmp_name']);
            $error = 1;
            echo '<p class="errors">Sorry, there was a problem uploading your picture.</p>';
          }
        
      }
      else {
        // The new picture file is not valid, so delete the temporary file and set the error flag
        @unlink($_FILES['new_pic']['tmp_name']);
        $error = 1;
        echo '<p class="errors">Your picture must be a GIF, JPEG, or PNG image file no greater than ' . (3276800 / 1024) .' KB.</p>';
      }
    }

		
		
		
		
		
		
		$e=0;
		
	if(empty($new_pic))
	{
	$q1="INSERT INTO `cust_table`(`cust_id`, `title`, `first_name`, `last_name`, `dob`, `email_id`, `qus`, `ans`,  `address`, `city`, `pincode`, `state`, `contact_no`, `residence_no`, `agent_id`) VALUES (0,'".$title."','".$fname."','".$lname."','".$dob."','".$email."','".$qus."','".$ans."','".$add."','".$city."','".$pcode."','".$state."','".$con_no."','".$res_no."','".$_SESSION['user_id']."')";
	}
	else
	{
	$q1="INSERT INTO `cust_table`(`cust_id`, `title`, `first_name`, `last_name`, `dob`, `email_id`, `qus`, `ans`, `picture`, `address`, `city`, `pincode`, `state`, `contact_no`, `residence_no`,  `agent_id`) VALUES (0,'".$title."','".$fname."','".$lname."','".$dob."','".$email."','".$qus."','".$ans."','".$new_pic."','".$add."','".$city."','".$pcode."','".$state."','".$con_no."','".$res_no."','".$_SESSION['user_id']."')";
	}
		mysql_query($q1,$dbc) or $e=1;
		if($e!=1){
		$q2="select cust_id from cust_table where email_id='".$email."'";
		$res=mysql_query($q2,$dbc) or $e=1;
		$row=mysql_fetch_array($res);
		$cust_id=$row[0];
		$q4="INSERT INTO `login_table`(`user_id`, `email_id`, `type`, `password`) VALUES ('".$cust_id."','".$email."','customer',SHA('".$pass."'))";
		mysql_query($q4,$dbc) or $e=1;
		}	
		
		if($e==0){
			echo "Success fuly Registred";
		}
		else
		{
			echo "not Success fuly Registred";
		}
}

//First this if executed to view data
		if(isset($_POST['submit']) || $error==1)
		{
			$fname=$_POST['fname'];
			$lname=$_POST['lname'];
			$email=$_POST['email'];
			$dob=$_POST['dob'];
			$add=$_POST['add'];
			$pcode=$_POST['pcode'];
			$state=$_POST['state'];
			$con_no=$_POST['con_no'];
			$res_no=$_POST['res_no'];
			$title=$_POST['title'];
			$city=$_POST['city'];
			$pass=$_POST['pass'];
			$qus=$_POST['qus'];
			$ans=$_POST['ans'];
			?>
			<fieldset>
			<legend>Conform Data</legend>
			<label>Name:</label><?php echo $fname.' '.$lname;?><br />
			<label>E-mail ID:</label><?php echo $email;?><br />
			<label>Title:</label><?php echo $title;?><br />
			<label>Date of Birth:</label><?php echo $dob;?><br />
			<label>Contect No:</label><?php echo $con_no;?><br />
			<label>Residence No:</label><?php echo $res_no;?><br />
			<label>Address:</label><?php echo $add;?><br />
			<label>Pincode:</label><?php echo $pcode;?><br />
			<label>State:</label><?php echo $state;?><br />
			<label>City:</label><?php echo $city;?><br />		
						
			<form action="agent_cust_reg_sub.php" method="post" enctype="multipart/form-data"><?php
			echo '<input type="hidden" name="fname" value="'.$fname.'" />';
			echo '<input type="hidden" name="lname" value="'.$lname.'" />';
			echo '<input type="hidden" name="email" value="'.$email.'" />';
			echo '<input type="hidden" name="dob" value="'.$dob.'" />';
			echo '<input type="hidden" name="add" value="'.$add.'" />';
			echo '<input type="hidden" name="pcode" value="'.$pcode.'" />';
			echo '<input type="hidden" name="state" value="'.$state.'" />';
			echo '<input type="hidden" name="con_no" value="'.$con_no.'" />';
			echo '<input type="hidden" name="res_no" value="'.$res_no.'" />';
			echo '<input type="hidden" name="title" value="'.$title.'" />';
			echo '<input type="hidden" name="city" value="'.$city.'" />';
			echo '<input type="hidden" name="pass" value="'.$pass.'" />';
			echo '<input type="hidden" name="qus" value="'.$qus.'" />';
			echo '<input type="hidden" name="ans" value="'.$ans.'" />';
			?>
			<label>Accout Picture</label><input type="file" name="new_pic" /><br />
			<input type="submit" name="sub" />
			</fieldset>
			</form>
			<img src="" id="pic" alt="" />
			<?php
		}
?>
<?php include("down.php"); ?>