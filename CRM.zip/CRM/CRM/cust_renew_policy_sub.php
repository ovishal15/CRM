<?php include("up.php"); require("comman_session.php"); include("chk_app.php");?>
<title>Renew Policy</title>
<?php 
	if(isset($_POST['submit'])){
	$pcid=$_POST['poli'];
	$err=0;
	if($_SESSION['type']=='customer')$cust=$_SESSION['user_id'];
	else{$cust=$_SESSION['rcust']; unset($_SESSION['rcust']);}
	$q='UPDATE `policy_cust_table` SET `approve`=0,`date`=now() WHERE policy_cust_id='.$pcid.' and cust_id='.$cust.'';
	mysql_query($q,$dbc) or $err=1;
	if($err==0){echo '<div class="warning">Your policy have been submited,we approve your policy when you pay money.</div>';}
	else{echo '<p class="error">Sorry, Some error found so try again later</p>';}

	}
	?>
<?php include("down.php"); ?>