<?php include("up.php"); ?>
<title>Agent Registration</title>
<script type="text/javascript" src="JS/jquery-2.0.3.min.js"></script>
<script type="text/javascript">
function selectcity(state_id){
 if(state_id!="-1"){
   loadData(state_id);
   $("#city_dropdown").html("<option value='-1'>Select City</option>");
 }else{
   $("#city_dropdown").html("<option value='-1'>Select City</option>");
 }
}
function loadData(loadId){
  var dataString ='loadId='+ loadId;
  $("#city_loader").show();
	 $.ajax({
     type: "POST",
     url: "JS/loadcity.php",
     data: dataString,
     cache: false,
     success: function(result){
       $("#city_loader").hide();
       $("#city_dropdown").
       html("<option value='-1'>Select City</option>");
       $("#city_dropdown").append(result);
     }
   });
}
</script>
<script src="JS/reg_validate.js"></script>
<form name="reg" action="agent_reg_sub.php" onSubmit="return validateForm(this);" method="post">
  <label>*Required Fields</label><br>
  <div id="errors"></div>
  <fieldset>
  <legend>Agent Registration Information</legend>
<label>* First Name</label><input type="text" name="fname" required="required" /><br />
<label>* Last Name</label><input type="text" name="lname" required="required"/><br />
<label>* E-mail ID </label><input type="text" name="email" required="required"/><br />
<label>*Title </label>
  <select name="title" style="width:160" required="required">
    <option value="Male">Mr.</option>
    <option value="Female">Mrs.</option>
  </select>
  <br />
<label>* Date of Birth</label><input name="dob" type="date" required="required"/><br />
<label>*Address </label><textarea name="add" required="required"></textarea><br />
<label>*State</label>
<select id="state_dropdown"  name="state" onChange="selectcity(this.options[this.selectedIndex].value)" required="required">
<option value="-1">Select State</option>
   	 <?php
	require("var/connect.php");
	$q="SELECT `state_id`, `name` FROM `state_table`";
	$res=mysql_query($q,$dbc);
	while($row=mysql_fetch_array($res))
	{
	echo '<option value="'.$row[0].'">'.$row[1].'</option>';
	}
	?>
</select><br>

<label>*City</label>
<select id="city_dropdown" name="city" required="required">
<option value="-1">Select City</option>
</select><br />
<label>*Pincode</label><input type="text" name="pcode" required="required" /><br />
<label>*Contact No </label><input type="text" name="con_no" required="required" /><br />
<label>Residence No</label><input type="text" name="res_no"/><br />
<label>*Password</label><input type="password" name="pass" required="required"><br />
<label>*Conform Password</label><input type="password" name="con_pass" required="required"><br />
<label>*Security Question</label><select name="qus" required="required">
<option value="What is your pet name?">What is your pet name?</option>
<option value="What is your first friend name?">What is your first friend name?</option>
<option value="What is your city name?">What is your city name?</option>
<option value="Whitch is your first Phone no ?">Whitch is your first Phone no?</option>
</select><br>
<label>*Answer</label><input type="text" name="ans" required="required" /><br>
<input type="checkbox" value="checkbox" required="required" /><b>I hereby acknowledge and accept the terms.</b><br />
<input type="submit" name="submit" value="Next" />
</fieldset>
</form>
<?php include("down.php"); ?>