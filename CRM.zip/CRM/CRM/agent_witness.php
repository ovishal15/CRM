<?php include("up.php"); require("agent_session.php");?>
<title>Add Witness</title>
<script type="text/javascript" src="JS/jquery-2.0.3.min.js"></script>
<script type="text/javascript">
function selectcity(state_id){
 if(state_id!="-1"){
   loadData(state_id);
   $("#city_dropdown").html("<option value='-1'>Select City</option>");
 }else{
   $("#city_dropdown").html("<option value='-1'>Select City</option>");
 }
}
function loadData(loadId){
  var dataString ='loadId='+ loadId;
  $("#city_loader").show();
	 $.ajax({
     type: "POST",
     url: "JS/loadcity.php",
     data: dataString,
     cache: false,
     success: function(result){
       $("#city_loader").hide();
       $("#city_dropdown").
       html("<option value='-1'>Select City</option>");
       $("#city_dropdown").append(result);
     }
   });
}
</script>
<script src="JS/witness_validate.js"></script>
<div id="errors"></div>
<?php
if(isset($_POST['submit']))
{
require("var/connect.php");
$err=0;
$cid=$_POST['cid'];
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$tp=$_POST['tp'];
$di=$_POST['di'];
$licno=$_POST['licno'];
$edate=$_POST['edate'];
$lictype=$_POST['lictype'];
$add=$_POST['add'];
$pcode=$_POST['pcode'];
$state=$_POST['state'];
$city=$_POST['city'];
$con_no=$_POST['con_no'];
$q='INSERT INTO `driver_table`(`driver_id`, `first_name`, `last_name`, `type`, `drug_influence`, `lic_no`, `exp_date`, `lic_type`, `address`, `city`, `pincode`, `state`, `contact_no`, `claim_id`) VALUES (0,"'.$fname.'","'.$lname.'","'.$tp.'","'.$di.'",'.$licno.','.$edate.',"'.$lictype.'","'.$add.'",'.$pcode.',"'.$state.'","'.$city.'",'.$con_no.','.$cid.')';
mysql_query($q,$dbc) or $err=1;
	if($err==1){echo 'error';}
}
if(isset($_POST['submit']) && $err==0){
?>
<form method="post" action="agent_hospital.php" onSubmit="return validate_form(this)">
<fieldset>
<legend>Withness Details</legend>
	<label>Full Name</label><input type="text" name="fname" required="required"><br>
	<label>Date of Birth</label><input type="date" name="dob" required="required"><br>
	<label>*Address </label><textarea name="add" required="required"></textarea><br />
<label>*State</label>
<select id="state_dropdown"  name="state" onChange="selectcity(this.options[this.selectedIndex].value)" required="required">
<option value="-1">Select State</option>
   	 <?php
	require("var/connect.php");
	$q="SELECT `state_id`, `name` FROM `state_table`";
	$res=mysql_query($q,$dbc);
	while($row=mysql_fetch_array($res))
	{
	echo '<option value="'.$row[0].'">'.$row[1].'</option>';
	}
	?>
</select><br>

<label>*City</label>
<select id="city_dropdown" name="city" required="required">
<option value="-1">Select City</option>
</select><br />
<label>*Pincode</label><input type="text" name="pcode" required="required" /><br />
<label>*Contact No </label><input type="text" name="con_no" required="required" /><br />
<input type="hidden" name="cid" value="<?php echo $cid;?>">
<input type="submit" name="submit">
</fieldset>
</form>
<?php }include("down.php"); ?>