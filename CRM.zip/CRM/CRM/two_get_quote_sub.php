<?php include("up.php"); ?>
<title>Get Quote</title>
<?php
	if(isset($_POST['submit']))
	{
	$rto=$_POST['rto'];
	$age=$_POST['age'];
	$cc=$_POST['cc'];
	$idv=$_POST['idv'];
	$elev=$_POST['elev'];
	$nelev=$_POST['nelev'];

	$amount=0;
	require_once 'Classes/PHPExcel.php';
require_once 'Classes/PHPExcel/IOFactory.php';
$zone="A";

$inputFileType = PHPExcel_IOFactory::identify('get_quote.xls');
$objPHPExcel = PHPExcel_IOFactory::load('get_quote.xls');

$objPHPExcel->setActiveSheetIndex(1);
$objPHPExcel->getActiveSheet()->setCellValue('I2',"TWO WHEELERS");
$objPHPExcel->getActiveSheet()->setCellValue('J6',$zone);
$objPHPExcel->getActiveSheet()->setCellValue('J7',$age);
$objPHPExcel->getActiveSheet()->setCellValue('J8',$cc);
$objPHPExcel->getActiveSheet()->setCellValue('J9',$idv);
$objPHPExcel->getActiveSheet()->setCellValue('J10',$elev);
$objPHPExcel->getActiveSheet()->setCellValue('J11',$nelev);

$amount= $objPHPExcel->getActiveSheet()->getCell('N39')->getCalculatedValue();


echo '<div class="valid">Amount for pay is ' . $amount ;
echo "<br>";
echo 'This Amout is with out sepcial discount if is given in policY</div>';
}
?>
<?php include("down.php"); ?>