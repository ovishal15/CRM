<?php include("up.php"); require("admin_session.php");?>
<title>Add Policy</title>
<script src="JS/chk_policy.js"></script>
<div id="errors"></div>
	<form action="add_policy.php" method="post" onsubmit="return validate_policy(this)">
	<fieldset>
	<legend>Add New Policy</legend>
	 <label>*Title:</label><input type="text" name="title" required="required" /><br>
    <label>*Policy details</label><textarea name="desc" rows="6" cols="30" required="required"></textarea>
    <br>
    <label>*Policy type</label>
    Two-wheeler<input name="ptype" type="radio" value="Two-wheeler" checked="checked" />
	Four wheeler<input name="ptype" type="radio" value="Four-wheeler" /><br>
  	<label>*Fixed cover</label><input type="text" name="cover" required="required" /><br>
	<label>Special Discount</label><input type="text" name="dis" /><br>
    <input type="submit" name="submit" value="Submit" />
    </label>
	</fieldset>
	</form>
	<?php
	require("var/connect.php");
  	 $error = 0;
	if(isset($_POST['submit']))
	{
		$e=0;
		$title=$_POST['title'];
		$desc=$_POST['desc'];
		$ptype=$_POST['ptype'];
		$cover=$_POST['cover'];
		$dis=$_POST['dis'];
		$q="INSERT INTO `policy_table`(`title`, `description`, `policy_id`, `policy_type`, `issued_date`, `fixed_cover`,`discount`) VALUES ('".$title."', '".$desc."', 0, '".$ptype."',NOW(),'".$cover."','".$dis."')";
		mysql_query($q,$dbc) or $e=1;
		if($e==0) echo '<div class="valid">Success fuly Submited</div>';
		else echo '<div class="error">not Success fuly Submited</div>';
}
	?>
<?php include("down.php"); ?>