<?php include("up.php");  require("admin_session.php");?>
<title>Contact Request</title>
<?php 
	require("var/connect.php");
	$err=0;
	$q='SELECT `contact_id`, `name`, `email_id`, `contact_no`, `message`, `date` FROM `contact_table` ORDER BY  `contact_table`.`date` DESC';
	$res=mysql_query($q,$dbc);
	?>
	<table>
		<tr>
			<td>Name</td><td>Email-id</td><td>Conatact No</td><td>Message</td><td>Date</td>
		</tr>
	<?php
	while($row=mysql_fetch_array($res))
	{
		echo '<tr><td>'.$row[1].'</td><td>'.$row[2].'</td><td>'.$row[3].'</td><td>'.$row[4].'</td><td>'.$row[5].'</td></tr>';
	}
?>
</table>
<?php include("down.php"); ?>