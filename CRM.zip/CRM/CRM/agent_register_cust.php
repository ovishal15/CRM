<?php include("up.php"); require("agent_session.php");?>
<title>Register Customer</title>
<script src="JS/reg_validate.js"></script>
<form name="reg" action="agent_cust_reg_sub.php" onSubmit="return validateForm(this);" method="post">
  <label>*Required Fields</label><br>
  <div id="errors"></div>
  <fieldset>
  <legend>Customer Registration Information</legend>
<label>* First Name</label><input type="text" name="fname" required="required" /><br />
<label>* Last Name</label><input type="text" name="lname" required="required"/><br />
<label>* E-mail ID </label><input type="text" name="email" required="required"/><br />
<label>*Title </label>
  <select name="title" style="width:160" required="required">
    <option value="Male">Mr.</option>
    <option value="Female">Mrs.</option>
  </select>
  <br />
<label>* Date of Birth</label><input name="dob" type="date" required="required"/><br />
<label>*Address </label><textarea name="add" required="required"></textarea><br />
<label>*City</label>
	<select name="city" style="width:160" required="required">
	<option value="Ahmedabad">Ahmedabad</option>
	</select><br />
<label>*Pincode</label><input type="text" name="pcode" required="required" /><br />
<label>*State</label><input type="text" name="state" required="required"/><br />
<label>*Contact No </label><input type="text" name="con_no" required="required" /><br />
<label>Residence No</label><input type="text" name="res_no"/><br />
<label>*Password</label><input type="password" name="pass" required="required"><br />
<label>*Conform Password</label><input type="password" name="con_pass" required="required"><br />
<label>*Security Question</label>
<select name="qus" required="required">
<option value="What is your pet name?">What is your pet name?</option>
<option value="What is your first friend name?">What is your first friend name?</option>
<option value="What is your city name?">What is your city name?</option>
<option value="Whitch is your first Phone no ?">Whitch is your first Phone no?</option>
</select><br>
<label>*Answer</label><input type="text" name="ans" required="required" /><br>
<input type="checkbox" value="checkbox" required="required" /><b>I hereby acknowledge and accept the terms.</b><br />
<input type="submit" name="submit" value="Next" />
</fieldset>
</form>
<?php include("down.php"); ?>